"""聊天 API 路由"""
from __future__ import annotations

import logging
import re
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sse_starlette.sse import EventSourceResponse

import database as db
from models import router as model_router
from models import OpenAICompatAdapter, EchoAdapter, ADAPTER_MAP
from config import ProviderConfig, settings
from tools import execute_tool_with_guard, TOOL_EXECUTORS
from prompt_builder import build_system_prompt

logger = logging.getLogger(__name__)
api = APIRouter(prefix="/api")


def _normalize_memory_text(text: str) -> str:
    return re.sub(r"\s+", "", text.strip().lower())


def _infer_memory_category_from_text(text: str) -> Optional[str]:
    # 规则优先：长期偏好/身份 => deep，计划安排 => daily，其余不强制提取
    deep_markers = ["我叫", "我是", "我喜欢", "我不喜欢", "我讨厌", "我习惯", "我希望", "我更喜欢"]
    daily_markers = ["今天", "明天", "这周", "计划", "待会", "等会", "要去", "要做", "安排"]
    if any(k in text for k in deep_markers):
        return "deep"
    if any(k in text for k in daily_markers):
        return "daily"
    return None


async def _load_saved_chat_provider() -> dict[str, str] | None:
    row = await db.get_setting("ai_settings")
    if not row or not row.get("value"):
        return None
    try:
        payload = json.loads(row["value"])
    except Exception:
        return None

    ai = payload.get("aiSettings") or payload.get("ai") or {}
    chat_slot = (ai.get("defaultModels") or {}).get("chat") or {}
    providers = ai.get("providers") or []
    provider = next((item for item in providers if item.get("id") == chat_slot.get("providerId")), None)
    if not provider or not provider.get("baseUrl") or not provider.get("apiKey"):
        return None
    return {
        "provider": provider.get("name") or provider.get("id") or "saved",
        "model": chat_slot.get("model") or provider.get("defaultModel") or "",
        "base_url": provider.get("baseUrl") or "",
        "api_key": provider.get("apiKey") or "",
    }


async def _auto_capture_memory_from_user_text(user_text: str):
    if not settings.memory_auto_extract_enabled:
        return
    text = (user_text or "").strip()
    if not text:
        return
    if len(text) < max(1, settings.memory_auto_extract_min_chars):
        return
    if len(text) > max(settings.memory_auto_extract_min_chars + 1, settings.memory_auto_extract_max_chars):
        return

    category = _infer_memory_category_from_text(text)
    if not category:
        return

    # 去重：用前缀关键词检索，再做归一化精确比对
    probe = text[:12]
    try:
        candidates = await db.search_memories(keyword=probe, category=category, limit=10)
    except Exception:
        candidates = []
    normalized = _normalize_memory_text(text)
    for m in candidates:
        if _normalize_memory_text(m.get("content", "")) == normalized:
            return

    await db.add_memory(content=text, category=category, tags="auto", source="auto_rule")
    logger.info("Auto memory captured: category=%s content=%s", category, text[:80])


class MemoryCreate(BaseModel):
    content: str
    category: str
    tags: str = ""
    source: str = ""


class MemoryUpdate(BaseModel):
    content: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[str] = None
    source: Optional[str] = None


class ChatRequest(BaseModel):
    session_id: str
    content: str
    model: Optional[str] = None
    api_key: Optional[str] = None
    base_url: Optional[str] = None


class SessionCreate(BaseModel):
    title: str = "新对话"
    model: str = "echo"


class SessionUpdate(BaseModel):
    title: Optional[str] = None
    model: Optional[str] = None


# ==================== 模型相关 ====================

@api.get("/models")
async def list_models():
    """获取所有已注册的模型 Provider"""
    return {"providers": model_router.list_providers()}


# ==================== 会话相关 ====================

@api.get("/sessions")
async def list_sessions():
    sessions = await db.list_sessions()
    return {"sessions": sessions}


@api.post("/sessions")
async def create_session(body: SessionCreate):
    session = await db.create_session(title=body.title, model=body.model)
    return {"session": session}


@api.get("/sessions/{session_id}")
async def get_session(session_id: str):
    session = await db.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    messages = await db.get_messages(session_id)
    return {"session": session, "messages": messages}


@api.patch("/sessions/{session_id}")
async def update_session(session_id: str, body: SessionUpdate):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="没有需要更新的字段")
    ok = await db.update_session(session_id, **updates)
    if not ok:
        raise HTTPException(status_code=404, detail="会话不存在")
    return {"ok": True}


@api.delete("/sessions/{session_id}")
async def delete_session(session_id: str):
    ok = await db.delete_session(session_id)
    if not ok:
        raise HTTPException(status_code=404, detail="会话不存在")
    return {"ok": True}


# ==================== 记忆相关 (Memories) ====================

@api.get("/memories")
async def list_memories(category: Optional[str] = None, limit: int = 50):
    memories = await db.list_memories(category=category, limit=limit)
    return {"memories": memories}


@api.post("/memories")
async def create_memory(body: MemoryCreate):
    memory = await db.add_memory(
        content=body.content,
        category=body.category,
        tags=body.tags,
        source=body.source,
    )
    return {"memory": memory}


@api.patch("/memories/{memory_id}")
async def update_memory(memory_id: str, body: MemoryUpdate):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="没有需要更新的字段")
    ok = await db.update_memory(memory_id, **updates)
    if not ok:
        raise HTTPException(status_code=404, detail="记忆不存在")
    return {"ok": True}


@api.delete("/memories/{memory_id}")
async def delete_memory(memory_id: str):
    ok = await db.delete_memory(memory_id)
    if not ok:
        raise HTTPException(status_code=404, detail="记忆不存在")
    return {"ok": True}


# ==================== 聊天核心 ====================

async def _resolve_adapter(body: ChatRequest):
    """
    ???????????????
    ????
    1. ????? api_key + base_url
    2. Supabase ???????????
    3. ?????????? chat adapter
    """
    allow_override = bool(settings.allow_client_provider_override)
    has_override = allow_override and bool(body.api_key and body.base_url)

    if has_override:
        config = ProviderConfig(
            name="custom_override",
            base_url=body.base_url,
            api_key=body.api_key,
            model=body.model or "",
        )
        return OpenAICompatAdapter(config), {
            "provider": "custom",
            "model": body.model or "unknown"
        }, {}

    if body.model and body.model == "echo":
        config = ProviderConfig(name="echo")
        return EchoAdapter(config), {"provider": "echo", "model": "echo"}, {}

    saved_provider = await _load_saved_chat_provider()
    if allow_override and saved_provider:
        config = ProviderConfig(
            name="saved_settings",
            base_url=saved_provider.get("base_url", ""),
            api_key=saved_provider.get("api_key", ""),
            model=saved_provider.get("model", ""),
        )
        override_kwargs = {}
        if body.model:
            override_kwargs["model"] = body.model
        return OpenAICompatAdapter(config), {
            "provider": saved_provider.get("provider", "saved"),
            "model": body.model or saved_provider.get("model", ""),
        }, override_kwargs

    adapter = model_router.get("chat")
    override_kwargs = {}
    if body.model:
        override_kwargs["model"] = body.model
    if allow_override and body.api_key:
        override_kwargs["api_key"] = body.api_key
    if allow_override and body.base_url:
        override_kwargs["base_url"] = body.base_url

    model_info = adapter.get_model_info()
    if body.model:
        model_info["model"] = body.model

    return adapter, model_info, override_kwargs



@api.post("/chat")
async def chat(body: ChatRequest):
    """
    核心聊天接口 —— SSE 流式返回

    流程:
    1. 保存用户消息到数据库
    2. 获取最近上下文
    3. 根据请求动态选择模型适配器
    4. 流式返回 + 保存完整回复
    """
    # 检查会话
    session = await db.get_session(body.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")

    # 1. 保存用户消息
    await db.add_message(body.session_id, "user", body.content)
    try:
        await _auto_capture_memory_from_user_text(body.content)
    except Exception as e:
        logger.warning(f"自动记忆提取失败: {e}")

    # 1.1 长会话摘要触发（增量摘要）
    try:
        await db.ensure_context_summary(
            session_id=body.session_id,
            trigger_messages=max(8, settings.summary_trigger_messages),
            keep_recent_messages=max(4, settings.summary_keep_recent_messages),
            min_batch_messages=max(2, settings.summary_min_batch_messages),
        )
    except Exception as e:
        logger.warning(f"上下文摘要触发失败: {e}")

    # 2. 获取最近上下文
    recent = await db.get_recent_messages(
        body.session_id,
        limit=max(1, settings.chat_recent_messages_limit),
    )

    # 3. 解析适配器
    resolved = await _resolve_adapter(body)
    if len(resolved) == 3:
        adapter, model_info, override_kwargs = resolved
    else:
        adapter, model_info = resolved
        override_kwargs = {}

    logger.info(f"Chat request → adapter={model_info}, overrides={list(override_kwargs.keys())}")

    # 4. SSE 流式返回
    async def event_generator():
        # 构建系统提示词
        system_prompt = await build_system_prompt(session_id=body.session_id)
        
        # 将系统消息插在最前面
        current_messages = [{"role": "system", "content": system_prompt}] + recent.copy()

        while True:
            full_response = []
            tool_calls_buffer = {}

            try:
                async for chunk in adapter.chat_stream(current_messages, **override_kwargs):
                    if isinstance(chunk, dict) and chunk.get("type") == "tool_call":
                        for tc in chunk["tool_calls"]:
                            idx = tc["index"]
                            if idx not in tool_calls_buffer:
                                tool_calls_buffer[idx] = {
                                    "id": tc.get("id"),
                                    "type": "function",
                                    "function": {"name": tc.get("function", {}).get("name", ""), "arguments": ""}
                                }
                            if "function" in tc and "arguments" in tc["function"]:
                                tool_calls_buffer[idx]["function"]["arguments"] += tc["function"]["arguments"]
                    elif isinstance(chunk, str):
                        full_response.append(chunk)
                        yield {"event": "message", "data": chunk}

            except Exception as e:
                logger.exception("Chat stream error")
                yield {"event": "error", "data": str(e)}
                return

            complete_text = "".join(full_response)

            if tool_calls_buffer:
                assistant_msg = {"role": "assistant", "content": complete_text, "tool_calls": list(tool_calls_buffer.values())}
                current_messages.append(assistant_msg)

                import json
                for tc in tool_calls_buffer.values():
                    func_name = tc["function"]["name"]
                    raw_args = tc["function"]["arguments"]
                    call_id = tc["id"]

                    try:
                        args = json.loads(raw_args) if raw_args else {}
                        if func_name in TOOL_EXECUTORS:
                            yield {"event": "message", "data": f"\n\n> 🔧 正在调用工具 `{func_name}`...\n"}
                            result = await execute_tool_with_guard(func_name, args)
                        else:
                            result = json.dumps({"error": f"Tool {func_name} not found"})
                    except Exception as ex:
                        result = json.dumps({"error": str(ex)})

                    # 控制工具返回长度，避免工具输出污染上下文并拉高 token 成本
                    if isinstance(result, str):
                        max_chars = max(80, settings.tool_result_max_chars)
                        if len(result) > max_chars:
                            result = result[:max_chars].rstrip() + "...(truncated)"

                    current_messages.append({
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": result
                    })

                continue

            if complete_text:
                await db.add_message(
                    body.session_id,
                    "assistant",
                    complete_text,
                    model=f"{model_info.get('provider', '?')}/{model_info.get('model', '?')}",
                )
                # 回复落库后再尝试一次摘要，避免对话越聊越长
                try:
                    await db.ensure_context_summary(
                        session_id=body.session_id,
                        trigger_messages=max(8, settings.summary_trigger_messages),
                        keep_recent_messages=max(4, settings.summary_keep_recent_messages),
                        min_batch_messages=max(2, settings.summary_min_batch_messages),
                    )
                except Exception as e:
                    logger.warning(f"上下文摘要触发失败(assistant): {e}")

            yield {"event": "done", "data": "[DONE]"}
            break

    return EventSourceResponse(event_generator())

