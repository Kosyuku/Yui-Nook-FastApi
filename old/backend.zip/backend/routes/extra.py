"""新增 API 路由 — 待办/便签/主动消息/历史/意识循环"""
from __future__ import annotations

import json
import logging
from urllib.parse import urljoin

import httpx
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

import database as db
import consciousness

logger = logging.getLogger(__name__)
extra_api = APIRouter(prefix="/api")


# ── Pydantic Models ──

class TodoCreate(BaseModel):
    content: str
    due_date: str = ""
    tags: str = ""

class TodoUpdate(BaseModel):
    content: Optional[str] = None
    status: Optional[str] = None
    due_date: Optional[str] = None
    tags: Optional[str] = None

class NoteCreate(BaseModel):
    content: str
    tags: str = ""
    date: Optional[str] = None


class AISettingsPayload(BaseModel):
    settings: dict[str, Any]


class ProviderDiscoverPayload(BaseModel):
    base_url: str
    api_key: str = ""


AI_SETTINGS_KEY = "ai_settings"


@extra_api.get("/settings/ai")
async def get_ai_settings():
    row = await db.get_setting(AI_SETTINGS_KEY)
    payload: dict[str, Any] = {}
    if row and row.get("value"):
        try:
            payload = json.loads(row["value"])
        except Exception:
            logger.warning("AI settings payload is not valid JSON, ignoring stored value")
    return {
        "settings": payload,
        "consciousness": consciousness.get_status(),
        "storage": "supabase",
    }


@extra_api.put("/settings/ai")
async def save_ai_settings(body: AISettingsPayload):
    row = await db.set_setting(AI_SETTINGS_KEY, json.dumps(body.settings, ensure_ascii=False))
    return {
        "ok": True,
        "updated_at": row.get("updated_at"),
        "storage": "supabase",
    }


@extra_api.post("/settings/ai/discover-models")
async def discover_provider_models(body: ProviderDiscoverPayload):
    base_url = (body.base_url or "").strip()
    if not base_url:
        raise HTTPException(status_code=400, detail="?? Base URL")

    endpoint = base_url.rstrip("/")
    if not endpoint.endswith("/models"):
        endpoint = f"{endpoint}/models"

    headers = {"Accept": "application/json"}
    if body.api_key:
        headers["Authorization"] = f"Bearer {body.api_key.strip()}"

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(endpoint, headers=headers)
    except Exception as exc:
        logger.warning("discover models request failed: %s", exc)
        raise HTTPException(status_code=502, detail="????????????????????????????")

    if resp.status_code >= 300:
        detail = "????????????????"
        try:
            payload = resp.json()
            if isinstance(payload, dict):
                detail = payload.get("error", {}).get("message") or payload.get("message") or detail
        except Exception:
            pass
        raise HTTPException(status_code=resp.status_code, detail=detail)

    try:
        payload = resp.json()
    except Exception as exc:
        logger.warning("discover models invalid json: %s", exc)
        raise HTTPException(status_code=502, detail="?????????? JSON?????????")

    items = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(items, list):
        raise HTTPException(status_code=502, detail="?????????????????????")

    models: list[str] = []
    for item in items:
        model_id = None
        if isinstance(item, dict):
            model_id = item.get("id") or item.get("name") or item.get("model") or item.get("slug")
        elif isinstance(item, str):
            model_id = item
        if model_id and model_id not in models:
            models.append(model_id)

    return {"models": models, "count": len(models), "endpoint": endpoint}


# ══════════ 待办 ══════════

@extra_api.get("/todos")
async def list_todos(status: Optional[str] = None, limit: int = 50):
    todos = await db.list_todos(status=status, limit=limit)
    return {"todos": todos}

@extra_api.post("/todos")
async def create_todo(body: TodoCreate):
    todo = await db.add_todo(content=body.content, due_date=body.due_date, tags=body.tags)
    return {"todo": todo}

@extra_api.patch("/todos/{todo_id}")
async def update_todo(todo_id: str, body: TodoUpdate):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="没有需要更新的字段")
    ok = await db.update_todo(todo_id, **updates)
    if not ok:
        raise HTTPException(status_code=404, detail="待办不存在")
    return {"ok": True}

@extra_api.delete("/todos/{todo_id}")
async def delete_todo(todo_id: str):
    ok = await db.delete_todo(todo_id)
    if not ok:
        raise HTTPException(status_code=404, detail="待办不存在")
    return {"ok": True}


# ══════════ 便签 ══════════

@extra_api.get("/notes")
async def list_notes(date: Optional[str] = None, tags: Optional[str] = None, limit: int = 50):
    notes = await db.list_notes(date=date, tags=tags, limit=limit)
    return {"notes": notes}

@extra_api.post("/notes")
async def create_note(body: NoteCreate):
    note = await db.add_note(content=body.content, tags=body.tags, date=body.date)
    return {"note": note}

@extra_api.delete("/notes/{note_id}")
async def delete_note(note_id: str):
    ok = await db.delete_note(note_id)
    if not ok:
        raise HTTPException(status_code=404, detail="便签不存在")
    return {"ok": True}


# ══════════ 主动消息 ══════════

@extra_api.get("/proactive")
async def get_proactive(limit: int = 10):
    """前端定时轮询此接口读取主动消息"""
    messages = await db.get_pending_proactive(limit=limit)
    return {"messages": messages}

@extra_api.post("/proactive/{msg_id}/read")
async def mark_proactive_read(msg_id: str):
    ok = await db.mark_proactive_read(msg_id)
    if not ok:
        raise HTTPException(status_code=404, detail="消息不存在")
    return {"ok": True}


# ══════════ 历史记录 ══════════

@extra_api.get("/history")
async def get_history(date: Optional[str] = None, limit: int = 100):
    """按日期获取聊天历史"""
    if not date:
        from datetime import datetime
        date = datetime.now().strftime("%Y-%m-%d")
    messages = await db.get_messages_by_date(date=date, limit=limit)
    return {"date": date, "messages": messages}


# ══════════ 意识循环 ══════════

@extra_api.get("/consciousness/status")
async def consciousness_status():
    return consciousness.get_status()

@extra_api.post("/consciousness/trigger")
async def consciousness_trigger():
    """手动触发一次意识循环"""
    await consciousness.run_once()
    return {"ok": True, "status": consciousness.get_status()}
