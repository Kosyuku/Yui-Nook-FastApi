"""
工具注册中心

所有工具在此统一注册 Schema + Executor 映射。
子模块工具 (weather, web_search 等) 也在此汇总。
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime
from typing import Any, Callable

import database as db
from config import settings

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════
# 1. 内置工具的 Python 实现
# ═══════════════════════════════════════════

async def execute_get_current_time(args: dict) -> str:
    now = datetime.now()
    weekday_cn = ["星期一","星期二","星期三","星期四","星期五","星期六","星期日"]
    return json.dumps({
        "current_time": now.isoformat(),
        "weekday": weekday_cn[now.weekday()],
        "formatted": now.strftime("%Y年%m月%d日 %H:%M"),
    }, ensure_ascii=False)


async def execute_add_memory(args: dict) -> str:
    content = args.get("content")
    category = args.get("category")
    tags = args.get("tags", "")
    try:
        res = await db.add_memory(content=content, category=category, tags=tags, source="agent_tool")
        return json.dumps({"status": "success", "memory_id": res["id"]}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


async def execute_list_memories(args: dict) -> str:
    category = args.get("category")
    limit = args.get("limit", 10)
    try:
        memories = await db.list_memories(category=category, limit=limit)
        return json.dumps({"status": "success", "count": len(memories), "memories": memories}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


async def execute_search_memories(args: dict) -> str:
    """关键词搜索记忆（全文匹配）"""
    keyword = args.get("keyword", "")
    category = args.get("category")
    limit = args.get("limit", 10)
    try:
        memories = await db.search_memories(keyword=keyword, category=category, limit=limit)
        return json.dumps({"status": "success", "count": len(memories), "memories": memories}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


async def execute_delete_memory(args: dict) -> str:
    memory_id = args.get("memory_id")
    try:
        ok = await db.delete_memory(memory_id)
        return json.dumps({"status": "success" if ok else "not_found"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


async def execute_update_memory(args: dict) -> str:
    memory_id = args.get("memory_id")
    updates = {}
    if "content" in args:
        updates["content"] = args["content"]
    if "category" in args:
        updates["category"] = args["category"]
    if "tags" in args:
        updates["tags"] = args["tags"]
    try:
        ok = await db.update_memory(memory_id, **updates)
        return json.dumps({"status": "success" if ok else "not_found"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


async def execute_get_memory_stats(args: dict) -> str:
    """统计各分类的记忆数量"""
    try:
        stats = await db.get_memory_stats()
        return json.dumps({"status": "success", "stats": stats}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


# ═══════════════════════════════════════════
# 2. OpenAI Function Calling Schema
# ═══════════════════════════════════════════

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "get_current_time",
            "description": "获取当前服务器时间（含日期、星期）。在需要知道现在几号、星期几、什么时间时调用。",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "add_memory",
            "description": "保存一条新记忆。当发现用户提到重要信息（偏好、经历、人设、计划）时调用。category 从 deep/daily/diary/writing 中选择。",
            "parameters": {
                "type": "object",
                "properties": {
                    "content": {"type": "string", "description": "记忆内容"},
                    "category": {"type": "string", "enum": ["deep", "daily", "diary", "writing"]},
                    "tags": {"type": "string", "description": "逗号分隔的标签"},
                },
                "required": ["content", "category"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_memories",
            "description": "按分类列出记忆。用于回顾深层人设、最近日常或过去日记。",
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {"type": "string", "enum": ["deep", "daily", "diary", "writing"]},
                    "limit": {"type": "integer", "description": "最大返回条数，默认10"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_memories",
            "description": "按关键词在记忆库中搜索。可选按分类过滤。",
            "parameters": {
                "type": "object",
                "properties": {
                    "keyword": {"type": "string", "description": "搜索关键词"},
                    "category": {"type": "string", "enum": ["deep", "daily", "diary", "writing"]},
                    "limit": {"type": "integer", "description": "最大返回条数，默认10"}
                },
                "required": ["keyword"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "delete_memory",
            "description": "按 ID 删除一条记忆。",
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_id": {"type": "string", "description": "要删除的记忆 ID"}
                },
                "required": ["memory_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "update_memory",
            "description": "更新一条记忆的内容、分类或标签。",
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_id": {"type": "string", "description": "记忆 ID"},
                    "content": {"type": "string", "description": "新的记忆内容"},
                    "category": {"type": "string", "enum": ["deep", "daily", "diary", "writing"]},
                    "tags": {"type": "string", "description": "新的标签"},
                },
                "required": ["memory_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_memory_stats",
            "description": "获取记忆库统计信息（各分类数量）。",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
]

# ═══════════════════════════════════════════
# 3. 工具执行器映射表
# ═══════════════════════════════════════════

TOOL_EXECUTORS: dict[str, Any] = {
    "get_current_time": execute_get_current_time,
    "add_memory": execute_add_memory,
    "list_memories": execute_list_memories,
    "search_memories": execute_search_memories,
    "delete_memory": execute_delete_memory,
    "update_memory": execute_update_memory,
    "get_memory_stats": execute_get_memory_stats,
}


def register_tool(schema: dict, executor: Callable):
    """动态注册一个新工具（供子模块调用）"""
    TOOLS_SCHEMA.append(schema)
    name = schema["function"]["name"]
    TOOL_EXECUTORS[name] = executor
    logger.info(f"已注册工具: {name}")


async def execute_tool_with_guard(name: str, args: dict) -> str:
    """
    统一工具执行入口：超时 + 重试 + 标准化错误 + 执行日志
    返回 JSON 字符串，确保可安全回灌给模型。
    """
    if name not in TOOL_EXECUTORS:
        return json.dumps({"status": "error", "type": "tool_not_found", "tool": name}, ensure_ascii=False)

    retries = max(0, settings.tool_retry_count)
    timeout_s = max(1.0, settings.tool_timeout_seconds)
    max_log_chars = max(60, settings.tool_log_max_result_chars)
    executor = TOOL_EXECUTORS[name]
    last_error = ""
    started = time.perf_counter()

    for attempt in range(retries + 1):
        try:
            result = await asyncio.wait_for(executor(args), timeout=timeout_s)
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            preview = str(result)
            if len(preview) > max_log_chars:
                preview = preview[:max_log_chars] + "..."
            logger.info(
                "Tool call success: tool=%s attempt=%s elapsed_ms=%s result_preview=%s",
                name,
                attempt + 1,
                elapsed_ms,
                preview,
            )
            if isinstance(result, str):
                return result
            return json.dumps({"status": "success", "result": result}, ensure_ascii=False)
        except asyncio.TimeoutError:
            last_error = f"timeout after {timeout_s}s"
            logger.warning("Tool call timeout: tool=%s attempt=%s", name, attempt + 1)
        except Exception as e:
            last_error = str(e)
            logger.warning("Tool call failed: tool=%s attempt=%s error=%s", name, attempt + 1, last_error)

    elapsed_ms = int((time.perf_counter() - started) * 1000)
    return json.dumps(
        {
            "status": "error",
            "type": "tool_execution_failed",
            "tool": name,
            "message": last_error or "unknown_error",
            "elapsed_ms": elapsed_ms,
            "retries": retries,
        },
        ensure_ascii=False,
    )


def init_external_tools():
    """初始化外部工具模块（天气、搜索等）"""
    try:
        from tools.weather import register as reg_weather
        reg_weather()
    except ImportError:
        logger.debug("天气工具未加载")
    try:
        from tools.web_search import register as reg_search
        reg_search()
    except ImportError:
        logger.debug("Web搜索工具未加载")
    try:
        from tools.fetch_url import register as reg_fetch
        reg_fetch()
    except ImportError:
        logger.debug("URL抓取工具未加载")
    try:
        from tools.calendar import register as reg_cal
        reg_cal()
    except ImportError:
        logger.debug("日历工具未加载")
    try:
        from tools.notes import register as reg_notes
        reg_notes()
    except ImportError:
        logger.debug("便签工具未加载")
    logger.info(f"工具注册完成，共 {len(TOOL_EXECUTORS)} 个工具")
