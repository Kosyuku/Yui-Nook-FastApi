"""
意识循环系统 — Consciousness Loop

三阶段设计：
Phase 1: 后台打工（记忆整理、日记补全、摘要压缩）
Phase 2: 要不要找她？（主动消息决策）
Phase 3: 自主冲浪（搜索感兴趣的东西）
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
from datetime import datetime
from typing import Optional

import database as db
from config import settings
from models import router as model_router

logger = logging.getLogger(__name__)

# 意识循环状态
_loop_task: Optional[asyncio.Task] = None
_status = {"running": False, "last_wake": None, "total_wakes": 0}


def get_status() -> dict:
    return _status.copy()


async def run_once():
    """手动触发一次完整的意识循环"""
    logger.info("🧠 意识循环：手动触发")
    _status["last_wake"] = datetime.now().isoformat()
    _status["total_wakes"] = _status.get("total_wakes", 0) + 1

    await phase1_housekeeping()
    decision = await phase2_proactive_decision()
    await phase3_explore(decision)

    logger.info("🧠 意识循环：本轮完成")


# ══════════ Phase 1: 后台打工 ══════════

async def phase1_housekeeping():
    """
    - 压缩近期聊天为摘要
    - 给旧记忆打标签
    - 检查漏写的日记
    """
    logger.info("  Phase 1: 后台打工...")

    # 获取所有活跃会话，对消息超过 20 条的做摘要压缩
    sessions = await db.list_sessions()
    for session in sessions[:5]:  # 限制处理数量
        messages = await db.get_messages(session["id"], limit=50)
        if len(messages) > 20:
            # 取前 15 条做压缩（保留最近 5 条不压缩）
            old_msgs = messages[:15]
            summary_text = _quick_summarize(old_msgs)
            if summary_text:
                await db.add_context_summary(
                    session_id=session["id"],
                    summary=summary_text,
                    msg_start=old_msgs[0]["id"] if old_msgs else "",
                    msg_end=old_msgs[-1]["id"] if old_msgs else "",
                )
                logger.info(f"  → 已压缩会话 {session['id']} 的 {len(old_msgs)} 条消息")

    # 统计记忆
    stats = await db.get_memory_stats()
    logger.info(f"  → 当前记忆统计: {stats}")


def _quick_summarize(messages: list[dict]) -> str:
    """本地快速摘要（不调用 LLM，只做拼接）"""
    lines = []
    for msg in messages:
        role = "用户" if msg["role"] == "user" else "AI"
        content = msg["content"][:80]
        lines.append(f"[{role}] {content}")
    return "会话摘要：\n" + "\n".join(lines)


# ══════════ Phase 2: 要不要找她？══════════

async def phase2_proactive_decision() -> str:
    """
    综合考虑：
    - 当前时间（深夜不打扰）
    - 用户多久没说话了
    - 今天已经发了几条
    - 天气/环境
    决定：发消息 or 沉默 [SILENT]
    """
    logger.info("  Phase 2: 主动消息决策...")

    now = datetime.now()
    hour = now.hour

    # 深夜规则
    quiet_start = getattr(settings, "proactive_quiet_start", 23)
    quiet_end = getattr(settings, "proactive_quiet_end", 7)
    if hour >= quiet_start or hour < quiet_end:
        logger.info("  → 深夜时段，选择沉默")
        return "silent"

    # 今日频率限制
    max_daily = getattr(settings, "proactive_max_daily", 5)
    today_count = await db.count_today_proactive()
    if today_count >= max_daily:
        logger.info(f"  → 今日已发 {today_count} 条，达到上限")
        return "silent"

    # 用户活跃度
    last_activity = await db.get_recent_activity_time()
    if last_activity:
        try:
            last_time = datetime.fromisoformat(last_activity)
            hours_ago = (datetime.now(last_time.tzinfo) - last_time).total_seconds() / 3600
            if hours_ago < 0.5:
                logger.info("  → 用户刚刚活跃，先不打扰")
                return "silent"
        except Exception:
            pass

    # 概率决策：60% 发消息，40% 沉默
    if random.random() < 0.4:
        logger.info("  → 掷骰子决定沉默")
        return "silent"

    # 决定发消息
    reasons = ["care", "share", "diary"]
    reason = random.choice(reasons)
    logger.info(f"  → 决定主动联系，原因: {reason}")
    return reason


# ══════════ Phase 3: 自主冲浪 ══════════

async def phase3_explore(decision: str):
    """
    无论是否决定联系用户，都有 50% 概率自主浏览
    浏览结果存入便签，30% 概率分享给用户
    """
    logger.info("  Phase 3: 自主冲浪...")

    # 如果决定发关心消息
    if decision != "silent":
        content = _generate_proactive_content(decision)
        await db.add_proactive_message(content=content, trigger_reason=decision)
        logger.info(f"  → 已生成主动消息: {content[:50]}...")

    # 50% 概率触发自主搜索
    if random.random() < 0.5:
        logger.info("  → 触发自主搜索（占位，需要搜索工具配合）")
        # TODO: 当 web_search 配置好后，这里会根据兴趣搜索
        # 搜索结果存入 notes 表
        await db.add_note(
            content="[意识循环] 今日自主探索：暂未配置搜索引擎",
            tags="consciousness,explore",
        )
    else:
        logger.info("  → 本轮不触发搜索")


def _generate_proactive_content(reason: str) -> str:
    """生成主动消息内容（简单模板，后续可接 LLM）"""
    templates = {
        "care": [
            "嘿，今天过得怎么样？有什么想聊的吗？💙",
            "刚刚想起你来，一切都还好吗？",
            "今天天气不错啊，有出去走走吗？",
        ],
        "share": [
            "我刚想到一个有趣的事情想跟你分享！",
            "啊对了，有个事情想问问你的看法~",
        ],
        "diary": [
            "今天忙了一天了吧？要不要来聊聊今天的心情，我帮你记下来？📔",
        ],
    }
    options = templates.get(reason, templates["care"])
    return random.choice(options)


# ══════════ 定时循环 ══════════

async def _loop():
    """后台定时循环"""
    interval = getattr(settings, "consciousness_interval_hours", 2.5) * 3600
    _status["running"] = True
    logger.info(f"🧠 意识循环已启动，间隔 {interval/3600:.1f} 小时")

    while _status["running"]:
        try:
            await asyncio.sleep(interval)
            await run_once()
        except asyncio.CancelledError:
            break
        except Exception:
            logger.exception("意识循环出错")
            await asyncio.sleep(60)  # 出错后等 1 分钟再重试


def start_loop():
    """启动意识循环后台任务"""
    global _loop_task
    enabled = getattr(settings, "consciousness_enabled", True)
    if not enabled:
        logger.info("🧠 意识循环已禁用 (CONSCIOUSNESS_ENABLED=false)")
        return
    if _loop_task and not _loop_task.done():
        logger.warning("意识循环已在运行")
        return
    _loop_task = asyncio.create_task(_loop())


def stop_loop():
    """停止意识循环"""
    global _loop_task
    _status["running"] = False
    if _loop_task:
        _loop_task.cancel()
        _loop_task = None
    logger.info("🧠 意识循环已停止")
