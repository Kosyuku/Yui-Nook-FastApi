"""SQLite 数据库层 — 会话 + 消息存储"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any

import aiosqlite
import httpx

from config import settings

_db: aiosqlite.Connection | None = None
logger = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id          TEXT PRIMARY KEY,
    title       TEXT NOT NULL DEFAULT '新对话',
    model       TEXT NOT NULL DEFAULT 'echo',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
    id          TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    role        TEXT NOT NULL,
    content     TEXT NOT NULL,
    model       TEXT DEFAULT '',
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_session
    ON messages(session_id, created_at);

CREATE TABLE IF NOT EXISTS memories (
    id          TEXT PRIMARY KEY,
    content     TEXT NOT NULL,
    category    TEXT NOT NULL,
    tags        TEXT DEFAULT '',
    source      TEXT DEFAULT '',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memories_category
    ON memories(category, updated_at);

-- ========== 新增表 ==========

CREATE TABLE IF NOT EXISTS context_summaries (
    id              TEXT PRIMARY KEY,
    session_id      TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    summary         TEXT NOT NULL,
    msg_range_start TEXT,
    msg_range_end   TEXT,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS todos (
    id          TEXT PRIMARY KEY,
    content     TEXT NOT NULL,
    due_date    TEXT DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'pending',  -- pending | done | cancelled
    tags        TEXT DEFAULT '',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notes (
    id          TEXT PRIMARY KEY,
    content     TEXT NOT NULL,
    tags        TEXT DEFAULT '',
    date        TEXT NOT NULL,  -- YYYY-MM-DD
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_notes_date ON notes(date);

CREATE TABLE IF NOT EXISTS proactive_messages (
    id              TEXT PRIMARY KEY,
    content         TEXT NOT NULL,
    trigger_reason  TEXT DEFAULT '',  -- care | share | diary | silent
    status          TEXT NOT NULL DEFAULT 'pending',  -- pending | delivered | read
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_logs (
    id          TEXT PRIMARY KEY,
    memory_id   TEXT,
    action      TEXT NOT NULL,  -- create | update | delete | access
    detail      TEXT DEFAULT '',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_settings (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


def _use_supabase_memory() -> bool:
    return getattr(settings, "memory_backend", "sqlite").lower() == "supabase"


def _supabase_headers(prefer_representation: bool = False) -> dict[str, str]:
    key = settings.supabase_key.strip()
    if not settings.supabase_url or not key:
        raise RuntimeError("Supabase memories backend is enabled but SUPABASE_URL/SUPABASE_KEY is missing")
    headers = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    if prefer_representation:
        headers["Prefer"] = "return=representation"
    return headers


def _supabase_memories_endpoint() -> str:
    return f"{settings.supabase_url}/rest/v1/{settings.supabase_memories_table}"


def _supabase_settings_endpoint() -> str:
    return f"{settings.supabase_url}/rest/v1/{settings.supabase_settings_table}"


def _use_supabase_settings() -> bool:
    return bool(settings.supabase_url and settings.supabase_key)


async def _supabase_get_setting_from_table(key: str) -> dict[str, Any] | None:
    params = {"select": "key,value,updated_at", "key": f"eq.{key}", "limit": "1"}
    async with httpx.AsyncClient(timeout=20.0, trust_env=settings.supabase_httpx_trust_env) as client:
        resp = await client.get(_supabase_settings_endpoint(), headers=_supabase_headers(), params=params)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase get_setting(table) failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
        return rows[0] if rows else None


async def _supabase_set_setting_to_table(key: str, value: str) -> dict[str, Any]:
    now = _now()
    payload = {"key": key, "value": value, "updated_at": now}
    headers = _supabase_headers(True)
    headers["Prefer"] = "resolution=merge-duplicates,return=representation"
    params = {"on_conflict": "key"}
    async with httpx.AsyncClient(timeout=20.0, trust_env=settings.supabase_httpx_trust_env) as client:
        resp = await client.post(_supabase_settings_endpoint(), headers=headers, params=params, json=payload)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase set_setting(table) failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
        return rows[0] if rows else payload


async def _supabase_get_setting_from_memory(key: str) -> dict[str, Any] | None:
    memory_id = f"cfg_{key}"
    params = {"select": "id,content,updated_at", "id": f"eq.{memory_id}", "limit": "1"}
    async with httpx.AsyncClient(timeout=20.0, trust_env=settings.supabase_httpx_trust_env) as client:
        resp = await client.get(_supabase_memories_endpoint(), headers=_supabase_headers(), params=params)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase get_setting(memory) failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
        if not rows:
            return None
        row = rows[0]
        return {"key": key, "value": row.get("content", ""), "updated_at": row.get("updated_at", "")}


async def _supabase_set_setting_to_memory(key: str, value: str) -> dict[str, Any]:
    memory_id = f"cfg_{key}"
    now = _now()
    payload = {
        "id": memory_id,
        "content": value,
        "category": "system_config",
        "tags": f"settings,{key}",
        "source": "app_settings",
        "created_at": now,
        "updated_at": now,
    }
    headers = _supabase_headers(True)
    headers["Prefer"] = "resolution=merge-duplicates,return=representation"
    params = {"on_conflict": "id"}
    async with httpx.AsyncClient(timeout=20.0, trust_env=settings.supabase_httpx_trust_env) as client:
        resp = await client.post(_supabase_memories_endpoint(), headers=headers, params=params, json=payload)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase set_setting(memory) failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
        row = rows[0] if rows else payload
        return {"key": key, "value": row.get("content", value), "updated_at": row.get("updated_at", now)}


async def _supabase_get_setting(key: str) -> dict[str, Any] | None:
    try:
        return await _supabase_get_setting_from_table(key)
    except Exception as exc:
        logger.warning("Supabase settings table unavailable, fallback to memories: %s", exc)
        return await _supabase_get_setting_from_memory(key)


async def _supabase_set_setting(key: str, value: str) -> dict[str, Any]:
    try:
        return await _supabase_set_setting_to_table(key, value)
    except Exception as exc:
        logger.warning("Supabase settings table unavailable, fallback to memories: %s", exc)
        return await _supabase_set_setting_to_memory(key, value)


async def _supabase_add_memory(content: str, category: str, tags: str = "", source: str = "") -> dict[str, Any]:
    mid = _new_id()
    now = _now()
    payload = {
        "id": mid,
        "content": content,
        "category": category,
        "tags": tags,
        "source": source,
        "created_at": now,
        "updated_at": now,
    }
    async with httpx.AsyncClient(
        timeout=20.0,
        trust_env=settings.supabase_httpx_trust_env,
    ) as client:
        resp = await client.post(_supabase_memories_endpoint(), headers=_supabase_headers(True), json=payload)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase add_memory failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
        return rows[0] if rows else payload


async def _supabase_list_memories(category: str = None, limit: int = 50) -> list[dict[str, Any]]:
    params = {"select": "*", "order": "updated_at.desc", "limit": str(limit)}
    if category:
        params["category"] = f"eq.{category}"
    async with httpx.AsyncClient(
        timeout=20.0,
        trust_env=settings.supabase_httpx_trust_env,
    ) as client:
        resp = await client.get(_supabase_memories_endpoint(), headers=_supabase_headers(), params=params)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase list_memories failed: {resp.status_code} {resp.text[:200]}")
        return resp.json()


async def _supabase_update_memory(memory_id: str, **kwargs) -> bool:
    if not kwargs:
        return False
    payload = dict(kwargs)
    payload["updated_at"] = _now()
    params = {"id": f"eq.{memory_id}"}
    async with httpx.AsyncClient(
        timeout=20.0,
        trust_env=settings.supabase_httpx_trust_env,
    ) as client:
        resp = await client.patch(
            _supabase_memories_endpoint(),
            headers=_supabase_headers(True),
            params=params,
            json=payload,
        )
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase update_memory failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
        return len(rows) > 0


async def _supabase_delete_memory(memory_id: str) -> bool:
    params = {"id": f"eq.{memory_id}"}
    async with httpx.AsyncClient(
        timeout=20.0,
        trust_env=settings.supabase_httpx_trust_env,
    ) as client:
        resp = await client.delete(_supabase_memories_endpoint(), headers=_supabase_headers(True), params=params)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase delete_memory failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
        return len(rows) > 0


async def _supabase_search_memories(keyword: str, category: str = None, limit: int = 10) -> list[dict[str, Any]]:
    params = {
        "select": "*",
        "content": f"ilike.*{keyword}*",
        "order": "updated_at.desc",
        "limit": str(limit),
    }
    if category:
        params["category"] = f"eq.{category}"
    async with httpx.AsyncClient(
        timeout=20.0,
        trust_env=settings.supabase_httpx_trust_env,
    ) as client:
        resp = await client.get(_supabase_memories_endpoint(), headers=_supabase_headers(), params=params)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase search_memories failed: {resp.status_code} {resp.text[:200]}")
        return resp.json()


async def _supabase_get_memory_stats() -> dict[str, int]:
    params = {"select": "category", "limit": "5000"}
    async with httpx.AsyncClient(
        timeout=20.0,
        trust_env=settings.supabase_httpx_trust_env,
    ) as client:
        resp = await client.get(_supabase_memories_endpoint(), headers=_supabase_headers(), params=params)
        if resp.status_code >= 300:
            raise RuntimeError(f"Supabase get_memory_stats failed: {resp.status_code} {resp.text[:200]}")
        rows = resp.json()
    stats: dict[str, int] = {}
    for row in rows:
        cat = row.get("category", "unknown")
        stats[cat] = stats.get(cat, 0) + 1
    return stats


async def get_db() -> aiosqlite.Connection:
    """获取数据库连接（单例）"""
    global _db
    if _db is None:
        _db = await aiosqlite.connect(settings.database_path)
        _db.row_factory = aiosqlite.Row
        await _db.execute("PRAGMA journal_mode=WAL")
        await _db.execute("PRAGMA foreign_keys=ON")
        await _db.executescript(SCHEMA)
        await _db.commit()
    return _db


async def close_db():
    global _db
    if _db:
        await _db.close()
        _db = None


# ==================== ???? ====================

async def get_setting(key: str) -> dict[str, Any] | None:
    if _use_supabase_settings():
        return await _supabase_get_setting(key)
    db = await get_db()
    cursor = await db.execute("SELECT key, value, updated_at FROM app_settings WHERE key = ?", (key,))
    row = await cursor.fetchone()
    if not row:
        return None
    return dict(row)


async def set_setting(key: str, value: str) -> dict[str, Any]:
    if _use_supabase_settings():
        return await _supabase_set_setting(key, value)
    db = await get_db()
    now = _now()
    await db.execute(
        """
        INSERT INTO app_settings (key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
        """,
        (key, value, now),
    )
    await db.commit()
    return {"key": key, "value": value, "updated_at": now}


# ==================== 会话 ====================

async def create_session(title: str = "新对话", model: str = "echo") -> dict[str, Any]:
    db = await get_db()
    sid = _new_id()
    now = _now()
    await db.execute(
        "INSERT INTO sessions (id, title, model, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
        (sid, title, model, now, now),
    )
    await db.commit()
    return {"id": sid, "title": title, "model": model, "created_at": now, "updated_at": now}


async def list_sessions() -> list[dict[str, Any]]:
    db = await get_db()
    cursor = await db.execute("SELECT * FROM sessions ORDER BY updated_at DESC")
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def get_session(session_id: str) -> dict[str, Any] | None:
    db = await get_db()
    cursor = await db.execute("SELECT * FROM sessions WHERE id = ?", (session_id,))
    row = await cursor.fetchone()
    return dict(row) if row else None


async def update_session(session_id: str, **kwargs) -> bool:
    db = await get_db()
    kwargs["updated_at"] = _now()
    sets = ", ".join(f"{k} = ?" for k in kwargs)
    vals = list(kwargs.values()) + [session_id]
    result = await db.execute(f"UPDATE sessions SET {sets} WHERE id = ?", vals)
    await db.commit()
    return result.rowcount > 0


async def delete_session(session_id: str) -> bool:
    db = await get_db()
    result = await db.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
    await db.commit()
    return result.rowcount > 0


# ==================== 消息 ====================

async def add_message(session_id: str, role: str, content: str, model: str = "") -> dict[str, Any]:
    db = await get_db()
    mid = _new_id()
    now = _now()
    await db.execute(
        "INSERT INTO messages (id, session_id, role, content, model, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (mid, session_id, role, content, model, now),
    )
    # 更新会话时间
    await db.execute("UPDATE sessions SET updated_at = ? WHERE id = ?", (now, session_id))
    await db.commit()
    return {"id": mid, "session_id": session_id, "role": role, "content": content, "model": model, "created_at": now}


async def get_messages(session_id: str, limit: int = 50) -> list[dict[str, Any]]:
    db = await get_db()
    cursor = await db.execute(
        "SELECT * FROM messages WHERE session_id = ? ORDER BY created_at ASC LIMIT ?",
        (session_id, limit),
    )
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def get_recent_messages(session_id: str, limit: int = 12) -> list[dict[str, str]]:
    """获取最近N条消息，格式化为 OpenAI messages 格式"""
    db = await get_db()
    cursor = await db.execute(
        "SELECT role, content FROM messages WHERE session_id = ? ORDER BY created_at DESC LIMIT ?",
        (session_id, limit),
    )
    rows = await cursor.fetchall()
    return [{"role": row["role"], "content": row["content"]} for row in reversed(rows)]


# ==================== 记忆 (Semantic Memory) ====================

async def add_memory(content: str, category: str, tags: str = "", source: str = "") -> dict[str, Any]:
    if _use_supabase_memory():
        return await _supabase_add_memory(content=content, category=category, tags=tags, source=source)
    db = await get_db()
    mid = _new_id()
    now = _now()
    await db.execute(
        "INSERT INTO memories (id, content, category, tags, source, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (mid, content, category, tags, source, now, now),
    )
    await db.commit()
    return {"id": mid, "content": content, "category": category, "tags": tags, "source": source, "created_at": now, "updated_at": now}


async def list_memories(category: str = None, limit: int = 50) -> list[dict[str, Any]]:
    if _use_supabase_memory():
        return await _supabase_list_memories(category=category, limit=limit)
    db = await get_db()
    if category:
        cursor = await db.execute("SELECT * FROM memories WHERE category = ? ORDER BY updated_at DESC LIMIT ?", (category, limit))
    else:
        cursor = await db.execute("SELECT * FROM memories ORDER BY updated_at DESC LIMIT ?", (limit,))
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def update_memory(memory_id: str, **kwargs) -> bool:
    if _use_supabase_memory():
        return await _supabase_update_memory(memory_id, **kwargs)
    db = await get_db()
    kwargs["updated_at"] = _now()
    sets = ", ".join(f"{k} = ?" for k in kwargs)
    vals = list(kwargs.values()) + [memory_id]
    result = await db.execute(f"UPDATE memories SET {sets} WHERE id = ?", vals)
    await db.commit()
    return result.rowcount > 0


async def delete_memory(memory_id: str) -> bool:
    if _use_supabase_memory():
        return await _supabase_delete_memory(memory_id)
    db = await get_db()
    result = await db.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
    await db.commit()
    return result.rowcount > 0


async def search_memories(keyword: str, category: str = None, limit: int = 10) -> list[dict[str, Any]]:
    """关键词搜索记忆（SQLite LIKE 全文匹配）"""
    if _use_supabase_memory():
        return await _supabase_search_memories(keyword=keyword, category=category, limit=limit)
    db = await get_db()
    query = "SELECT * FROM memories WHERE content LIKE ?"
    params = [f"%{keyword}%"]
    if category:
        query += " AND category = ?"
        params.append(category)
    query += " ORDER BY updated_at DESC LIMIT ?"
    params.append(limit)
    cursor = await db.execute(query, params)
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def get_memory_stats() -> dict[str, int]:
    """统计各分类的记忆数量"""
    if _use_supabase_memory():
        return await _supabase_get_memory_stats()
    db = await get_db()
    cursor = await db.execute("SELECT category, COUNT(*) as count FROM memories GROUP BY category")
    rows = await cursor.fetchall()
    return {row["category"]: row["count"] for row in rows}


# ==================== 上下文摘要 ====================

async def add_context_summary(session_id: str, summary: str, msg_start: str = "", msg_end: str = "") -> dict[str, Any]:
    db = await get_db()
    sid = _new_id()
    now = _now()
    await db.execute(
        "INSERT INTO context_summaries (id, session_id, summary, msg_range_start, msg_range_end, created_at) VALUES (?,?,?,?,?,?)",
        (sid, session_id, summary, msg_start, msg_end, now),
    )
    await db.commit()
    return {"id": sid, "session_id": session_id, "summary": summary, "created_at": now}


async def get_context_summaries(session_id: str, limit: int = 5) -> list[dict[str, Any]]:
    db = await get_db()
    cursor = await db.execute(
        "SELECT * FROM context_summaries WHERE session_id = ? ORDER BY created_at DESC LIMIT ?",
        (session_id, limit),
    )
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


def _quick_summarize_messages(messages: list[dict[str, Any]], max_chars_per_line: int = 120) -> str:
    lines: list[str] = []
    for msg in messages:
        role = msg.get("role", "")
        role_cn = "用户" if role == "user" else "AI"
        content = (msg.get("content") or "").replace("\n", " ").strip()
        if len(content) > max_chars_per_line:
            content = content[:max_chars_per_line].rstrip() + "..."
        lines.append(f"[{role_cn}] {content}")
    return "会话摘要：\n" + "\n".join(lines)


async def ensure_context_summary(
    session_id: str,
    trigger_messages: int = 24,
    keep_recent_messages: int = 12,
    min_batch_messages: int = 8,
) -> bool:
    """为长会话增量生成摘要，避免上下文无限增长。"""
    db = await get_db()
    cursor = await db.execute(
        "SELECT id, role, content, created_at FROM messages WHERE session_id = ? ORDER BY created_at ASC",
        (session_id,),
    )
    rows = await cursor.fetchall()
    messages = [dict(r) for r in rows]
    if len(messages) < max(trigger_messages, keep_recent_messages + min_batch_messages):
        return False

    last_end_id = ""
    c2 = await db.execute(
        "SELECT msg_range_end FROM context_summaries WHERE session_id = ? ORDER BY created_at DESC LIMIT 1",
        (session_id,),
    )
    last = await c2.fetchone()
    if last and last["msg_range_end"]:
        last_end_id = last["msg_range_end"]

    start_idx = 0
    if last_end_id:
        for i, msg in enumerate(messages):
            if msg["id"] == last_end_id:
                start_idx = i + 1
                break

    new_messages = messages[start_idx:]
    if len(new_messages) <= keep_recent_messages:
        return False

    to_summarize = new_messages[:-keep_recent_messages]
    if len(to_summarize) < min_batch_messages:
        return False

    summary_text = _quick_summarize_messages(to_summarize)
    await add_context_summary(
        session_id=session_id,
        summary=summary_text,
        msg_start=to_summarize[0]["id"],
        msg_end=to_summarize[-1]["id"],
    )
    logger.info(
        "Context summary created: session=%s batch=%s keep_recent=%s",
        session_id,
        len(to_summarize),
        keep_recent_messages,
    )
    return True


# ==================== 待办 (Todos) ====================

async def add_todo(content: str, due_date: str = "", tags: str = "") -> dict[str, Any]:
    db = await get_db()
    tid = _new_id()
    now = _now()
    await db.execute(
        "INSERT INTO todos (id, content, due_date, status, tags, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
        (tid, content, due_date, "pending", tags, now, now),
    )
    await db.commit()
    return {"id": tid, "content": content, "due_date": due_date, "status": "pending", "tags": tags, "created_at": now}


async def list_todos(status: str = None, limit: int = 50) -> list[dict[str, Any]]:
    db = await get_db()
    if status:
        cursor = await db.execute("SELECT * FROM todos WHERE status = ? ORDER BY created_at DESC LIMIT ?", (status, limit))
    else:
        cursor = await db.execute("SELECT * FROM todos ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def update_todo(todo_id: str, **kwargs) -> bool:
    db = await get_db()
    kwargs["updated_at"] = _now()
    sets = ", ".join(f"{k} = ?" for k in kwargs)
    vals = list(kwargs.values()) + [todo_id]
    result = await db.execute(f"UPDATE todos SET {sets} WHERE id = ?", vals)
    await db.commit()
    return result.rowcount > 0


async def delete_todo(todo_id: str) -> bool:
    db = await get_db()
    result = await db.execute("DELETE FROM todos WHERE id = ?", (todo_id,))
    await db.commit()
    return result.rowcount > 0


# ==================== 便签 (Notes) ====================

async def add_note(content: str, tags: str = "", date: str = None) -> dict[str, Any]:
    db = await get_db()
    nid = _new_id()
    now = _now()
    if not date:
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    await db.execute(
        "INSERT INTO notes (id, content, tags, date, created_at) VALUES (?,?,?,?,?)",
        (nid, content, tags, date, now),
    )
    await db.commit()
    return {"id": nid, "content": content, "tags": tags, "date": date, "created_at": now}


async def list_notes(date: str = None, tags: str = None, limit: int = 50) -> list[dict[str, Any]]:
    db = await get_db()
    query = "SELECT * FROM notes"
    params = []
    conditions = []
    if date:
        conditions.append("date = ?")
        params.append(date)
    if tags:
        conditions.append("tags LIKE ?")
        params.append(f"%{tags}%")
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    cursor = await db.execute(query, params)
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def delete_note(note_id: str) -> bool:
    db = await get_db()
    result = await db.execute("DELETE FROM notes WHERE id = ?", (note_id,))
    await db.commit()
    return result.rowcount > 0


# ==================== 主动消息 ====================

async def add_proactive_message(content: str, trigger_reason: str = "") -> dict[str, Any]:
    db = await get_db()
    pid = _new_id()
    now = _now()
    await db.execute(
        "INSERT INTO proactive_messages (id, content, trigger_reason, status, created_at) VALUES (?,?,?,?,?)",
        (pid, content, trigger_reason, "pending", now),
    )
    await db.commit()
    return {"id": pid, "content": content, "trigger_reason": trigger_reason, "status": "pending", "created_at": now}


async def get_pending_proactive(limit: int = 10) -> list[dict[str, Any]]:
    db = await get_db()
    cursor = await db.execute(
        "SELECT * FROM proactive_messages WHERE status = 'pending' ORDER BY created_at DESC LIMIT ?",
        (limit,),
    )
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def mark_proactive_read(msg_id: str) -> bool:
    db = await get_db()
    result = await db.execute(
        "UPDATE proactive_messages SET status = 'read' WHERE id = ?",
        (msg_id,),
    )
    await db.commit()
    return result.rowcount > 0


async def count_today_proactive() -> int:
    """今日已发送的主动消息数量"""
    db = await get_db()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    cursor = await db.execute(
        "SELECT COUNT(*) as cnt FROM proactive_messages WHERE created_at LIKE ?",
        (f"{today}%",),
    )
    row = await cursor.fetchone()
    return row["cnt"] if row else 0


# ==================== 记忆日志 ====================

async def add_memory_log(memory_id: str, action: str, detail: str = ""):
    db = await get_db()
    lid = _new_id()
    now = _now()
    await db.execute(
        "INSERT INTO memory_logs (id, memory_id, action, detail, created_at) VALUES (?,?,?,?,?)",
        (lid, memory_id, action, detail, now),
    )
    await db.commit()


# ==================== 历史消息聚合 ====================

async def get_messages_by_date(date: str, limit: int = 100) -> list[dict[str, Any]]:
    """按日期获取消息 (date 格式: YYYY-MM-DD)"""
    db = await get_db()
    cursor = await db.execute(
        "SELECT m.*, s.title as session_title FROM messages m "
        "LEFT JOIN sessions s ON m.session_id = s.id "
        "WHERE m.created_at LIKE ? ORDER BY m.created_at ASC LIMIT ?",
        (f"{date}%", limit),
    )
    rows = await cursor.fetchall()
    return [dict(row) for row in rows]


async def get_recent_activity_time() -> str:
    """获取用户最近一次发言的时间"""
    db = await get_db()
    cursor = await db.execute(
        "SELECT created_at FROM messages WHERE role = 'user' ORDER BY created_at DESC LIMIT 1"
    )
    row = await cursor.fetchone()
    return row["created_at"] if row else ""
