"""Pyro-Gemini 网关配置"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from dotenv import load_dotenv

# 加载 .env
load_dotenv()


@dataclass
class ProviderConfig:
    """单个模型 Provider 的配置"""
    name: str
    base_url: str = ""
    api_key: str = ""
    model: str = ""

    @property
    def enabled(self) -> bool:
        return self.name == "echo" or bool(self.base_url and self.api_key and self.model)


@dataclass
class AppConfig:
    """应用全局配置"""
    host: str = "127.0.0.1"
    port: int = 8000
    database_path: str = "./data/gateway.db"
    cors_allow_origins: str = "*"
    internal_api_token: str = ""
    memory_backend: str = "sqlite"
    supabase_url: str = ""
    supabase_key: str = ""
    supabase_memories_table: str = "memories"
    # 与 httpx trust_env 一致：默认 false（忽略 HTTP_PROXY，避免代理导致 TLS 失败）
    supabase_httpx_trust_env: bool = False

    # 聊天 Provider
    chat: ProviderConfig = field(default_factory=lambda: ProviderConfig(name="echo"))
    # 压缩/总结 Provider（可以用便宜模型）
    summary: ProviderConfig = field(default_factory=lambda: ProviderConfig(name="echo"))

    # ── 人设 ──
    persona_name: str = "Pyro"
    persona_description: str = ""

    # ── 天气 ──
    weather_api_key: str = ""
    default_city: str = "Shanghai"

    # ── Web 搜索 ──
    search_engine: str = "searxng"
    search_api_key: str = ""
    searxng_url: str = ""

    # ── 意识循环 ──
    consciousness_enabled: bool = True
    consciousness_interval_hours: float = 2.5
    proactive_max_daily: int = 5
    proactive_quiet_start: int = 23
    proactive_quiet_end: int = 7

    # ── Token / Prompt 预算 ──
    chat_recent_messages_limit: int = 12
    tool_result_max_chars: int = 1200
    prompt_memory_items: int = 5
    prompt_memory_item_max_chars: int = 180
    prompt_summary_items: int = 2
    prompt_summary_item_max_chars: int = 260
    prompt_tool_count_max: int = 8
    prompt_tool_desc_max_chars: int = 80
    summary_trigger_messages: int = 24
    summary_keep_recent_messages: int = 12
    summary_min_batch_messages: int = 8
    tool_timeout_seconds: float = 15.0
    tool_retry_count: int = 1
    tool_log_max_result_chars: int = 200
    memory_auto_extract_enabled: bool = True
    memory_auto_extract_min_chars: int = 8
    memory_auto_extract_max_chars: int = 220
    memory_retrieval_top_k: int = 6
    memory_retrieval_keyword_count: int = 4
    allow_client_provider_override: bool = True

    @classmethod
    def from_env(cls) -> "AppConfig":
        """从环境变量加载配置"""
        config = cls(
            host=os.getenv("HOST", "127.0.0.1"),
            port=int(os.getenv("PORT", "8000")),
            database_path=os.getenv("DATABASE_PATH", "./data/gateway.db"),
            cors_allow_origins=os.getenv("CORS_ALLOW_ORIGINS", "*"),
            internal_api_token=os.getenv("INTERNAL_API_TOKEN", ""),
            memory_backend=os.getenv("MEMORY_BACKEND", "sqlite").lower(),
            supabase_url=os.getenv("SUPABASE_URL", "").rstrip("/"),
            supabase_key=os.getenv("SUPABASE_KEY", ""),
            supabase_memories_table=os.getenv("SUPABASE_MEMORIES_TABLE", "memories"),
            supabase_settings_table=os.getenv("SUPABASE_SETTINGS_TABLE", "app_settings"),
            supabase_httpx_trust_env=os.getenv("SUPABASE_HTTP_TRUST_ENV", "0").lower()
            in ("1", "true", "yes"),
            chat=ProviderConfig(
                name=os.getenv("CHAT_PROVIDER", "echo"),
                base_url=os.getenv("CHAT_BASE_URL", ""),
                api_key=os.getenv("CHAT_API_KEY", ""),
                model=os.getenv("CHAT_MODEL", ""),
            ),
            summary=ProviderConfig(
                name=os.getenv("SUMMARY_PROVIDER", "echo"),
                base_url=os.getenv("SUMMARY_BASE_URL", ""),
                api_key=os.getenv("SUMMARY_API_KEY", ""),
                model=os.getenv("SUMMARY_MODEL", ""),
            ),
            # 人设
            persona_name=os.getenv("PERSONA_NAME", "Pyro"),
            persona_description=os.getenv("PERSONA_DESCRIPTION", ""),
            # 天气
            weather_api_key=os.getenv("WEATHER_API_KEY", ""),
            default_city=os.getenv("DEFAULT_CITY", "Shanghai"),
            # 搜索
            search_engine=os.getenv("SEARCH_ENGINE", "searxng"),
            search_api_key=os.getenv("SEARCH_API_KEY", ""),
            searxng_url=os.getenv("SEARXNG_URL", ""),
            # 意识循环
            consciousness_enabled=os.getenv("CONSCIOUSNESS_ENABLED", "true").lower() == "true",
            consciousness_interval_hours=float(os.getenv("CONSCIOUSNESS_INTERVAL_HOURS", "2.5")),
            proactive_max_daily=int(os.getenv("PROACTIVE_MAX_DAILY", "5")),
            proactive_quiet_start=int(os.getenv("PROACTIVE_QUIET_START", "23")),
            proactive_quiet_end=int(os.getenv("PROACTIVE_QUIET_END", "7")),
            # Prompt / token 预算
            chat_recent_messages_limit=int(os.getenv("CHAT_RECENT_MESSAGES_LIMIT", "12")),
            tool_result_max_chars=int(os.getenv("TOOL_RESULT_MAX_CHARS", "1200")),
            prompt_memory_items=int(os.getenv("PROMPT_MEMORY_ITEMS", "5")),
            prompt_memory_item_max_chars=int(os.getenv("PROMPT_MEMORY_ITEM_MAX_CHARS", "180")),
            prompt_summary_items=int(os.getenv("PROMPT_SUMMARY_ITEMS", "2")),
            prompt_summary_item_max_chars=int(os.getenv("PROMPT_SUMMARY_ITEM_MAX_CHARS", "260")),
            prompt_tool_count_max=int(os.getenv("PROMPT_TOOL_COUNT_MAX", "8")),
            prompt_tool_desc_max_chars=int(os.getenv("PROMPT_TOOL_DESC_MAX_CHARS", "80")),
            summary_trigger_messages=int(os.getenv("SUMMARY_TRIGGER_MESSAGES", "24")),
            summary_keep_recent_messages=int(os.getenv("SUMMARY_KEEP_RECENT_MESSAGES", "12")),
            summary_min_batch_messages=int(os.getenv("SUMMARY_MIN_BATCH_MESSAGES", "8")),
            tool_timeout_seconds=float(os.getenv("TOOL_TIMEOUT_SECONDS", "15")),
            tool_retry_count=int(os.getenv("TOOL_RETRY_COUNT", "1")),
            tool_log_max_result_chars=int(os.getenv("TOOL_LOG_MAX_RESULT_CHARS", "200")),
            memory_auto_extract_enabled=os.getenv("MEMORY_AUTO_EXTRACT_ENABLED", "true").lower() == "true",
            memory_auto_extract_min_chars=int(os.getenv("MEMORY_AUTO_EXTRACT_MIN_CHARS", "8")),
            memory_auto_extract_max_chars=int(os.getenv("MEMORY_AUTO_EXTRACT_MAX_CHARS", "220")),
            memory_retrieval_top_k=int(os.getenv("MEMORY_RETRIEVAL_TOP_K", "6")),
            memory_retrieval_keyword_count=int(os.getenv("MEMORY_RETRIEVAL_KEYWORD_COUNT", "4")),
            allow_client_provider_override=os.getenv("ALLOW_CLIENT_PROVIDER_OVERRIDE", "true").lower() == "true",
        )

        # 确保数据目录存在
        Path(config.database_path).parent.mkdir(parents=True, exist_ok=True)

        return config


# 全局单例
settings = AppConfig.from_env()
