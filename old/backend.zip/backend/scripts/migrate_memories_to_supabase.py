"""Migrate memories from local SQLite to Supabase table.

Usage:
  python scripts/migrate_memories_to_supabase.py

Required env:
  DATABASE_PATH
  SUPABASE_URL
  SUPABASE_KEY
  SUPABASE_MEMORIES_TABLE (optional, default: memories)
"""
from __future__ import annotations

import os
import sqlite3
from typing import Any

import httpx
from dotenv import load_dotenv


def load_config() -> dict[str, str]:
    load_dotenv()
    database_path = os.getenv("DATABASE_PATH", "./data/gateway.db")
    supabase_url = os.getenv("SUPABASE_URL", "").rstrip("/")
    supabase_key = os.getenv("SUPABASE_KEY", "")
    table = os.getenv("SUPABASE_MEMORIES_TABLE", "memories")

    if not supabase_url or not supabase_key:
        raise RuntimeError("SUPABASE_URL and SUPABASE_KEY are required")

    return {
        "database_path": database_path,
        "supabase_url": supabase_url,
        "supabase_key": supabase_key,
        "table": table,
    }


def read_sqlite_memories(database_path: str) -> list[dict[str, Any]]:
    conn = sqlite3.connect(database_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT id, content, category, tags, source, created_at, updated_at FROM memories ORDER BY created_at ASC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def upload_to_supabase(items: list[dict[str, Any]], supabase_url: str, supabase_key: str, table: str) -> None:
    if not items:
        print("No memories found in SQLite. Nothing to migrate.")
        return

    endpoint = f"{supabase_url}/rest/v1/{table}"
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates,return=minimal",
    }

    # PostgREST has payload size limits; batch to reduce failure risk.
    batch_size = 200
    trust_env = os.getenv("SUPABASE_HTTP_TRUST_ENV", "0").lower() in ("1", "true", "yes")
    with httpx.Client(timeout=30.0, trust_env=trust_env) as client:
        for i in range(0, len(items), batch_size):
            batch = items[i : i + batch_size]
            resp = client.post(endpoint, headers=headers, json=batch)
            if resp.status_code >= 300:
                raise RuntimeError(
                    f"Upload failed at batch {i // batch_size + 1}: {resp.status_code} {resp.text[:300]}"
                )
            print(f"Uploaded batch {i // batch_size + 1}: {len(batch)} rows")

    print(f"Migration finished. Total uploaded: {len(items)}")


def main() -> None:
    cfg = load_config()
    memories = read_sqlite_memories(cfg["database_path"])
    print(f"Loaded {len(memories)} memories from SQLite: {cfg['database_path']}")
    upload_to_supabase(memories, cfg["supabase_url"], cfg["supabase_key"], cfg["table"])


if __name__ == "__main__":
    main()
