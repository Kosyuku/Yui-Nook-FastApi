"""Pyro-Gemini 网关入口"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

import database as db
from models import init_router
from routes import api
from routes.extra import extra_api
from tools import init_external_tools
import consciousness

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    logger.info("🚀 Pyro-Gemini 网关启动中...")
    init_router()
    init_external_tools()           # 注册天气/搜索/抓取等外部工具
    await db.get_db()               # 初始化数据库（含新增表）
    consciousness.start_loop()      # 启动意识循环后台任务
    logger.info("✅ 网关就绪！")
    yield
    consciousness.stop_loop()
    await db.close_db()
    logger.info("👋 网关已关闭")


app = FastAPI(
    title="Pyro-Gemini Gateway",
    description="个人 AI 助手网关 — 多模型路由 + 记忆系统 + 意识循环",
    version="0.2.0",
    lifespan=lifespan,
)

# CORS — 允许前端跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载路由
app.include_router(api)          # 核心路由 (chat/sessions/memories/models)
app.include_router(extra_api)    # 扩展路由 (todos/notes/proactive/history/consciousness)

# 如果前端目录存在，提供静态文件
frontend_dir = Path(__file__).parent.parent / "frontend"
if frontend_dir.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dir), html=True), name="frontend")


@app.get("/api/health")
async def health():
    return {"status": "ok", "gateway": "pyro-gemini", "version": "0.2.0"}


if __name__ == "__main__":
    import uvicorn
    from config import settings
    uvicorn.run("main:app", host=settings.host, port=settings.port, reload=True)
