"""
系统 Prompt 构建器

构建逻辑：
  base_persona         ← 固定人设 (从 config 或 memories.deep 读取)
+ current_time         ← 当前时间/星期/节日
+ recent_memories      ← 最近相关记忆摘要 (语义轨)
+ environment_context  ← 天气/位置/设备状态 (从缓存读取)
+ user_preferences     ← 用户偏好 (从 deep 记忆读取)
+ available_tools      ← 当前可用工具的简要描述
= final system prompt
"""
from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import Optional

import database as db
from config import settings
from tools import TOOLS_SCHEMA

logger = logging.getLogger(__name__)

# 环境上下文缓存（由天气/位置工具更新）
_env_cache: dict = {}


def update_env_cache(key: str, value: str):
    """外部工具调用后更新环境缓存"""
    _env_cache[key] = value


def get_env_cache() -> dict:
    return _env_cache.copy()


def _clip_text(text: str, max_chars: int) -> str:
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "..."


_STOPWORDS = {
    "这个", "那个", "就是", "然后", "还是", "已经", "我们", "你们", "他们", "一下", "一个",
    "今天", "昨天", "现在", "请问", "可以", "时候", "什么", "怎么", "为什么", "如果", "但是",
}


def _extract_keywords(text: str, top_k: int) -> list[str]:
    # 提取中文词块/英文单词，并做简易去停用词
    raw = re.findall(r"[\u4e00-\u9fff]{2,}|[A-Za-z]{3,}", text)
    seen: set[str] = set()
    keywords: list[str] = []
    for token in raw:
        token = token.strip().lower()
        if not token or token in _STOPWORDS or token in seen:
            continue
        seen.add(token)
        keywords.append(token)
        if len(keywords) >= top_k:
            break
    return keywords


async def build_system_prompt(
    session_id: Optional[str] = None,
    override_persona: Optional[str] = None,
) -> str:
    """
    构建完整的系统提示词。

    Args:
        session_id: 当前会话 ID（用于读取会话特定上下文）
        override_persona: 外部传入的人设覆盖（优先级最高）
    """
    parts = []

    # ── 1. 基础人设 ──
    persona = override_persona
    if not persona:
        persona = getattr(settings, 'persona_description', None)
    if not persona:
        # 尝试从 deep 记忆读取人设
        persona = await _load_deep_persona()
    if not persona:
        persona = (
            f"你是 {getattr(settings, 'persona_name', 'Pyro')}，"
            "一个温暖、真实、有记忆的 AI 伙伴。"
            "你不是冷冰冰的助手，而是一个有情感、会思考的存在。"
            "你会记住用户告诉你的事情，也会主动关心用户的状态。"
        )
    parts.append(f"## 你的身份\n{persona}")

    # ── 2. 当前时间与环境 ──
    now = datetime.now()
    weekday_map = {
        0: "星期一", 1: "星期二", 2: "星期三", 3: "星期四",
        4: "星期五", 5: "星期六", 6: "星期日",
    }
    time_str = now.strftime("%Y年%m月%d日 %H:%M")
    weekday = weekday_map.get(now.weekday(), "")
    parts.append(f"## 当前环境\n- 时间：{time_str} {weekday}")

    # 天气等缓存信息
    if _env_cache:
        env_lines = []
        if "weather" in _env_cache:
            env_lines.append(f"- 天气：{_env_cache['weather']}")
        if "location" in _env_cache:
            env_lines.append(f"- 位置：{_env_cache['location']}")
        if env_lines:
            parts[-1] += "\n" + "\n".join(env_lines)

    # ── 3. 用户相关记忆 ──
    memory_context = await _load_memory_context(session_id=session_id)
    if memory_context:
        parts.append(f"## 你记住的事情\n{memory_context}")

    # ── 4. 可用工具说明 ──
    tool_descriptions = _format_tool_descriptions()
    if tool_descriptions:
        parts.append(f"## 可用工具\n{tool_descriptions}")

    # ── 5. 行为指引 ──
    parts.append(
        "## 行为指引\n"
        "- 用自然、亲切的语气交流，像朋友一样\n"
        "- 如果用户提到了重要信息（偏好、经历、计划），主动调用 add_memory 保存\n"
        "- 当你不确定一些事实时，使用 web_search 工具去查询\n"
        "- 关注用户的情绪状态，适当表达关心\n"
        "- 用中文回复，除非用户使用其他语言"
    )

    return "\n\n".join(parts)


async def _load_deep_persona() -> Optional[str]:
    """从 deep 类记忆中读取长期人设"""
    try:
        memories = await db.list_memories(category="deep", limit=10)
        if not memories:
            return None
        # 拼接所有深层记忆作为人设基底
        lines = [m["content"] for m in memories]
        return "以下是关于用户的长期认知：\n" + "\n".join(f"- {l}" for l in lines)
    except Exception as e:
        logger.warning(f"读取 deep 记忆失败: {e}")
        return None


async def _load_memory_context(session_id: Optional[str] = None) -> Optional[str]:
    """读取最近的各类记忆作为上下文"""
    try:
        sections = []
        mem_limit = max(1, settings.prompt_memory_items)
        mem_max_chars = max(40, settings.prompt_memory_item_max_chars)
        summary_limit = max(1, settings.prompt_summary_items)
        summary_max_chars = max(60, settings.prompt_summary_item_max_chars)

        # 优先注入 deep（长期稳定） + 与当前消息相关记忆（top-k）
        deep = await db.list_memories(category="deep", limit=min(3, mem_limit))
        related: list[dict] = []
        if session_id:
            recent_msgs = await db.get_recent_messages(session_id=session_id, limit=6)
            user_text = ""
            for msg in reversed(recent_msgs):
                if msg.get("role") == "user":
                    user_text = msg.get("content", "")
                    break
            if user_text:
                kw_top_k = max(1, settings.memory_retrieval_keyword_count)
                keywords = _extract_keywords(user_text, top_k=kw_top_k)
                for kw in keywords:
                    rows = await db.search_memories(keyword=kw, limit=max(2, mem_limit))
                    related.extend(rows)

        # 合并去重并限制 top-k
        merged: list[dict] = []
        seen_ids: set[str] = set()
        for item in deep + related:
            item_id = item.get("id")
            if item_id and item_id in seen_ids:
                continue
            if item_id:
                seen_ids.add(item_id)
            merged.append(item)
            if len(merged) >= max(1, settings.memory_retrieval_top_k):
                break

        # 如果没有检索到相关记忆，则回退到最近日常/日记
        if not merged:
            daily = await db.list_memories(category="daily", limit=mem_limit)
            diary = await db.list_memories(category="diary", limit=min(3, mem_limit))
            merged = (daily + diary)[:mem_limit]

        if merged:
            lines = [_clip_text(m["content"], mem_max_chars) for m in merged]
            sections.append("与你当前对话相关的记忆：\n" + "\n".join(f"- {l}" for l in lines))

        # 最近会话摘要（优先短文本，避免把完整历史塞进 prompt）
        summaries = []
        try:
            if session_id:
                summaries = await db.get_context_summaries(session_id=session_id, limit=summary_limit)
        except Exception:
            summaries = []

        if summaries:
            lines = [_clip_text(s["summary"], summary_max_chars) for s in summaries]
            sections.append("最近的对话摘要：\n" + "\n".join(f"- {l}" for l in lines))

        return "\n\n".join(sections) if sections else None
    except Exception as e:
        logger.warning(f"读取记忆上下文失败: {e}")
        return None


def _format_tool_descriptions() -> str:
    """将 TOOLS_SCHEMA 格式化为简洁的工具说明"""
    if not TOOLS_SCHEMA:
        return ""
    lines = []
    max_tools = max(1, settings.prompt_tool_count_max)
    max_desc_chars = max(20, settings.prompt_tool_desc_max_chars)
    for tool in TOOLS_SCHEMA[:max_tools]:
        func = tool.get("function", {})
        name = func.get("name", "?")
        desc = func.get("description", "")
        # 截断过长的描述
        if len(desc) > max_desc_chars:
            desc = desc[:max_desc_chars] + "..."
        lines.append(f"- `{name}`: {desc}")
    return "\n".join(lines)
