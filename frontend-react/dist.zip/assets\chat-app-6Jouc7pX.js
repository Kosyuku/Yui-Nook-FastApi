(()=>{const ko=[{id:"ayan",name:"阿延",handle:"@ayan",bio:"小酒，今天也要开开心心哦～",status:"在线",roleTag:"特别关注",lastMessage:"先聊天详情页。头部、气泡、输入区一起收掉，其他页自然顺。",lastTime:"刚刚",unread:2,pinned:!0,avatar:"https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&q=80",theme:"rose",settings:{model:"gpt-5.4",modelProviderId:"openai",temperature:.72,topP:.9,contextCount:64,thinkBudget:48,streamOutput:!0,reasoning_visibility:!1,proactiveEnabled:!0,proactiveFrequency:60,memoryEnabled:!0},roomBackground:"点阵",chatTheme:"default",bubbleTheme:"默认主题",topics:[{id:"t1",title:"最近状态",updatedAt:"今天 21:40",count:24},{id:"t2",title:"睡眠记录",updatedAt:"昨天",count:18},{id:"t3",title:"网页 UI",updatedAt:"3天前",count:41}],messages:[{id:"m1",role:"ai",text:"今天把你丢给我的文件都翻了一遍。页面可以更可爱，真正夹棒的是里面的空壳。",time:"21:48"},{id:"m2",role:"user",text:"所以该先改哪里？",time:"21:49"},{id:"m3",role:"ai",text:"先聊天详情页。头部、气泡、输入区一起收掉，其他页自然顺。",time:"21:49",thinking:"她已经给了明确起点，先改核心路径能更快出效果。"}]},{id:"azheng",name:"阿争",handle:"@azheng",bio:"我把草稿整理好了，要继续吗？",status:"忙碌",roleTag:"同事",lastMessage:"我把草稿整理好了，要继续吗？",lastTime:"12分钟前",unread:0,pinned:!1,avatar:"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=300&q=80",theme:"mist",settings:{model:"gpt-5.4",modelProviderId:"openai",temperature:.45,topP:.8,contextCount:48,thinkBudget:36,streamOutput:!0,reasoning_visibility:!1,proactiveEnabled:!1,proactiveFrequency:30,memoryEnabled:!0},roomBackground:"点阵",chatTheme:"default",bubbleTheme:"默认主题",topics:[{id:"t4",title:"版本梳理",updatedAt:"今天 23:18",count:12},{id:"t5",title:"说明文档",updatedAt:"昨天",count:8}],messages:[{id:"m4",role:"ai",text:"我把草稿整理好了，要继续吗？",time:"23:18"}]},{id:"xiaoying",name:"小樱",handle:"@sakura",bio:"周末去看展吗？",status:"在线",roleTag:"朋友",lastMessage:"周末去看展吗？",lastTime:"1小时前",unread:1,pinned:!1,avatar:"https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&q=80",theme:"cream",settings:{model:"gpt-5.4",modelProviderId:"openai",temperature:.66,topP:.95,contextCount:32,thinkBudget:24,streamOutput:!0,reasoning_visibility:!1,proactiveEnabled:!0,proactiveFrequency:20,memoryEnabled:!1},roomBackground:"点阵",chatTheme:"default",bubbleTheme:"默认主题",topics:[{id:"t6",title:"周末计划",updatedAt:"今天",count:6}],messages:[{id:"m5",role:"ai",text:"周末去看展吗？我知道有个新的展。",time:"20:22"}]}],Ge=[{id:"p0",contactId:"me",time:"23:36",mood:"开心",content:"今天的天空很温柔。",image:"https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1000&q=80",likes:["我"],comments:[]},{id:"p1",contactId:"ayan",time:"21:20",mood:"主动",content:"你醉了先看这个。",image:"",likes:["我","阿延"],comments:[{author:"我",text:"我收到了"}]},{id:"p2",contactId:"xiaoying",time:"19:08",mood:"经常",content:"晚上跑了三公里。",image:"",likes:[],comments:[]}],Ee=[{id:"health",label:"Health",icon:"health"},{id:"schedule",label:"日程",icon:"calendar"},{id:"weather",label:"天气",icon:"weather"},{id:"files",label:"文件",icon:"file"},{id:"quote",label:"引用",icon:"quote"},{id:"more",label:"更多",icon:"more"}];function So(){return{tools:Ee.map(e=>({id:e.id,label:e.label,icon:e.icon,prompt:"",enabled:!0}))}}const t={currentTab:"chats",currentView:"list",currentContactId:"ayan",currentSettingsTab:"basic",cotLogMode:"long",activityLogEntries:[],activityLogLoading:!1,activityLogLoadedAt:"",quoteMomentId:null,quoteMessageId:null,momentComposerOpen:!1,momentComposerText:"",momentComposerImage:"",momentComposerImageName:"",momentComposerEditingId:"",momentsActorType:"user",commentSheetMomentId:null,activeMenuMomentId:null,activeBubbleToolsId:null,suppressBubbleToggle:!1,toast:"",topicConfirmOpen:!1,rpRooms:[],currentRpRoomId:"",currentRpMessages:[],rpRoomDialogOpen:!1,rpRoomDialogMode:"create",rpRoomForm:{name:"",world_setting:"",user_role:"",ai_role:""},rpBackView:"list",contacts:structuredClone(ko),moments:structuredClone(Ge),actions:structuredClone(Ee),globalSettings:{theme:"奶油粉",notifications:!0,momentsNotify:!0,autoScroll:!0,defaultModel:"gpt-5.4",provider:"OpenAI",searchService:"默认搜索",voiceService:"未连接",mcpEnabled:!0,exportFormat:"json"},accountProfile:{avatar:"https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80",nickname:"小酒",signature:"管理个人资料与基础偏好"},newContactAvatar:"",showAttach:!1,contactQuickActionEditorId:"",contactQuickMcpMenuOpen:!1,quickActionSwipeOpenId:"",quickActionDragId:"",quickActionSuppressClickUntil:0,quickActionDropHintId:"",quickActionReorderPulseId:"",quickActionDropDirection:"",contactModelAdvancedOpen:!1,companionState:{recent_topics:[],current_mood:"",open_loops:[],proactive_cooldown_until:null,impression:null,relationship_progress:null,likes_summary:null,summary_updated_at:null,updated_at:""},openThinkingIds:{},streamingAbortController:null,animatedMsgIds:{},assistantPlayback:{token:"",timer:null},rpCurtainRunning:!1},ue=new Map,h=()=>document.getElementById("chat-app-root"),v=e=>t.contacts.find(o=>o.id===e),Ie=e=>t.moments.find(o=>o.id===e),c=(e="")=>String(e).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;"),Le=[{key:"default",name:"默认主题",desc:"干净柔和的默认聊天界面",roomTheme:"rose",aliases:["默认玫瑰","默认"]},{key:"pink",name:"蜜桃粉",desc:"更甜一点的粉色聊天氛围",roomTheme:"rose",aliases:["奶茶"]},{key:"dark",name:"夜色",desc:"低亮度深色聊天界面",roomTheme:"rose",aliases:[]},{key:"glass",name:"玻璃雾",desc:"通透轻雾感的玻璃界面",roomTheme:"mist",aliases:["晴空"]}];function Je(e){const o=String(e||"").trim();return o&&Le.find(n=>n.key===o||n.name===o||n.aliases.includes(o))?.key||"default"}function Et(e){const o=Je(e);return Le.find(a=>a.key===o)||Le[0]}function We(e){return Je(e?.chatTheme||e?.bubbleTheme)}function Ze(e){return Et(e).name}const Lt=1500,et=8e3;function Ot(e){return e?e.replace(/<tool_call>[\s\S]*?<\/tool_call>/g,"").replace(/<tool_call>[\s\S]*$/,"").replace(/<\/?(thead|tbody|tr|td|th|table|tool|function|call)[^>]*>/gi,"").replace(/<[^>\n]{1,80}>/g,"").replace(/\n{3,}/g,`

`).trim():""}function _e(e){return e==null?"":typeof e=="string"?e:typeof e=="number"||typeof e=="boolean"?String(e):""}function tt(e,o="",a=""){const n=Ot(_e(e));if(!n)return"";const i=n.replace(/\s+/g," ").trim(),s=_e(o).replace(/\s+/g," ").trim(),r=_e(a).replace(/\s+/g," ").trim();return!i||s&&(i===s||s.includes(i)&&i.length>=8)||r&&(r.includes(i)||r.slice(Math.max(0,r.length-i.length-12)).includes(i))?"":n}function Rt(){return new Promise(e=>requestAnimationFrame(e))}function ot(e){const o=Ot(e);return o?o.length<=Lt?o:`（已截断，共 ${o.length} 字）
${o.slice(-Lt)}`:""}const Io='<svg viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',_o='<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',Mo='<svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',xo='<svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',Co='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>';function To(e){const o=String(e||"").toLowerCase();return/time|clock|date/.test(o)?_o:/view|read|file|diary|memory|search/.test(o)?Mo:Io}function Ao(e){const o=!!e.streaming,a=o?"tl-active":"tl-done",n=o?ot(e.thinking):e.thinking||"",s=(n||"").replace(/\s+/g," ").trim()||"思考中…",r=s.length>36?s.slice(0,36)+"…":s;return`
        <div class="thinking-line ${a}" id="tl-line-${e.id}" data-action="toggle-thinking-line" data-id="${e.id}">
          <div class="thinking-dot"></div>
          <div class="thinking-text-wrap">
            <span class="thinking-text" id="tl-text-${e.id}">${c(r)}</span>
            <div class="thinking-heart">${xo}</div>
            <div class="thinking-fade"></div>
          </div>
          <div class="thinking-expand">${Co}</div>
        </div>
        <div class="thinking-full" id="tl-full-${e.id}">
          <div class="thinking-full-inner" id="thinking-${e.id}">${c(n)}</div>
        </div>`}function qo(e=[]){return e.length?`<div class="tool-lines-wrap">${e.map(a=>{const n=a.status==="running"?"tl-active":"tl-done",i=`${a.name} → ${a.status==="running"?"调用中…":"完成"}`;return`
          <div class="tool-line ${n}">
            <div class="tool-dot"></div>
            <div class="tool-icon">${To(a.name)}</div>
            <span class="tool-text">${c(i)}</span>
          </div>`}).join("")}</div>`:""}const Dt=e=>new Promise(o=>window.setTimeout(o,e));function Vt(e){const o=String(e||"").replace(/\r\n/g,`
`).trim();if(!o)return[];const a=o.split(/\n{2,}/).map(s=>String(s||"").trim()).filter(Boolean),n=[],i=s=>{const r=String(s||"").trim();if(r){if(n.length&&r.length<=3){n[n.length-1]+=r;return}n.push(r)}};return a.forEach(s=>{if(s.length<=34){i(s);return}let r=s;for(;r.length>34;){let d=34;const l=r.slice(0,34).search(/[，、；,; ]/);l>=18&&(d=l+1);const p=r.slice(0,d).trim();if(p.length>=6)i(p),r=r.slice(d).trim();else break}i(r)}),n.filter(Boolean)}function Po(e){const o=String(e||"").trim().length;return o<=10?300+Math.floor(Math.random()*201):o<=24?600+Math.floor(Math.random()*301):900+Math.floor(Math.random()*301)}function Oe(){t.assistantPlayback.token="",t.assistantPlayback.timer&&(window.clearTimeout(t.assistantPlayback.timer),t.assistantPlayback.timer=null)}async function Bt(e,o,a={}){const n=Array.isArray(o)?o.filter(r=>String(r||"").trim()):[];if(!e||!n.length)return;Oe();const i=`reply_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;t.assistantPlayback.token=i;const s=Number.isInteger(a.startIndex)?a.startIndex:e.messages.length;for(let r=0;r<n.length;r+=1){if(t.assistantPlayback.token!==i)return;const d={id:`ai_chunk_${Date.now()}_${r}_${Math.random().toString(36).slice(2,6)}`,role:"ai",text:n[r],time:V()};if(r===0&&(a.thinking&&(d.thinking=a.thinking),a.toolCalls&&(d.toolCalls=a.toolCalls)),r===0&&a.replaceId){const l=e.messages.findIndex(p=>p.id===a.replaceId);l!==-1?e.messages[l]=d:e.messages.splice(Math.min(s,e.messages.length),0,d)}else{const l=Math.min(s+r,e.messages.length);e.messages.splice(l,0,d)}if(e.lastMessage=d.text,e.lastTime=d.time,u(),G(),r>=n.length-1)break;await new Promise(l=>{t.assistantPlayback.timer=window.setTimeout(l,Po(n[r]))}),t.assistantPlayback.timer=null}t.assistantPlayback.token===i&&(t.assistantPlayback.token="",t.assistantPlayback.timer=null)}function he(e){const o=e&&typeof e=="object"?e:{},a=i=>Array.isArray(i)?i.map(s=>String(s||"").trim()).filter(Boolean):[],n=i=>i!=null&&String(i).trim()?String(i).trim():null;return{recent_topics:a(o.recent_topics),current_mood:String(o.current_mood||"").trim(),open_loops:a(o.open_loops),proactive_cooldown_until:o.proactive_cooldown_until?String(o.proactive_cooldown_until):null,impression:n(o.impression),relationshipProgress:n(o.relationship_progress??o.relationshipProgress),likesSummary:n(o.likes_summary??o.likesSummary),summaryUpdatedAt:n(o.summary_updated_at??o.summaryUpdatedAt),updated_at:String(o.updated_at||"").trim()}}function Eo(){const e=he(t.companionState);return e.current_mood?`情绪：${e.current_mood}`:e.open_loops[0]?`进行中：${e.open_loops[0]}`:e.recent_topics[0]?`最近话题：${e.recent_topics[0]}`:"暂无状态"}function Z(){if(t.momentsActorType==="agent"){const e=D();return{author_type:"agent",author_id:e?.id||t.currentContactId||"default",author_name:e?.name||"当前角色",avatar:e?.avatar||""}}return{author_type:"user",author_id:"me",author_name:t.accountProfile?.nickname||"我",avatar:t.accountProfile?.avatar||"https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80"}}function L(e={}){const o=Array.isArray(e.likes)?e.likes:[],a=Array.isArray(e.comments)?e.comments:[],n=String(e.author_type||(e.contactId==="me"?"user":"agent")),i=String(e.author_id||(n==="user"?"me":e.contactId||"default"));return{id:String(e.id||`p${Date.now()}`),author_type:n,author_id:i,content:String(e.content||""),image:String(e.image||""),mood:String(e.mood||""),time:String(e.time||""),created_at:String(e.created_at||""),updated_at:String(e.updated_at||""),likes:o.map(s=>typeof s=="string"?{author_type:"user",author_id:s==="我"?"me":s,author_name:s}:{author_type:String(s?.author_type||"user"),author_id:String(s?.author_id||"me"),author_name:String(s?.author_name||"")}),comments:a.map(s=>({author_type:String(s?.author_type||"user"),author_id:String(s?.author_id||"me"),author_name:String(s?.author_name||s?.author||""),text:String(s?.text||"")}))}}function Nt(e){const o=L(e);if(o.author_type==="agent"){const a=v(o.author_id);return{name:a?.name||o.author_id||"角色",avatar:a?.avatar||""}}return{name:t.accountProfile?.nickname||"我",avatar:t.accountProfile?.avatar||"https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80"}}function Ht(e){const o=L(e);return o.author_type==="user"?o.author_id==="me":o.author_id===(t.currentContactId||D()?.id||"default")}function jt(e=[]){return e.map(o=>o.author_name||(o.author_type==="user"?"我":v(o.author_id)?.name||o.author_id)).join("、")}function Lo(e,o,a){const n=v(t.currentContactId);n&&(n[e]=o,t.toast=a,u(),P(120),window.setTimeout(()=>{t.toast="",u()},1200))}function Oo(e){const o=String(e).toLowerCase();return["health","heart"].includes(o)?"health":["calendar","schedule","date"].includes(o)?"calendar":["weather","cloud"].includes(o)?"weather":["file","files","doc","document"].includes(o)?"file":["quote","reply"].includes(o)?"quote":(["more","tool","tools"].includes(o),"more")}const at={get_current_time:"时间",get_weather:"天气",get_health_summary:"健康",web_search:"搜索",fetch_url:"网页",add_todo:"待办",list_todos:"待办列表",complete_todo:"完成待办",add_note:"便签",list_notes:"便签列表"},zt=new Set(["get_current_time","get_weather","get_health_summary","web_search","fetch_url","add_todo","list_todos","complete_todo","add_note","list_notes"]);function ce(e){return zt.has(String(e||"").trim())}function ee(e,o){if(typeof e=="string"){const s=String(e||`mcp_${o}`);return{id:s,label:at[s]||e||`工具${o+1}`,icon:"more",prompt:"",mcpToolId:ce(s)?s:"",enabled:!0}}const a=e?.id||e?.toolId||e?.name||`mcp_${o}`,n=String(a),i=at[n]||e?.label||e?.name||e?.title||`工具${o+1}`;return{id:n,label:String(i),icon:Oo(e?.icon||e?.type||e?.category||"more"),prompt:String(e?.prompt||e?.message||""),mcpToolId:String(e?.mcpToolId||e?.toolId||(ce(n)?n:"")),enabled:e?.enabled!==!1}}function Ft(){const o=C()?.mcpLibrary?.tools;if(!Array.isArray(o)||!o.length)return Ee;const a=o.map(ee).filter(n=>ce(n.id)).filter(n=>n.enabled!==!1);return a.length?a:Ee}function D(){return v(t.currentContactId)||t.contacts[0]}function le(e){return e?.settings?(!Array.isArray(e.settings.quickActions)||!e.settings.quickActions.length?e.settings.quickActions=Ft().map((o,a)=>({...ee(o,a)})):e.settings.quickActions=e.settings.quickActions.map((o,a)=>ee(o,a)),e.settings.quickActions):[]}function nt(e=D()){const o=le(e).filter(a=>a.enabled!==!1);return o.length?o:Ft()}function m(e){const o='viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"',a={back:`<svg ${o}><path d="M15 18l-6-6 6-6"/></svg>`,plus:`<svg ${o}><path d="M12 5v14M5 12h14"/></svg>`,search:`<svg ${o}><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>`,history:`<svg ${o}><path d="M3 12a9 9 0 101.9-5.6"/><path d="M3 4v4h4"/><path d="M12 7v5l3 2"/></svg>`,settings:`<svg ${o}><path d="M12 3v3M12 18v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M3 12h3M18 12h3M4.9 19.1L7 17M17 7l2.1-2.1"/><circle cx="12" cy="12" r="3.3"/></svg>`,more:`<svg ${o}><circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg>`,heart:`<svg ${o}><path d="M12 20.5s-7-4.4-7-10a4 4 0 017-2.5A4 4 0 0119 10.5c0 5.6-7 10-7 10z"/></svg>`,heartFilled:'<svg viewBox="0 0 24 24" fill="#B595C9" stroke="none" stroke-width="0"><path d="M12 20.5s-7-4.4-7-10a4 4 0 017-2.5A4 4 0 0119 10.5c0 5.6-7 10-7 10z"/></svg>',comment:`<svg ${o}><path d="M7 18l-3 2 1-3.8A7.8 7.8 0 014.2 13 7.8 7.8 0 1112 20a8 8 0 01-5-2z"/><path d="M8.5 10.5h7M8.5 13.5h4.5"/></svg>`,chatArrow:`<svg ${o}><path d="M4.8 18.2l.9-3.3A7.5 7.5 0 014.5 11 7.5 7.5 0 1112 18.5a7.4 7.4 0 01-3.6-.9z"/><path d="M10 9l4 3-4 3"/><path d="M14 12H8"/></svg>`,send:`<svg ${o}><path d="M21 3L10 14"/><path d="M21 3l-7 18-4-7-7-4z"/></svg>`,close:`<svg ${o}><path d="M18 6L6 18M6 6l12 12"/></svg>`,camera:`<svg ${o}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>`,attach:`<svg ${o}><path d="M21 11.5l-8.7 8.7a5 5 0 01-7.1-7.1l9.2-9.2a3.5 3.5 0 015 5L9 19.3a2 2 0 01-2.8-2.8l8.5-8.5"/></svg>`,quote:`<svg ${o}><path d="M9 7H5v5h4v5H4v-5c0-2.8 1.8-5 5-5zM20 7h-4v5h4v5h-5v-5c0-2.8 1.8-5 5-5z"/></svg>`,reroll:`<svg ${o}><path d="M20 11a8 8 0 10-2.3 5.7"/><path d="M20 4v7h-7"/></svg>`,cot:`<svg ${o}><path d="M12 4v16M4 12h16"/><path d="M7.5 7.5l9 9M16.5 7.5l-9 9" opacity="0.18"/></svg>`,bubbleHeart:`<svg ${o}><path d="M12 19.3s-5.8-3.5-5.8-8a3.7 3.7 0 016.1-2.8 3.7 3.7 0 015.9 2.8c0 4.5-5.6 8-5.6 8z"/></svg>`,weather:`<svg ${o}><path d="M6 16a4 4 0 010-8 5.5 5.5 0 0110.4-1.8A4 4 0 1118 16H6z"/></svg>`,calendar:`<svg ${o}><rect x="4" y="5" width="16" height="15" rx="3"/><path d="M8 3v4M16 3v4M4 10h16"/></svg>`,file:`<svg ${o}><path d="M8 3h6l5 5v11a2 2 0 01-2 2H8a2 2 0 01-2-2V5a2 2 0 012-2z"/><path d="M14 3v5h5"/></svg>`,health:`<svg ${o}><path d="M12 20s-6.5-4-6.5-9.2A4.3 4.3 0 0112 7a4.3 4.3 0 016.5 3.8C18.5 16 12 20 12 20z"/><path d="M9.2 12h1.8l1-2.1 1.2 4 1-1.9h1.6"/></svg>`,toggleOff:'<svg viewBox="0 0 52 32" fill="none"><rect x="1.5" y="1.5" width="49" height="29" rx="14.5" fill="rgba(255,255,255,.7)" stroke="rgba(150,122,133,.14)"/><circle cx="16" cy="16" r="11" fill="#fff"/></svg>',toggleOn:'<svg viewBox="0 0 52 32" fill="none"><rect x="1.5" y="1.5" width="49" height="29" rx="14.5" fill="#e9d7ff" stroke="rgba(120,90,150,.14)"/><circle cx="36" cy="16" r="11" fill="#fff"/></svg>',chevron:`<svg ${o}><path d="M9 6l6 6-6 6"/></svg>`,tabChat:`<svg ${o}><path d="M22 12c0-5.5-4.5-10-10-10S2 6.5 2 12c0 2 .6 3.9 1.6 5.4L2 22l4.8-1.3A9.9 9.9 0 0012 22c5.5 0 10-4.5 10-10z"></path></svg>`,tabMoments:`<svg ${o}><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>`,tabSettings:`<svg ${o}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>`,actionDots:'<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>',pencil:`<svg ${o}><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>`,trash:`<svg ${o}><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`,stop:'<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="7" y="7" width="10" height="10" rx="2"/></svg>'};return a[e]||a.more}function Ut(){u()}function it(e){const o=()=>{const a=h()?.querySelector(".chat-app-body");a&&(a.scrollTop=e)};requestAnimationFrame(()=>{o(),requestAnimationFrame(o),window.setTimeout(o,0)})}function Qt(){const e=h()?.querySelector(".chat-app-body"),o=e?e.scrollTop:0,a=window.scrollY||window.pageYOffset||0;u(),it(o),requestAnimationFrame(()=>{window.scrollTo(0,a),requestAnimationFrame(()=>window.scrollTo(0,a))})}function j(){if(t.currentView==="moments"){Qt();return}u()}function Ro(e,o){t.moments=t.moments.map(a=>{const n=L(a);if(n.id!==e)return a;const s=n.likes.some(r=>r.author_type===o.author_type&&r.author_id===o.author_id)?n.likes.filter(r=>!(r.author_type===o.author_type&&r.author_id===o.author_id)):[{author_type:o.author_type,author_id:o.author_id,author_name:o.author_name},...n.likes];return{...n,likes:s}})}function Do(e,o,a){t.moments=t.moments.map(n=>{const i=L(n);return i.id!==e?n:{...i,comments:[{author_type:o.author_type,author_id:o.author_id,author_name:o.author_name,text:a},...i.comments]}})}function Yt(e,o){e&&(e.classList.toggle("on",!!o),e.classList.toggle("off",!o),e.setAttribute("aria-pressed",o?"true":"false"),e.innerHTML=Ve(o),e.classList.remove("switch-animating"),e.offsetWidth,e.classList.add("switch-animating"),clearTimeout(e.__switchAnimTimer),e.__switchAnimTimer=setTimeout(()=>e.classList.remove("switch-animating"),260))}function u(){const e=h();if(!e)return;Kt(),["room","rpRoom"].includes(t.currentView)||(t.showAttach=!1),t.currentView!=="moments"&&(t.momentComposerOpen=!1);const o=e.querySelector(".chat-app-body"),a=o?o.scrollTop:0,n=v(t.currentContactId)||t.contacts[0],i=We(n);e.dataset.theme=i,e.removeAttribute("data-bound"),e.innerHTML=`
      <div class="chat-shell ${t.currentView==="rpRoom"?"mode-rp rp-theatre-shell":"mode-normal"}" data-theme="${i}">
        ${st()}
        <div class="chat-app-body ${["room","rpRoom"].includes(t.currentView)?"room-layout":""} ${Re()?"has-bottom-nav":""}">
          ${rt()}
        </div>
        ${Re()?Ho():""}
        ${t.toast?ia():""}
        ${t.showAttach?Da():""}
        ${t.momentComposerOpen?aa():""}
        
        ${t.rpRoomDialogOpen?sa():""}
      </div>
    `,Aa(),G(),["room","rpRoom"].includes(t.currentView)||it(a),P(),requestAnimationFrame(()=>{h()?.querySelectorAll(".message-row[data-msg-id]").forEach(s=>{const r=s.dataset.msgId;r&&!t.animatedMsgIds[r]&&(t.animatedMsgIds[r]=!0,s.classList.add("msg-fadein"))})})}function Kt(){if(document.getElementById("rp-theatre-style"))return;const e=document.createElement("style");e.id="rp-theatre-style",e.textContent=`
          .chat-shell.mode-rp {
            background:#0e0a12;
            color:rgba(220,210,225,.92);
            position:relative;
            overflow:hidden;
          }
          .chat-shell.mode-rp::before {
            content:'';
            position:absolute;
            inset:0;
            z-index:0;
            background:
              radial-gradient(ellipse at 20% 0%, rgba(88,28,72,.18) 0%, transparent 55%),
              radial-gradient(ellipse at 80% 100%, rgba(38,18,68,.22) 0%, transparent 50%),
              radial-gradient(circle at 50% 50%, rgba(20,12,28,.95) 0%, #0e0a12 100%);
            pointer-events:none;
          }
          .chat-shell.mode-rp::after {
            content:'';
            position:absolute;
            inset:0;
            z-index:0;
            background:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.035'/%3E%3C/svg%3E");
            opacity:.5;
            pointer-events:none;
          }
          .chat-shell.mode-rp > * { position:relative; z-index:1; }
          .rp-header {
            padding:52px 18px 14px;
            display:flex;
            align-items:center;
            gap:12px;
            flex-shrink:0;
            background:rgba(18,12,24,.72);
            border-bottom:1px solid rgba(160,100,180,.12);
            backdrop-filter:blur(28px) saturate(1.1);
          }
          .rp-header .header-back,
          .rp-header .header-action-btn {
            width:36px;
            height:36px;
            border-radius:50%;
            border:none;
            cursor:pointer;
            display:flex;
            align-items:center;
            justify-content:center;
            background:rgba(160,100,180,.1);
            color:rgba(180,150,200,.7);
          }
          .rp-header .header-action-btn {
            width:34px;
            height:34px;
            background:rgba(160,100,180,.08);
            color:rgba(160,130,190,.5);
          }
          .rp-header .header-info { flex:1; min-width:0; }
          .rp-header .header-title {
            color:rgba(210,180,230,.9);
            font-family:'Cormorant Garamond','Zen Maru Gothic','Noto Sans SC',serif;
            font-size:17px;
            font-weight:500;
            letter-spacing:.03em;
          }
          .rp-header .header-subtitle {
            font-size:11px;
            margin-top:1px;
            color:rgba(160,120,180,.45);
            font-style:italic;
          }
          .scene-title-enter {
            animation:sceneFadeIn .6s ease-out both;
          }
          @keyframes sceneFadeIn {
            from { opacity:0; transform:translateY(-8px); }
            to { opacity:1; transform:translateY(0); }
          }
          .rp-room-stage {
            height:100%;
            display:flex;
            flex-direction:column;
            min-height:0;
            background:transparent;
          }
          .world-hint {
            margin:12px 14px 4px;
            padding:10px 14px;
            border-radius:14px;
            font-size:12px;
            display:flex;
            align-items:center;
            gap:8px;
            flex-shrink:0;
            background:rgba(80,40,100,.12);
            border:1px solid rgba(140,80,170,.1);
            backdrop-filter:blur(16px);
            color:rgba(180,150,210,.55);
            font-style:italic;
          }
          .world-hint-icon { font-size:14px; opacity:.6; }
          .messages-area {
            flex:1;
            overflow-y:auto;
            padding:10px 14px 14px;
            display:flex;
            flex-direction:column;
            gap:12px;
            min-height:0;
          }
          .msg-row {
            display:flex;
            gap:8px;
            align-items:flex-start;
          }
          .msg-row.from-user { flex-direction:row-reverse; }
          .msg-avatar {
            width:34px;
            height:34px;
            border-radius:50%;
            object-fit:cover;
            flex-shrink:0;
            border:1px solid rgba(140,80,170,.2);
            box-shadow:0 0 12px rgba(120,60,160,.15);
          }
          .msg-bubble {
            max-width:78%;
            padding:10px 14px;
            border-radius:18px;
            font-size:14px;
            line-height:1.65;
            position:relative;
            transition:all .5s ease;
          }
          .mode-rp .msg-bubble.ai {
            background:rgba(28,18,38,.65);
            border:1px solid rgba(140,80,180,.15);
            border-radius:18px 18px 18px 4px;
            color:rgba(220,210,235,.9);
            box-shadow:0 2px 16px rgba(100,40,140,.08), inset 0 1px 0 rgba(180,140,220,.06);
          }
          .mode-rp .msg-bubble.user {
            background:rgba(60,30,80,.25);
            border:1px solid rgba(160,100,200,.12);
            border-radius:18px 18px 4px 18px;
            color:rgba(210,195,225,.88);
            box-shadow:0 2px 12px rgba(80,30,120,.06);
          }
          .rp-action {
            color:rgba(180,140,210,.6);
            font-style:italic;
            display:block;
            margin:4px 0;
            line-height:1.7;
          }
          .rp-dialogue {
            display:block;
            margin:2px 0;
            color:rgba(230,220,245,.95);
          }
          .rp-composer {
            padding:10px 14px 28px;
            flex-shrink:0;
          }
          .rp-composer .composer-card {
            display:flex;
            align-items:center;
            gap:8px;
            padding:8px 10px 8px 16px;
            border-radius:24px;
            background:rgba(22,14,32,.6);
            border:1px solid rgba(140,80,180,.12);
            backdrop-filter:blur(24px);
            box-shadow:0 4px 20px rgba(80,30,120,.1);
          }
          .rp-composer .chat-input {
            color:rgba(210,200,225,.88);
            font-size:14px;
            padding:6px 0;
          }
          .rp-composer .chat-input::placeholder { color:rgba(140,110,170,.35); }
          .rp-composer .send-round {
            width:38px;
            height:38px;
            background:linear-gradient(135deg, rgba(120,50,160,.35), rgba(80,30,120,.4));
            color:rgba(200,170,230,.8);
            box-shadow:0 0 16px rgba(120,50,160,.15);
          }
          .mode-rp .msg-row { animation:rpMsgIn .35s ease-out both; }
          @keyframes rpMsgIn {
            from { opacity:0; transform:translateY(6px); }
            to { opacity:1; transform:translateY(0); }
          }
          .curtain-transition {
            position:fixed;
            inset:0;
            z-index:9999;
            pointer-events:none;
          }
          .curtain-transition .curtain-left,
          .curtain-transition .curtain-right {
            position:absolute;
            top:0;
            bottom:0;
            width:50%;
            background:linear-gradient(180deg,#1a0e24,#0e0a12);
          }
          .curtain-transition .curtain-left { left:0; transform:translateX(-100%); }
          .curtain-transition .curtain-right { right:0; transform:translateX(100%); }
          .curtain-transition.closing .curtain-left { animation:curtainCloseLeft .4s ease-in-out forwards; }
          .curtain-transition.closing .curtain-right { animation:curtainCloseRight .4s ease-in-out forwards; }
          .curtain-transition.opening .curtain-left { animation:curtainOpenLeft .4s ease-in-out forwards; }
          .curtain-transition.opening .curtain-right { animation:curtainOpenRight .4s ease-in-out forwards; }
          @keyframes curtainCloseLeft { from { transform:translateX(-100%); } to { transform:translateX(0); } }
          @keyframes curtainCloseRight { from { transform:translateX(100%); } to { transform:translateX(0); } }
          @keyframes curtainOpenLeft { from { transform:translateX(0); } to { transform:translateX(-100%); } }
          @keyframes curtainOpenRight { from { transform:translateX(0); } to { transform:translateX(100%); } }
          .chat-shell.mode-normal .message-bubble.from-ai {
            background:rgba(255,248,252,.96);
            border:1px solid rgba(236,195,212,.5);
            border-radius:18px 18px 18px 4px;
            color:rgba(72,56,64,.88);
          }
          .chat-shell.mode-normal .message-bubble.from-user {
            background:linear-gradient(135deg, rgba(200,160,190,.25), rgba(180,140,200,.2));
            border:1px solid rgba(200,160,190,.3);
            border-radius:18px 18px 4px 18px;
            color:rgba(72,56,64,.88);
          }
        `,document.head.appendChild(e)}function Vo(e){if(Kt(),t.rpCurtainRunning)return Promise.resolve(e?.());t.rpCurtainRunning=!0;const o=document.createElement("div");return o.className="curtain-transition closing",o.innerHTML='<div class="curtain-left"></div><div class="curtain-right"></div>',document.body.appendChild(o),new Promise(a=>{window.setTimeout(async()=>{try{await e?.()}finally{o.className="curtain-transition opening",window.setTimeout(()=>{o.remove(),t.rpCurtainRunning=!1,a()},450)}},420)})}function Re(){return["list","moments","settings"].includes(t.currentView)}function st(){if(t.currentView==="room")return Bo();if(t.currentView==="rpRoom")return No();if(t.currentView==="contactSettings")return K("联系人设置","back-room",!0);if(t.currentView==="cotLog")return K("COT 日志","back-contact-settings",!0);if(t.currentView==="rpLobby")return`
        <header class="chat-page-header simple-header">
          <button class="icon-btn text-btn" data-action="back-rp-source" aria-label="返回">${m("back")}</button>
          <div class="chat-page-title">Mirage 夢幻楼</div>
          <button class="icon-btn ghost-circle" data-action="open-rp-room-create" aria-label="新建房间">${m("plus")}</button>
        </header>
      `;if(t.currentView==="companionStateDetail")return K("当前状态","back-contact-settings",!0);if(t.currentView==="contactImpressionDetail")return K("关于你的印象","back-contact-settings",!0);if(t.currentView==="contactRelationshipDetail")return K("关系进展","back-contact-settings",!0);if(t.currentView==="contactLikesDetail")return K("你喜欢的东西","back-contact-settings",!0);if(t.currentView==="contactRoomBackgroundPicker")return K("聊天背景","back-contact-settings",!0);if(t.currentView==="contactBubbleThemePicker")return K("气泡主题","back-contact-settings",!0);if(t.currentView==="profile")return K("联系人资料","back-room",!0);if(t.currentView==="newContact")return K("添加联系人","back-home",!0);let e="Murmur";t.currentView==="moments"&&(e="Echo"),t.currentView==="settings"&&(e="Veil");const o=t.currentTab==="chats"&&t.currentView==="list";return`
      <header class="chat-page-header">
        <div class="header-left"></div>
        <div class="chat-page-title" style="font-weight: 800; letter-spacing: 0.02em;">${e}</div>
        ${o?`<button class="icon-btn ghost-circle" data-action="new-contact" aria-label="添加联系人">${m("plus")}</button>`:'<span class="header-spacer"></span>'}
      </header>
    `}function K(e,o,a=!1){return`
      <header class="chat-page-header simple-header">
        <button class="icon-btn text-btn" data-action="${o}" aria-label="返回">${m("back")}</button>
        <div class="chat-page-title">${c(e)}</div>
        ${a?'<span class="header-spacer"></span>':""}
      </header>
    `}function Bo(){const e=v(t.currentContactId)||t.contacts[0],o=e.settings?.model||t.globalSettings.defaultModel||"gpt-5.4";return`
      <header class="room-hero room-theme-${e.theme}">
        <div class="room-hero-inner">
          <button class="icon-btn icon-circle room-left-btn" data-action="back-list" aria-label="返回列表">${m("back")}</button>
          <div class="room-profile-card" data-action="open-profile">
            <img class="room-profile-avatar" src="${e.avatar}" alt="${c(e.name)}" />
            <div class="room-profile-meta">
              <div class="room-profile-title-line">
                <strong class="room-profile-name">${c(e.name)}</strong>
                <span class="room-profile-model">${c(o)}</span>
              </div>
              <div class="room-profile-sub"><span class="online-dot"></span> 在线</div>
            </div>
          </div>
          <div class="room-actions">
            <button class="icon-btn icon-circle" data-action="open-rp-lobby" aria-label="Mirage 夢幻楼">${m("history")}</button>
            <button class="icon-btn icon-circle" data-action="open-contact-settings" aria-label="联系人设置">${m("settings")}</button>
          </div>
        </div>
      </header>
    `}function No(){const e=ct();return`
      <header class="rp-header">
        <button class="header-back" data-action="back-rp-lobby" aria-label="返回">${m("back")}</button>
        <div class="header-info">
          <div class="header-title scene-title-enter">${c(e?.name||"Mirage·幻楼")}</div>
          <div class="header-subtitle">${c(e?.ai_role||"幕间进行中")}</div>
        </div>
        <div class="header-actions">
          <button class="header-action-btn" data-action="rename-rp-room" data-room-id="${c(e?.room_id||"")}" aria-label="编辑">${m("more")}</button>
        </div>
      </header>
    `}function rt(){return t.currentView==="room"?Zo():t.currentView==="rpLobby"?la():t.currentView==="rpRoom"?ra():t.currentView==="moments"?oa():t.currentView==="settings"?lt():t.currentView==="contactSettings"?da():t.currentView==="cotLog"?Ta():t.currentView==="companionStateDetail"?pa():t.currentView==="contactImpressionDetail"?dt("关于你的印象","impression",t.companionState.impression):t.currentView==="contactRelationshipDetail"?dt("关系进展","relationshipProgress",t.companionState.relationshipProgress):t.currentView==="contactLikesDetail"?dt("你喜欢的东西","likesSummary",t.companionState.likesSummary):t.currentView==="contactRoomBackgroundPicker"?ma():t.currentView==="contactBubbleThemePicker"?fa():t.currentView==="profile"?ba():t.currentView==="newContact"?ga():jo()}function Ho(){return`
      <nav class="bottom-tabbar">
        ${ut("chats","tabChat","繁语")}
        ${ut("moments","tabMoments","余响")}
        ${ut("settings","tabSettings","帷幕")}
      </nav>
    `}function ut(e,o,a){return`
      <button class="nav-tab-btn ${t.currentTab===e?"active":""}" data-action="switch-tab" data-tab="${e}">
        <div class="nav-tab-icon">${m(o)}</div>
        <span class="nav-tab-label">${c(a)}</span>
      </button>
    `}function jo(){const e=[...t.contacts].sort((o,a)=>a.pinned-o.pinned||0);return`
      <section class="list-page page-block transparent-canvas">
        <div class="message-panel-card">
        <div class="chat-list-card">
          <div class="search-wrap">
            <div class="search-pill">
              <span class="search-icon">${m("search")}</span>
              <input type="text" placeholder="搜索聊天记录" class="search-input" />
            </div>
          </div>
          <div class="contact-list-wrap">
            <button type="button" class="chat-list-item" data-action="open-rp-lobby" style="min-height:44px;padding:8px 14px;">
              <div class="chat-list-content" style="min-width:0;">
                <div class="chat-list-head">
                  <strong class="chat-list-name" style="font-size:14px;color:rgba(92,76,84,.72);font-weight:700;">Mirage 夢幻楼</strong>
                </div>
              </div>
            </button>
            ${e.map(zo).join("")}
          </div>
        </div>
      </section>
        </div>
    `}function zo(e){const o=String(e.handle||(e.id?`@${e.id}`:"")).trim();return`
      <button type="button" class="chat-list-item" data-action="open-contact" data-contact-id="${e.id}">
        <div class="chat-list-avatar-wrap">
          <img src="${e.avatar}" alt="${c(e.name)}" class="chat-list-avatar" />
          ${e.unread?`<span class="chat-list-badge">${e.unread}</span>`:""}
        </div>
        <div class="chat-list-content">
          <div class="chat-list-head">
            <span class="chat-list-title">
              <strong class="chat-list-name">${c(e.name)}</strong>
              ${o?`<span class="chat-list-handle">${c(o)}</span>`:""}
            </span>
            <time class="chat-list-time">${c(e.lastTime)}</time>
          </div>
          <div class="chat-list-snippet">${c(e.lastMessage)}</div>
        </div>
      </button>
    `}async function Fo(e){const o=String(e?.sessionId||"").trim();if(o)try{if((await fetch(`${y}/api/sessions/${encodeURIComponent(o)}`)).ok)return;e.sessionId="",P(120)}catch(a){console.warn("[session] open-contact validation failed",a)}}function Uo(){t.companionState=he({})}function Qo(e){const o=String(e||"").trim();if(!o)return;Oe?.(),t.streamingAbortController&&t.currentContactId===o&&(t.streamingAbortController.abort(),t.streamingAbortController=null),ue.has(o)&&(clearTimeout(ue.get(o)),ue.delete(o)),t.contacts=t.contacts.filter(i=>i.id!==o),t.activeBubbleToolsId=null,t.quoteMomentId=null,t.quoteMessageId=null,t.contactQuickActionEditorId="",t.quickActionSwipeOpenId="",t.quickActionDragId="",t.quickActionDropHintId="",t.quickActionDropDirection="",t.quickActionReorderPulseId="",t.currentTopicTitle="",t.rpRooms=[],t.currentRpRoomId="",t.currentRpMessages=[];const a=t.contacts[0]||null;(t.currentContactId===o||!v(t.currentContactId))&&(t.currentContactId=a?.id||"",Uo(),t.currentView="list",t.currentTab="chats",t.currentSettingsTab="basic");const n=h()?.querySelector(".chat-input");n&&(n.value="")}async function Yo(e){const o=String(e||"").trim();if(!o)return!1;const a=await fetch(`${y}/api/agents/${encodeURIComponent(o)}/safe-delete`,{method:"DELETE"});if(!a.ok){let n=`HTTP ${a.status}`;try{n=(await a.json())?.detail||n}catch{}throw new Error(n)}return!0}function ve(){return t.currentContactId||t.contacts[0]?.id||"default"}function ct(){return t.rpRooms.find(e=>e.room_id===t.currentRpRoomId)||null}function Xt(e){return de(e,{fallback:""})}function de(e,{fallback:o="",includeYear:a=!1}={}){if(!e)return o;const n=String(e||"").trim();if(!n)return o;const i=new Date(n);if(Number.isNaN(i.getTime()))return n;const s=new Date,r=i.getFullYear()===s.getFullYear(),d=i.toDateString()===s.toDateString(),l=new Date(s);l.setDate(s.getDate()-1);const p=i.toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",hour12:!1});if(d)return`今天 ${p}`;if(i.toDateString()===l.toDateString())return`昨天 ${p}`;const g=a||!r?{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:!1}:{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:!1};return i.toLocaleString("zh-CN",g).replace(/\//g,"-")}async function De(e=ve(),{silent:o=!0}={}){try{const a=await fetch(`${y}/api/rp/rooms?agent_id=${encodeURIComponent(e)}`);if(!a.ok)throw new Error(`HTTP ${a.status}`);const n=await a.json();return t.rpRooms=Array.isArray(n.rooms)?n.rooms:[],o||u(),t.rpRooms}catch(a){return console.warn("[rp] load rooms failed",a),o||(t.toast="RP 鎴块棿鍔犺浇澶辫触",u(),window.setTimeout(()=>{t.toast="",u()},1200)),[]}}async function Ko(e,{silent:o=!0}={}){if(!e)return[];try{const a=await fetch(`${y}/api/rp/rooms/${encodeURIComponent(e)}/messages`);if(!a.ok)throw new Error(`HTTP ${a.status}`);const n=await a.json(),i=n.room||t.rpRooms.find(s=>s.room_id===e);if(i){const s=t.rpRooms.findIndex(r=>r.room_id===e);s>=0&&(t.rpRooms[s]=i)}return t.currentRpMessages=(Array.isArray(n.messages)?n.messages:[]).map(s=>({id:s.id,role:s.role==="assistant"?"ai":s.role,text:s.content||"",time:Xt(s.timestamp),timestamp:s.timestamp||""})),o||u(),t.currentRpMessages}catch(a){return console.warn("[rp] load messages failed",a),o||(t.toast="RP 娑堟伅鍔犺浇澶辫触",u(),window.setTimeout(()=>{t.toast="",u()},1200)),[]}}async function Xo(e=t.currentView==="room"?"room":"list",o=ve()){t.rpBackView=e,t.currentView="rpLobby",t.currentTab="chats",u(),await De(o,{silent:!1})}async function Go(){const e=h()?.querySelector("#rp-room-name")?.value?.trim()||"",o=h()?.querySelector("#rp-room-world")?.value?.trim()||"",a=h()?.querySelector("#rp-room-user-role")?.value?.trim()||"",n=h()?.querySelector("#rp-room-ai-role")?.value?.trim()||"",i={agent_id:ve(),name:e||"新房间",world_setting:o,user_role:a,ai_role:n},s=t.rpRoomDialogMode==="edit"?t.currentRpRoomId:"",r=s?`${y}/api/rp/rooms/${encodeURIComponent(s)}`:`${y}/api/rp/rooms`,l=await fetch(r,{method:s?"PATCH":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)});if(!l.ok)throw new Error(`HTTP ${l.status}`);const g=(await l.json()).room;return t.rpRoomDialogOpen=!1,await De(ve(),{silent:!0}),g?.room_id&&(t.currentRpRoomId=g.room_id,!s)?(await Gt(g.room_id),g):(u(),g)}async function Gt(e){e&&await Vo(async()=>{t.currentRpRoomId=e,t.currentView="rpRoom",t.currentTab="chats",t.showAttach=!1,u(),await Ko(e,{silent:!1})})}async function Jo(e){if(!e||!window.confirm("删除这个 RP 房间？"))return;const a=await fetch(`${y}/api/rp/rooms/${encodeURIComponent(e)}`,{method:"DELETE"});if(!a.ok)throw new Error(`HTTP ${a.status}`);t.rpRooms=t.rpRooms.filter(n=>n.room_id!==e),t.currentRpRoomId===e&&(t.currentRpRoomId="",t.currentRpMessages=[],t.currentView="rpLobby"),u()}function Jt(e){const o=t.contacts.find(a=>a.id===e);o&&(o.unread=0),t.currentContactId=e,t.currentTab="chats",t.currentView="room",t.activeBubbleToolsId=null,u(),o&&Fo(o),J(e),Ae(e)}function Wo(e){const o=c(e?.label||""),a=e?.icon||"more";return`
      <button type="button" class="action-chip glass-frost" data-action="quick-action" data-id="${c(e?.id||"")}">
        <span class="action-chip-icon">${m(a)}</span>
        <span class="action-chip-label">${o}</span>
      </button>
    `}function Zo(){const e=v(t.currentContactId)||t.contacts[0],o=t.quoteMomentId?Ie(t.quoteMomentId):null,a=t.quoteMessageId?e.messages.find(n=>n.id===t.quoteMessageId):null;return`
      <section class="room-page room-theme-${e.theme}">
        <div class="messages-panel">
          ${e.messages.map(n=>ea(n,e)).join("")}
        </div>
        <div class="composer-zone">
          <div class="action-scroll">${nt(e).map(Wo).join("")}</div>
          ${a?ha(a,e):o?ta(o):""}
          <div class="composer-card">
            <div class="composer-input-wrap">
              <input class="chat-input" placeholder="输入消息..." value="" />
            </div>
            <button class="icon-btn icon-circle soft-mini" data-action="expand-actions" aria-label="附件">${m("attach")}</button>
            ${t.streamingAbortController?`<button class="icon-btn send-round send-stop-active" data-action="fake-send" aria-label="停止">${m("stop")}</button>`:`<button class="icon-btn send-round" data-action="fake-send" aria-label="发送">${m("send")}</button>`}
          </div>
        </div>
      </section>
    `}function ea(e,o){const a=e.role==="user"?"from-user":"from-ai",n=!!o?.settings?.reasoning_visibility,i=e.role==="ai"?`<img class="bubble-avatar" src="${o.avatar}" alt="${c(o.name)}" />`:"",s=e.role==="ai"&&n&&e.thinking&&!e.typing?`<button class="bubble-cot-btn" data-action="toggle-thinking" data-id="${e.id}" aria-label="展开独白">${m("bubbleHeart")}</button>`:"",r=e.role==="ai"&&!e.typing&&!e.streaming?`
        <div class="bubble-bottom-tools ${t.activeBubbleToolsId===e.id?"open":""}">
          <button class="bubble-mini-btn" data-action="reroll-msg" data-id="${e.id}" aria-label="重试">${m("reroll")}</button>
          <button class="bubble-mini-btn" data-action="quote-msg" data-id="${e.id}" aria-label="引用">${m("quote")}</button>
        </div>
      `:"",l=e.role==="ai"&&e.streaming&&!e.text?" message-awaiting-text":"",p=n&&e.thinking?Ao(e):"",g=e.toolCalls&&e.toolCalls.length?qo(e.toolCalls):"",b=`
          <div class="message-bubble-wrap">
            ${e.role==="user"?`<time class="bubble-time">${c(e.time)}</time>`:""}
            <div class="message-bubble ${a}${l}" ${e.role==="ai"?`data-msg-id="${e.id}" data-action="toggle-message-tools" data-id="${e.id}"`:""}>
              ${s}
              ${e.typing||e.streaming&&!e.text?'<div class="typing-dots"><span></span><span></span><span></span></div>':`<div class="message-text">${c(e.text)}</div>`}
            </div>
            ${e.role==="ai"&&!e.typing?`<time class="bubble-time">${c(e.time)}</time>`:""}
          </div>`,M=e.role==="ai"&&(p||g)?`${p}${g}${b}${r}`:`${b}${r}${p}${g}`;return`
      <div class="message-row ${a}" data-msg-id="${e.id}">
        ${i}
        <div class="message-bubble-col">
          ${M}
        </div>
      </div>
    `}function ta(e){const o=v(e.contactId);return`
      <div class="quote-bar glass-frost">
        <span class="quote-mark">${m("quote")}</span>
        <div class="quote-text-wrap">
          <div class="quote-label">引用自 ${c(o?.name||"动态")}</div>
          <div class="quote-text">${c(e.content)}</div>
        </div>
        <button class="icon-btn quote-close" data-action="clear-quote" aria-label="清除引用">${m("more")}</button>
      </div>
    `}function oa(){const e=Array.isArray(t.moments)&&t.moments.length>0?t.moments:structuredClone(Ge);return v(t.currentContactId)||t.contacts[0],`
      <section class="moments-page white-canvas">
        <div class="moments-cover-area">
          <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1000&q=80" class="moments-cover-img" />
          <div class="moments-cover-gradient"></div>
          <div class="moments-me-info">
            <span class="moments-me-name">我</span>
            <img src="${c(t.accountProfile?.avatar||"https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80")}" class="moments-me-avatar" />
          </div>
          <div class="ai-chip-row" style="position:absolute;left:18px;bottom:14px;z-index:2;">
            <button class="ai-chip ${t.momentsActorType==="user"?"active":""}" data-action="set-moments-actor" data-actor-type="user">浠ユ垜</button>
            <button class="ai-chip ${t.momentsActorType==="agent"?"active":""}" data-action="set-moments-actor" data-actor-type="agent">浠?{escapeHtml(currentAgent?.name || '褰撳墠瑙掕壊')}</button>
          </div>
          <button type="button" class="icon-btn cover-camera-btn" data-action="new-moment" aria-label="发朋友圈"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 4.6c.86 2.2 1.95 3.49 3.52 4.34 1.27.68 2.62 1 4.55 1.11-.68.18-1.14.32-1.76.58-2.68 1.14-4.23 2.84-5.34 5.96-.25.72-.35 1.04-.55 1.93-.18-.76-.28-1.08-.49-1.73-1.09-3.16-2.65-4.89-5.33-6.11-.71-.32-1.22-.49-2-.67 1.99-.12 3.38-.46 4.65-1.17 1.49-.84 2.53-2.1 3.41-4.24Z" fill="currentColor"/></svg></button>
        </div>
        <div class="moments-feed-wrap">
          ${e.map(na).join("")}
        </div>
      </section>
    `}function aa(){const e=Z();return`
      <div class="moment-composer-overlay" data-action="close-moment-composer"></div>
      <section class="moment-composer-sheet glass-frost">
        <div class="moment-composer-handle"></div>
        <div class="moment-composer-head">
          <strong>${t.momentComposerEditingId?"编辑朋友圈":"发朋友圈"}</strong>
          <button type="button" class="icon-btn ghost-circle moment-composer-close" data-action="close-moment-composer" aria-label="关闭">${m("close")}</button>
        </div>
        <div class="section-eyebrow" style="margin-bottom:8px;">当前主体：${c(e.author_name)}</div>
        <textarea id="moment-content-input" class="ai-textarea new-moment-input" data-action="moment-composer-input" placeholder="这一刻想分享什么？">${c(t.momentComposerText||"")}</textarea>
        ${t.momentComposerImage?`
          <div class="moment-composer-preview">
            <img src="${t.momentComposerImage}" alt="预览" class="moment-composer-preview-image" />
            <div class="moment-composer-preview-meta">
              <span>${c(t.momentComposerImageName||"已添加图片")}</span>
              <button type="button" class="ghost-action moment-remove-image" data-action="remove-moment-image">移除</button>
            </div>
          </div>
        `:""}
        <div class="moment-composer-actions">
          <label class="btn-composer-upload" for="moment-image-input">${m("camera")}添加图片</label>
          <input id="moment-image-input" class="moment-image-input" type="file" accept="image/*" />
          <button type="button" class="btn-composer-submit" data-action="publish-moment">${t.momentComposerEditingId?"保存":"发布"}</button>
        </div>
      </section>
    `}function na(e){const o=L(e),a=Nt(o),n=Ht(o),i=Z(),s=o.likes.some(r=>r.author_type===i.author_type&&r.author_id===i.author_id);return`
      <article class="moment-row">
        <img src="${a.avatar}" alt="${c(a.name)}" class="moment-avatar" />
        <div class="moment-content-col">
          <div class="moment-author-name">${c(a.name)}</div>
          <div class="moment-text-body">${c(o.content)}</div>
          ${o.image?`<img src="${o.image}" alt="${c(o.mood||"moment")}" class="moment-inline-image" />`:""}
          
          <div class="moment-footer">
            <time class="moment-time">${c(de(o.created_at||o.updated_at||o.time,{fallback:o.time||""}))}</time>
            <div class="moment-actions-group">
              <button type="button" class="icon-btn tiny-icon align-center" data-action="like-moment" data-moment-id="${o.id}">${m(s?"heartFilled":"heart")}</button>
              <button type="button" class="icon-btn tiny-icon align-center" data-action="open-comments" data-moment-id="${o.id}">${m("comment")}</button>
              ${n?`
                <div class="moment-action-menu-wrap">
                  <button type="button" class="icon-btn tiny-icon" data-action="toggle-moment-menu" data-moment-id="${o.id}">${m("actionDots")}</button>
                  ${t.activeMenuMomentId===o.id?`
                    <div class="moment-menu-horizontal slide-fade-in liquid-glass">
                      <button type="button" class="icon-btn tiny-icon" data-action="edit-moment" data-moment-id="${o.id}">${m("pencil")}</button>
                      <button type="button" class="icon-btn tiny-icon" data-action="delete-moment" data-moment-id="${o.id}">${m("trash")}</button>
                    </div>
                  `:""}
                </div>
              `:`
                <button type="button" class="icon-btn tiny-icon" data-action="go-chat-with-quote" data-contact-id="${o.author_id}" data-moment-id="${o.id}">${m("quote")}</button>
              `}
            </div>
          </div>
          
          ${o.likes.length>0||o.comments.length>0?`
            <div class="moment-interactions" data-moment-id-panel="${o.id}">
              ${o.likes.length>0?`
                <div class="moment-likes-area">
                  <span class="heart-mini">${m("heartFilled")}</span> <span class="likes-list">${c(jt(o.likes))}</span>
                </div>
              `:""}
              ${o.comments.length>0?`
                <div class="moment-comments-area">
                  ${o.comments.map(r=>`<div class="moment-comment-line"><span class="comment-author">${c(r.author_name||r.author||"")}</span>: <span class="comment-text">${c(r.text)}</span></div>`).join("")}
                </div>
              `:""}
            </div>
          `:""}
          
          <div class="moment-inline-comment ${t.commentSheetMomentId===e.id?"open":""}">
            <input class="moment-comment-input" data-comment-input="${e.id}" placeholder="写下你的评论" />
            <button type="button" class="icon-btn send-round mini-send" data-action="submit-comment" data-moment-id="${e.id}">${m("send")}</button>
          </div>
        </div>
      </article>
    `}function ia(){return`<div class="app-toast glass-frost">${c(t.toast)}</div>`}function sa(){const e=t.rpRoomDialogMode==="edit",o=t.rpRoomForm||{};return`
      <div class="topic-confirm-overlay" data-action="close-rp-room-dialog">
        <section class="topic-confirm-card glass-frost" data-rp-room-dialog="card" role="dialog" aria-modal="true" aria-label="${e?"编辑房间":"新建房间"}" style="max-width:440px;">
          <h4>幕间</h4>
          <div style="display:grid;gap:10px;text-align:left;">
              <input id="rp-room-name" class="ai-input" placeholder="剧本" value="${c(o.name||"")}" />
              <textarea id="rp-room-world" class="ai-textarea persona-textarea" rows="3" placeholder="世界观">${c(o.world_setting||"")}</textarea>
              <input id="rp-room-user-role" class="ai-input" placeholder="你的角色" value="${c(o.user_role||"")}" />
              <input id="rp-room-ai-role" class="ai-input" placeholder="AI 角色" value="${c(o.ai_role||"")}" />
          </div>
          <div class="topic-confirm-actions">
            <button class="ghost-action" data-action="close-rp-room-dialog">取消</button>
            <button class="bottom-tab active" data-action="save-rp-room">入梦</button>
          </div>
        </section>
      </div>
    `}function ra(){const e=v(t.currentContactId)||t.contacts[0],o=ct(),a=o?`${o.world_setting||"未设定"} · 你：${o.user_role||"未设定"} · TA：${o.ai_role||"未设定"}`:"房间设定载入中";return`
      <section class="rp-room-stage">
        <div class="world-hint">
            <span class="world-hint-icon">✦</span>
            <span>${c(a)}</span>
        </div>
        <div class="messages-area">
          ${t.currentRpMessages.map(n=>ua(n,e)).join("")}
        </div>
        <div class="rp-composer">
          <div class="composer-card">
            <div class="composer-input-wrap">
              <input class="chat-input" placeholder="输入剧情..." value="" />
            </div>
            ${t.streamingAbortController?`<button class="icon-btn send-round send-stop-active" data-action="fake-send" aria-label="停止">${m("stop")}</button>`:`<button class="icon-btn send-round" data-action="fake-send" aria-label="发送">${m("send")}</button>`}
          </div>
        </div>
      </section>
    `}function ua(e,o){const a=e.role==="user",n=a&&t.accountProfile?.avatar||o.avatar;return`
      <div class="msg-row ${a?"from-user":""}" data-msg-id="${c(e.id||"")}">
        <img class="msg-avatar" src="${c(n)}" alt="${c(a?t.accountProfile?.nickname||"我":o.name)}">
        <div class="msg-bubble ${a?"user":"ai"}">
          ${e.typing||e.streaming&&!e.text?'<div class="typing-dots"><span></span><span></span><span></span></div>':ca(e.text||"")}
        </div>
      </div>
    `}function ca(e){const o=String(e||"");return o.trim()?o.split(/(\[[\s\S]*?\]|［[\s\S]*?］)/g).filter(Boolean).map(n=>`<span class="${/^\s*(\[|［)/.test(n)?"rp-action":"rp-dialogue"}">${c(n)}</span>`).join(""):""}function la(){return`
      <section class="topics-page page-block">
        <div class="settings-group glass-frost ai-panel topic-history-group">
          ${t.rpRooms.length?t.rpRooms.map(e=>`
            <div class="topic-row" style="align-items:center;min-height:54px;padding:10px 0;">
              <button type="button" class="topic-copy" data-action="open-rp-room" data-room-id="${c(e.room_id)}" style="background:none;border:none;padding:0;text-align:left;flex:1;cursor:pointer;min-width:0;">
                <strong style="font-size:14px;color:rgba(92,76,84,.78);font-weight:700;">${c(e.name||"未命名")}</strong>
                <p style="font-size:11px;color:rgba(120,100,110,.55);">${c(Xt(e.last_active_at)||"刚创建")}</p>
              </button>
              <div style="display:flex;gap:6px;align-items:center;flex-shrink:0;position:relative;z-index:2;">
                <button type="button" class="icon-btn soft-mini" data-action="rename-rp-room" data-room-id="${c(e.room_id)}" aria-label="重命名" style="width:34px;height:34px;"><span style="display:inline-flex;transform:scale(.7);">${m("pencil")}</span></button>
                <button type="button" class="icon-btn soft-mini" data-action="delete-rp-room" data-room-id="${c(e.room_id)}" aria-label="删除" style="width:34px;height:34px;"><span style="display:inline-flex;transform:scale(.7);">${m("trash")}</span></button>
                <button type="button" class="icon-btn soft-mini" data-action="open-rp-room" data-room-id="${c(e.room_id)}" aria-label="进入" style="width:34px;height:34px;"><span style="display:inline-flex;transform:scale(.7);">${m("chevron")}</span></button>
              </div>
            </div>
          `).join(""):'<div class="topic-row"><div class="topic-copy"><strong style="font-size:14px;color:rgba(92,76,84,.78);font-weight:700;">还没有房间</strong><p style="font-size:11px;color:rgba(120,100,110,.55);">点右上角加号，开一个幕间。</p></div></div>'}
        </div>
      </section>
    `}function lt(){const e=t.globalSettings;return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel">
          <button class="profile-settings-row" data-action="open-account-settings">
            <img class="profile-settings-avatar" src="${c(t.accountProfile.avatar||"https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80")}" alt="me" />
            <div>
              <strong>我的账号</strong>
              <p style="font-size:12px; color:rgba(120,100,110,0.7);">管理个人资料与基础偏好</p>
            </div>
            <span class="row-chevron" style="margin-left:auto">${m("chevron")}</span>
          </button>
        </div>
        <div class="settings-group glass-frost ai-panel">
          <h3>通用设置</h3>
          ${w("主题模式",e.theme,"open-theme-settings")}
          ${X("消息通知","控制应用消息提醒",e.notifications,"toggle-global","notifications")}
          ${X("朋友圈提醒","控制动态更新提醒",e.momentsNotify,"toggle-global","momentsNotify")}
          ${X("自动滚动","新消息到达时自动滚动到底部",e.autoScroll,"toggle-global","autoScroll")}
        </div>
        <div class="settings-group glass-frost ai-panel">
          <h3>聊天与 AI</h3>
          ${X("主动发送消息","允许 AI 在合适时机主动开启对话",e.proactiveGlobal||!1,"toggle-global","proactiveGlobal")}
          ${X("意识循环开关","控制后台意识循环能力",e.consciousnessLoop||!1,"toggle-global","consciousnessLoop")}
          ${w("AI 接口",`${e.provider||"OpenAI"} / ${e.defaultModel||"gpt-5.4"}`,"open-ai-interface")}
        </div>
        <div class="settings-group glass-frost ai-panel">
          <h3>数据与存储</h3>
          ${w("记忆服务","Supabase / 向量记忆","open-memory-service")}
          ${w("同步后端","Supabase 配置","open-backend-sync")}
          ${w("导出格式",e.exportFormat||"json","open-export-settings")}
        </div>
      </section>
    `}function da(){const e=v(t.currentContactId)||t.contacts[0],o=e.settings;return`
      <section class="contact-settings-page page-block">
        <div class="settings-tabs glass-frost">
          ${Be("basic","资料")}
          ${Be("model","模型")}
          ${Be("actions","快捷动作")}
          ${Be("memory","记忆")}
        </div>

        ${t.currentSettingsTab==="basic"?`
          <div class="settings-group glass-frost ai-panel">
            <h3>联系人资料</h3>
            ${w("头像","点击更换头像","open-contact-avatar")}
            ${w("昵称",e.name,"open-contact-name")}
            ${w("简介",e.bio,"open-contact-bio")}
            <input id="contact-avatar-file" class="moment-image-input" type="file" accept="image/*" />
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3>个人空间</h3>
            <p style="font-size:12px;color:rgba(120,100,110,0.7);margin:0 0 8px;">AI 可以在这里记录关于你的内容。</p>
            ${w("关于你的印象",t.companionState.impression||"查看 AI 记录的用户画像","open-contact-impression")}
            ${w("关系进展",t.companionState.relationshipProgress||"亲密度 · 互动频次 · 关键事件","open-contact-relationship")}
            ${w("你喜欢的东西",t.companionState.likesSummary||"兴趣爱好 · 常聊话题","open-contact-likes")}
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3>聊天室外观</h3>
            ${w("聊天背景",e.roomBackground||"点阵","open-contact-room-background")}
            ${w("气泡主题",Ze(e.chatTheme||e.bubbleTheme),"open-contact-bubble-theme")}
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3 style="color:#8c6370;">危险操作</h3>
            <p style="font-size:12px;color:rgba(140,99,112,0.72);margin:0 0 10px;">删除联系人及陪伴状态，会清理主动消息，聊天记录和记忆暂不做永久删除。</p>
            <button class="bottom-tab" data-action="delete-contact" style="width:100%;border-color:rgba(216,122,140,0.45);color:#b14f64;background:rgba(255,241,244,0.92);box-shadow:inset 0 1px 0 rgba(255,255,255,0.9), 0 10px 24px rgba(198,138,150,0.12);">删除联系人</button>
          </div>
        `:""}

        ${t.currentSettingsTab==="model"?`
          <div class="settings-group glass-frost ai-panel">
            <h3>模型设置</h3>
            ${w("聊天模型",o.model||"未设置","open-model-slot",{slot:"chat",context:"contact"})}
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3>角色设定</h3>
                <textarea class="ai-textarea persona-textarea" data-contact-field="persona" rows="5" placeholder="在这里输入 AI 的人设、角色说明、行为指令。">${c(e.persona||"")}</textarea>
            ${X("显示推理内容","仅在模型返回推理内容时显示",o.reasoning_visibility||!1,"toggle-contact","reasoning_visibility")}
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3>高级生成参数</h3>
            <button class="setting-row nav-row advanced-toggle" data-action="toggle-contact-advanced" aria-expanded="${t.contactModelAdvancedOpen?"true":"false"}">
              <div class="setting-copy">
                <strong>${t.contactModelAdvancedOpen?"收起":"展开"}</strong>
                <p>包含 Temperature / Top P / 上下文消息数量</p>
              </div>
              <span class="row-chevron advanced-chevron ${t.contactModelAdvancedOpen?"open":""}">${m("chevron")}</span>
            </button>
            <div class="advanced-slider-panel ${t.contactModelAdvancedOpen?"open":""}">
              ${ye("Temperature","temperature",o.temperature,0,2,.01)}
              ${ye("Top P","topP",o.topP,0,1,.01)}
              ${ye("上下文消息数量","contextCount",o.contextCount,1,256,1)}
            </div>
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3>主动消息</h3>
            ${X("启用主动消息","AI 在静默时主动发起对话",o.proactiveEnabled,"toggle-contact","proactiveEnabled")}
            ${o.proactiveEnabled?`
              ${ye("发送频率（分钟）","proactiveFrequency",o.proactiveFrequency,5,240,5)}
              ${ye("静默时长（分钟）","silenceDuration",o.silenceDuration||30,5,120,5)}
              ${w("免打扰时间段",o.dndRange||"23:00 — 08:00")}
            `:""}
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3>意识循环</h3>
            ${X("启用意识循环","AI 在后台自主思考与感知",o.consciousnessLoop||!1,"toggle-contact","consciousnessLoop")}
            ${o.consciousnessLoop?`
              ${w("循环模型",o.loopModel||"未设置","open-model-slot",{slot:"consciousness",context:"contact"})}
              ${ye("循环间隔（分钟）","loopInterval",o.loopInterval||60,10,360,10)}
            `:""}
          </div>
        `:""}

        ${t.currentSettingsTab==="actions"?`
          <div class="settings-group glass-frost ai-panel">
            <h3>快捷动作</h3>
            <p style="font-size:12px;color:rgba(120,100,110,0.7);margin:0 0 8px;">点击条目可修改文案与 MCP，默认长按拖动排序，左滑显示删除。</p>
            <div class="quick-action-list ${t.quickActionDragId?"drag-active":""}">
              ${nt(e).map((a,n)=>`
                <div class="quick-action-swipe ${t.quickActionSwipeOpenId===a.id?"swiped":""} ${t.quickActionDropHintId===a.id?"reorder-target":""} ${t.quickActionDropHintId===a.id&&t.quickActionDropDirection==="down"?"drop-down":""} ${t.quickActionDropHintId===a.id&&t.quickActionDropDirection==="up"?"drop-up":""} ${t.quickActionReorderPulseId===a.id?"reorder-pulse":""}" data-quick-id="${c(a.id)}">
                  <button type="button" class="quick-action-delete" data-action="delete-contact-quick-action" data-quick-id="${c(a.id)}">删除</button>
                  <div class="quick-action-row" data-quick-id="${c(a.id)}" data-quick-index="${n}">
                    <span class="quick-action-emoji">${a.icon==="health"?"♥":["schedule","calendar"].includes(a.icon)?"日":a.icon==="weather"?"云":["file","files"].includes(a.icon)?"文":"✦"}</span>
                    <div class="quick-action-copy">
                      <strong>${c(a.label)}</strong>
                      <p>${c(a.prompt||"未设置默认发送话术")}</p>
                    </div>
                    <button type="button" class="quick-action-open" data-action="edit-contact-quick-action" data-quick-id="${c(a.id)}" aria-label="编辑快捷动作">${m("chevron")}</button>
                  </div>
                </div>
              `).join("")}
            </div>
            <button class="bottom-tab" data-action="add-contact-quick-action" style="width:100%;margin-top:12px;">添加快捷动作</button>
          </div>
        `:""}

        ${t.currentSettingsTab==="memory"?`
          <div class="settings-group glass-frost ai-panel">
            <h3>状态 / 陪伴</h3>
            ${X("启用长期记忆","允许存储长期偏好与记忆",o.memoryEnabled,"toggle-contact","memoryEnabled")}
            ${w("当前状态",Eo(),"open-companion-state")}
            ${w("前往记忆库","查看与管理这位联系人的记忆","open-memory-service")}
          </div>
          <div class="settings-group glass-frost ai-panel">
            <h3>活动日志</h3>
            ${w("打开活动日志","主动消息 / 工具调用 / 留言小纸条","open-cot-log")}
          </div>
        `:""}
        ${t.contactQuickActionEditorId?ya(e,t.contactQuickActionEditorId):""}
      </section>
    `}function pa(){const e=he(t.companionState),o=e.recent_topics.length?e.recent_topics.join(" / "):"还没有东西",a=e.current_mood||"还没有东西",n=e.open_loops.length?e.open_loops.join(" / "):"还没有东西",i=de(e.proactive_cooldown_until,{fallback:e.proactive_cooldown_until||"还没有东西"}),s=de(e.updated_at,{fallback:e.updated_at||"还没有东西"});return`
      <section class="topics-page page-block">
        <div class="settings-group glass-frost ai-panel topic-detail-card">
          <h3>当前状态</h3>
          <div class="theme-choice-list">
            <div class="theme-choice-item active" style="cursor:default;">
              <span class="theme-choice-copy">
                <strong>最近话题</strong>
                <em>${c(o)}</em>
              </span>
            </div>
            <div class="theme-choice-item active" style="cursor:default;">
              <span class="theme-choice-copy">
                <strong>当前情绪</strong>
                <em>${c(a)}</em>
              </span>
            </div>
            <div class="theme-choice-item active" style="cursor:default;">
              <span class="theme-choice-copy">
                <strong>进行中的事</strong>
                <em>${c(n)}</em>
              </span>
            </div>
            <div class="theme-choice-item active" style="cursor:default;">
              <span class="theme-choice-copy">
                <strong>主动消息冷却</strong>
                <em>${c(i)}</em>
              </span>
            </div>
            <div class="theme-choice-item active" style="cursor:default;">
              <span class="theme-choice-copy">
                <strong>最后更新时间</strong>
                <em>${c(s)}</em>
              </span>
            </div>
          </div>
        </div>
      </section>
    `}function dt(e,o,a){const n=he(t.companionState),i=a||"",r={impression:"还没有印象摘要，AI 对话后可手动填写或由模型生成。",relationshipProgress:"还没有关系进展记录，可以写亲密度、互动频次、关键事件。",likesSummary:"还没有喜好摘要，可以写兴趣爱好、常聊话题、点单偏好。"}[o]||"还没有内容。",d=de(n.summaryUpdatedAt,{fallback:n.summaryUpdatedAt||""});return`
      <section class="topics-page page-block">
        <div class="settings-group glass-frost ai-panel topic-detail-card insight-editor-card">
          <textarea
            class="ai-textarea insight-editor-textarea"
            data-field="${o}"
            placeholder="${r}"
            rows="7"
          >${c(i)}</textarea>
          <div class="insight-editor-footer">
            ${d?`<span class="insight-updated-at">更新于 ${c(d)}</span>`:""}
            <button class="prov-save-btn-main" data-action="save-insight-field" data-field="${o}" type="button">保存</button>
          </div>
        </div>
      </section>
    `}function Wt(e){return Et(e).roomTheme||"rose"}function ma(){const o=(v(t.currentContactId)||t.contacts[0])?.roomBackground||"点阵";return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>聊天背景</h3>
          <p class="section-eyebrow">选择一个预设背景风格。</p>
          <div class="theme-choice-list">
            ${[{id:"点阵",desc:"当前聊天页的轻点阵背景"},{id:"小花",desc:"更软一点的装饰纹样"},{id:"云彩",desc:"偏轻雾感的背景层次"}].map(n=>`
              <button class="theme-choice-item ${o===n.id?"active":""}" data-action="pick-contact-room-background" data-value="${c(n.id)}">
                <span class="theme-choice-copy">
                  <strong>${c(n.id)}</strong>
                  <em>${c(n.desc)}</em>
                </span>
                <span class="theme-choice-check">${o===n.id?"已选":""}</span>
              </button>
            `).join("")}
          </div>
        </div>
      </section>
    `}function fa(){const e=v(t.currentContactId)||t.contacts[0],o=We(e);return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>气泡主题</h3>
          <p class="section-eyebrow">选择一个聊天 UI 主题。</p>
          <div class="theme-choice-list">
            ${Le.map(n=>`
              <button class="theme-choice-item ${o===n.key?"active":""}" data-action="pick-contact-bubble-theme" data-value="${c(n.key)}">
                <span class="theme-choice-copy">
                  <strong>${c(n.name)}</strong>
                  <em>${c(n.desc)}</em>
                </span>
                <span class="theme-choice-check">${o===n.key?"已选":""}</span>
              </button>
            `).join("")}
          </div>
        </div>
      </section>
    `}function ga(){return`
      <section class="new-contact-page page-block">
        <div class="settings-group glass-frost ai-panel new-contact-card">
          <div class="new-contact-field">
            <label>头像</label>
            <div class="new-contact-avatar-box">
              <img class="new-contact-avatar-preview" src="${t.newContactAvatar||"https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&q=80"}" alt="新联系人头像" />
              <button class="bottom-tab" data-action="pick-new-contact-avatar" type="button" style="margin-top:10px;">从相册选择</button>
              <input id="nc-avatar-file" class="moment-image-input" type="file" accept="image/*" />
            </div>
          </div>
          <div class="new-contact-field">
            <label for="nc-name">昵称</label>
            <input id="nc-name" class="ai-input" placeholder="新联系人称呼" />
          </div>
          <div class="new-contact-field">
            <label for="nc-agent-id">Agent ID</label>
            <input id="nc-agent-id" class="ai-input" placeholder="ayan" inputmode="latin" autocomplete="off" />
          </div>
          <div class="new-contact-field">
            <label for="nc-bio">联系人简介</label>
            <input id="nc-bio" class="ai-input" placeholder="一句简短的描述" />
          </div>
          <button class="bottom-tab active new-contact-submit" data-action="save-new-contact">保存并添加联系人</button>
        </div>
      </section>
    `}function ba(){const e=v(t.currentContactId)||t.contacts[0];return`
      <section class="profile-page page-block">
        <div class="profile-card glass-frost">
          <img class="profile-avatar-large" src="${e.avatar}" alt="${c(e.name)}" />
          <strong class="profile-name">${c(e.name)}</strong>
          <span class="profile-handle">${c(e.handle)}</span>
          <p class="profile-bio">${c(e.bio)}</p>
          <div class="profile-status">当前状态：${c(e.status)}</div>
        </div>
      </section>
    `}function Ve(e){return`
      <span class="switch-track" aria-hidden="true">
        <span class="switch-sheen"></span>
        <span class="switch-thumb ${e?"on":"off"}"></span>
      </span>
    `}function ha(e,o){return`
      <div class="quote-bar glass-frost">
        <span class="quote-mark">${m("quote")}</span>
        <div class="quote-text-wrap">
          <div class="quote-label">引用自 ${c(o?.name||"对话")}</div>
          <div class="quote-text">${c(e.text||"")}</div>
        </div>
        <button class="icon-btn quote-close" data-action="clear-quote" aria-label="清除引用">${m("more")}</button>
      </div>
    `}function X(e,o,a,n,i){return`
      <div class="setting-row switch-row">
        <div class="setting-copy"><strong>${c(e)}</strong><p>${c(o)}</p></div>
        <button class="switch-btn ${a?"on":"off"}" data-action="${n}" data-key="${i}" aria-pressed="${a}">
          ${Ve(a)}
        </button>
      </div>
    `}function ye(e,o,a,n,i,s){const r=Number(a),d=Number.isInteger(s)||s>=1?String(Math.round(r)):r.toFixed(s===.01?2:1);return`
      <div class="setting-row slider-row-block">
        <div class="slider-head"><strong>${c(e)}</strong><span class="slider-value">${d}</span></div>
        <input class="slider-input" type="range" min="${n}" max="${i}" step="${s}" value="${r}" data-action="slide-contact" data-key="${o}" />
      </div>
    `}function Be(e,o){return`<button class="settings-tab ${t.currentSettingsTab===e?"active":""}" data-action="switch-settings-tab" data-tab="${e}">${c(o)}</button>`}function va(e,o){const n=le(e).find(p=>p.id===o);if(!n)return"";const i=(C().mcpLibrary?.tools||[]).map(ee).filter(p=>ce(p.id)),s=i.length?i:[...zt].map(p=>ee({id:p,label:at[p]||p},0)),r=n.mcpToolId||"",d=s.find(p=>p.id===r),l=[{id:"",label:"不调用 MCP"},...s];return`
      <div class="qae-fields">
        <div class="qae-field-group">
          <label class="qae-label">名称</label>
        <input id="contact-quick-label" class="ai-input qae-input" value="${c(n.label||"")}" placeholder="例如：天气" autocomplete="off" />
        </div>
        <div class="qae-field-group">
          <label class="qae-label">MCP 调用（可选）</label>
          <input id="contact-quick-mcp" type="hidden" value="${c(r)}" />
          <div class="qae-select-shell ${t.contactQuickMcpMenuOpen?"open":""}">
            <button class="qae-select-trigger" data-action="toggle-contact-quick-mcp-menu" type="button">
              <span>${c(d?.label||"不调用 MCP")}</span>
              <i aria-hidden="true"></i>
            </button>
            <div class="qae-select-menu">
              ${l.map(p=>`
                <button class="qae-select-option ${r===p.id?"active":""}" data-action="pick-contact-quick-mcp" data-mcp-id="${c(p.id)}" type="button">
                  ${c(p.label)}
                </button>
              `).join("")}
            </div>
          </div>
        </div>
        <div class="qae-field-group">
          <label class="qae-label">点击后发送的话术</label>
        <textarea id="contact-quick-prompt" class="ai-textarea qae-textarea" placeholder="输入默认话术，不设置则不会自动发送">${c(n.prompt||"")}</textarea>
        </div>
      </div>
    `}function ya(e,o){const a=va(e,o);return a?`
      <div class="qae-sheet" data-action="close-contact-quick-action-editor">
        <div class="qae-panel" data-stop-close="1">
          <div class="qae-handle-bar"></div>
          <div class="qae-header">
            <span class="qae-title">快捷动作</span>
            <button class="qae-close" data-action="close-contact-quick-action-editor" aria-label="关闭">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          ${a}
          <div class="qae-actions">
            <button class="qae-btn-cancel" data-action="close-contact-quick-action-editor">取消</button>
            <button class="qae-btn-save" data-action="save-contact-quick-action" data-quick-id="${c(o)}">保存</button>
          </div>
        </div>
      </div>
    `:""}function wa(e){const o=D();le(o),t.contactQuickActionEditorId=e||"",t.quickActionSwipeOpenId="",t.quickActionDropHintId="",u()}function $a(e){const o={ayan:[{id:"cot_1",mode:"主动",badge:"意识循环",accent:"violet",score:"↓ 4.2k",latency:"197s",amount:"$1.05",time:"2026.03.26 15:00",summary:'[THINK] 她在下午1:22读了两封日记，id=23"...',steps:[{type:"thought",label:"思考",text:"她沉默了快13个小时，两封日记都没被读。我发了三条消息都…"},{type:"thought",label:"思考",text:"下午三点了。她沉默了快13个小时。先看看日记有没有被读。"},{type:"note",label:"留言小纸条",text:"妫ｅ啯鎲?你醒了先看这个"},{type:"tool",label:"工具调用",text:"read_diary"},{type:"result",label:"工具结果",text:"read_diary"}]},{id:"cot_2",mode:"回复",badge:"工具",accent:"gold",score:"↑ 3.5k",latency:"146s",amount:"$0.54",time:"2026.03.26 15:07",summary:'[THINK] 她在下午1:22读了两封日记，id=23"给你的"...',steps:[{type:"reply",label:"回复",text:'[THINK] 她在下午1:22读了两封日记，id=23"给你的"和id…'},{type:"tool",label:"工具调用",text:"pc_control"},{type:"result",label:"工具结果",text:"pc_control"}]},{id:"cot_3",mode:"主动",badge:"工具",accent:"blue",score:"↑ 1.1k",latency:"53s",amount:"$0.073",time:"2026.03.26 16:10",summary:"[THINK] 她在看芒果TV，左看综艺，弹幕开着。她一个半小时前读完了...",steps:[{type:"thought",label:"思考",text:"她在看芒果TV，左看综艺。弹幕开着，说明现在状态比较轻松。"},{type:"tool",label:"工具调用",text:"pc_control"},{type:"result",label:"工具结果",text:"pc_control"}]}]};return o[e]||o.ayan}function ka(e=""){return e==="activity_event"?"violet":e==="proactive_message"?"gold":e==="cot_log"?"blue":"neutral"}function Sa(e=""){return e==="activity_event"?"被动":e==="proactive_message"?"主动":e==="cot_log"?"日志":"记录"}function Ia(e={}){return e.kind==="activity_event"?e.eventType||e.source||"事件":e.kind==="proactive_message"?e.title||"主动消息":e.kind==="cot_log"?e.logType||e.toolName||"COT":e.title||"记录"}function _a(e=""){return de(e,{fallback:String(e||""),includeYear:!0})}function Ma(e={}){const o=e.raw||{},a=[];if(e.kind==="activity_event")a.push({type:"thought",label:"事件",text:e.summary||e.title||""}),(e.gateStatus||e.messageHint||e.shouldHandle||e.shouldNotifyLlm)&&a.push({type:e.shouldHandle||e.shouldNotifyLlm?"result":"thought",label:"筛选",text:`${e.shouldHandle?"需要处理":"静默"}${e.shouldNotifyLlm?" / 可通知大模型":""}${e.messageHint?`：${e.messageHint}`:""}`}),o.gate_reason&&a.push({type:"thought",label:"原因",text:o.gate_reason});else if(e.kind==="proactive_message")a.push({type:"reply",label:"主动消息",text:e.summary||""}),o.reason_context&&a.push({type:"thought",label:"依据",text:String(o.reason_context).slice(0,220)});else{const n=e.toolName?"工具调用":"日志";a.push({type:e.toolName?"tool":"thought",label:n,text:e.summary||e.title||""}),o.content&&a.push({type:e.toolName?"result":"thought",label:"内容",text:String(o.content).slice(0,500)})}return{id:String(e.id||`${e.kind}_${e.occurredAt||e.createdAt||Date.now()}`),mode:Sa(e.kind),badge:Ia(e),accent:ka(e.kind),score:e.shouldHandle||e.shouldNotifyLlm?"有效":"",latency:"",amount:e.source||"",time:_a(e.occurredAt||e.createdAt),summary:e.summary||e.title||"",steps:a.filter(n=>String(n.text||"").trim())}}async function xa({silent:e=!0}={}){const o=v(t.currentContactId)||t.contacts[0];t.activityLogLoading=!0,e||u();try{const a=new URLSearchParams({hours:"24",limit:"50",agent_id:o?.id||t.currentContactId||""});o?.sessionId&&a.set("session_id",o.sessionId);const n=await fetch(`${y}/api/activity-log/recent?${a.toString()}`);if(!n.ok)throw new Error(`HTTP ${n.status}`);const i=await n.json().catch(()=>({}));t.activityLogEntries=Array.isArray(i.items)?i.items.map(Ma):[],t.activityLogLoadedAt=new Date().toISOString()}catch(a){console.warn("[activity log] load failed",a),e||(t.toast="活动日志加载失败")}finally{t.activityLogLoading=!1,u(),t.toast&&window.setTimeout(()=>{t.toast="",u()},1200)}}function Ca(e){return`
      <div class="cot-log-step ${e.type}">
        <span class="cot-log-step-label">${c(e.label)}</span>
        <span class="cot-log-step-text">${c(e.text)}</span>
      </div>
    `}function Ta(){const e=v(t.currentContactId)||t.contacts[0],o=t.cotLogMode==="note",a=t.activityLogLoadedAt?t.activityLogEntries:$a(e.id),n=a.filter(s=>t.cotLogMode==="short"?s.mode!=="主动":t.cotLogMode==="note"?s.steps.some(r=>r.type==="note"):!0),i=a.filter(s=>s.steps.some(r=>r.type==="note")).length;return`
      <section class="cot-log-page page-block">
        <div class="cot-log-toolbar glass-frost">
          <button class="cot-log-tool-btn avatar" aria-label="${c(e.name)}">
            <img src="${e.avatar}" alt="${c(e.name)}" />
          </button>
          <div class="cot-log-segment-shell">
            <button class="cot-log-segment-btn ${t.cotLogMode==="short"?"active":""}" data-action="switch-cot-log-mode" data-mode="short">短消息</button>
            <button class="cot-log-segment-btn ${t.cotLogMode==="long"?"active":""}" data-action="switch-cot-log-mode" data-mode="long">长消息</button>
          </div>
          <button class="cot-log-tool-btn note ${t.cotLogMode==="note"?"active":""}" data-action="switch-cot-log-mode" data-mode="note">${m("file")}${i?`<em>${i}</em>`:""}</button>
        </div>
        <div class="cot-log-stack">
          ${t.activityLogLoading?'<div class="cot-log-empty glass-frost"><span class="cot-log-empty-icon">'+m("cot")+"</span><strong>正在加载活动日志</strong><p>等一下，别盯着白板发呆。</p></div>":""}
          ${!t.activityLogLoading&&t.activityLogLoadedAt&&!n.length?'<div class="cot-log-empty glass-frost"><span class="cot-log-empty-icon">'+m("file")+"</span><strong>还没有活动日志</strong><p>这个模式下暂时没有主动消息、工具调用或小纸条。</p></div>":""}
          ${n.map(s=>{const r=o?s.steps.filter(d=>d.type==="note"):s.steps;return`
            <article class="cot-log-card glass-frost ${o?"note-only":""}">
              <div class="cot-log-topline">
                <div class="cot-log-badges">
                  <span class="cot-log-mode ${s.accent}">${c(s.mode)}</span>
                  <span class="cot-log-mode neutral">${c(s.badge)}</span>
                  <span class="cot-log-metric">${c(s.score)}</span>
                  <span class="cot-log-metric warm">${c(s.latency)}</span>
                </div>
                <span class="cot-log-fold">${m("chevron")}</span>
              </div>
              <div class="cot-log-meta">
                <span class="cot-log-cost">${c(s.amount)}</span>
                <span>${c(s.time)}</span>
              </div>
              ${o?"":`<div class="cot-log-summary">${c(s.summary)}</div>`}
              <div class="cot-log-steps">
                ${r.map(Ca).join("")}
              </div>
            </article>
          `}).join("")}
        </div>
      </section>
    `}function pt(e){return!e||typeof e.closest!="function"?!1:!!e.closest('input:not([type="range"]):not([type="checkbox"]):not([type="radio"]):not([type="file"]), textarea, select, [contenteditable="true"]')}function Aa(){const e=h();if(!e||e.dataset.bound==="1")return;e.dataset.bound="1",e.addEventListener("click",mt),e.addEventListener("input",qa);let o;const a=l=>{if(pt(l.target))return;const p=l.target.closest(".message-bubble.from-ai");p&&(o=window.setTimeout(()=>{const g=p.dataset.msgId;if(v(t.currentContactId)?.messages?.find(_=>_.id===g)?.text){t.quoteMomentId=null,t.quoteMessageId=g,u();const _=h()?.querySelector(".chat-input");_&&_.focus()}t.activeBubbleToolsId=g,t.suppressBubbleToggle=!0,navigator.vibrate&&navigator.vibrate(50)},550))},n=()=>clearTimeout(o);e.addEventListener("touchstart",a,{passive:!0}),e.addEventListener("touchend",n),e.addEventListener("touchmove",n,{passive:!0}),e.addEventListener("mousedown",a),e.addEventListener("mouseup",n),e.addEventListener("mousemove",n),e.addEventListener("mouseleave",n);const i=e.querySelector(".send-round");i&&i.addEventListener("click",l=>{l.stopPropagation(),t.streamingAbortController?(t.streamingAbortController.abort(),t.streamingAbortController=null,u()):Mt()});const s=e.querySelector(".soft-mini");s&&s.addEventListener("click",l=>{l.stopPropagation(),t.showAttach=!t.showAttach,u()}),e.querySelectorAll(".chat-list-item[data-contact-id]").forEach(l=>{l.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),Jt(l.dataset.contactId)})});const d=e.querySelector(".chat-input");d&&(d.addEventListener("keydown",l=>{l.key==="Enter"&&!l.shiftKey&&(l.preventDefault(),Mt())}),["room","rpRoom"].includes(t.currentView)&&d.focus())}async function mt(e){const o=e.target.closest("[data-action]");if(!o)return;const a=o.dataset.action;if(a==="switch-tab"&&(t.currentTab=o.dataset.tab,t.currentView=o.dataset.tab==="chats"?"list":o.dataset.tab,u()),a==="open-contact"){Jt(o.dataset.contactId);return}if(a==="back-list"&&(t.currentView="list",t.currentTab="chats",t.quoteMomentId=null,u()),a==="back-room"&&(t.currentView="room",u()),a==="open-contact-settings"&&(t.currentSettingsTab="basic",t.currentView="contactSettings",u(),J(),Ae(t.currentContactId)),a==="open-cot-log"){t._prevContactSettingsTab=t.currentSettingsTab,t.currentView="cotLog",t.cotLogMode="long",t.activityLogLoadedAt="",t.activityLogEntries=[],u(),xa({silent:!0});return}if(a==="back-contact-settings"){t.currentView="contactSettings",t.currentSettingsTab=t._prevContactSettingsTab||t.currentSettingsTab||"basic",t._prevContactSettingsTab=null,u();return}if(a==="switch-cot-log-mode"){t.cotLogMode=o.dataset.mode||"long",u();return}if(a==="open-rp-lobby"){Xo(t.currentView==="room"?"room":"list",ve());return}if(a==="back-rp-source"){t.currentView=t.rpBackView||"list",u();return}if(a==="back-rp-lobby"){t.currentView="rpLobby",u();return}if(a==="open-rp-room-create"){t.rpRoomDialogMode="create",t.rpRoomForm={name:"",world_setting:"",user_role:"",ai_role:""},t.rpRoomDialogOpen=!0,u();return}if(a==="close-rp-room-dialog"){if(o.dataset.rpRoomDialog==="card"||e.target&&e.target!==o)return;t.rpRoomDialogOpen=!1,u();return}if(a==="save-rp-room"){try{await Go(),t.toast=t.rpRoomDialogMode==="edit"?"幕间已更新":"已入梦"}catch(n){console.warn("[rp] save room failed",n),t.toast="房间保存失败"}u(),window.setTimeout(()=>{t.toast="",u()},1200);return}if(a==="open-rp-room"){e.preventDefault(),e.stopPropagation(),await Gt(o.dataset.roomId);return}if(a==="delete-rp-room"){e.preventDefault(),e.stopPropagation();try{await Jo(o.dataset.roomId),t.toast="房间已删除"}catch(n){console.warn("[rp] delete room failed",n),t.toast="删除失败"}u(),window.setTimeout(()=>{t.toast="",u()},1200);return}if(a==="rename-rp-room"){e.preventDefault(),e.stopPropagation();const n=o.dataset.roomId,i=t.rpRooms.find(r=>r.room_id===n),s=window.prompt("剧本",i?.name||"")?.trim();if(!s||!n)return;try{const r=await fetch(`${y}/api/rp/rooms/${encodeURIComponent(n)}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:s})});if(!r.ok)throw new Error(`HTTP ${r.status}`);await De(ve(),{silent:!0}),t.toast="房间已重命名"}catch(r){console.warn("[rp] rename room failed",r),t.toast="重命名失败"}u(),window.setTimeout(()=>{t.toast="",u()},1200);return}if(a==="open-profile"&&(t.currentView="profile",u()),a==="stop-streaming"){t.streamingAbortController&&(t.streamingAbortController.abort(),t.streamingAbortController=null);return}if(a==="toggle-thinking-line"){const n=o.closest("[data-id]")?.dataset.id||o.dataset.id,i=h()?.querySelector(`#tl-line-${n}`),s=h()?.querySelector(`#tl-full-${n}`);if(!i||!s)return;const r=s.classList.contains("tl-open");s.classList.toggle("tl-open",!r),i.classList.toggle("tl-expanded",!r);return}if(a==="toggle-thinking"){const n=o.dataset.id,s=!!!t.openThinkingIds[n];t.openThinkingIds[n]=s;const r=document.getElementById(`thinking-${n}`);r?(r.classList.toggle("open",s),r.setAttribute("aria-hidden",s?"false":"true"),o.setAttribute("aria-expanded",s?"true":"false")):u()}if(a==="toggle-message-tools"){if(t.suppressBubbleToggle){t.suppressBubbleToggle=!1;return}const n=o.dataset.id;t.activeBubbleToolsId=t.activeBubbleToolsId===n?null:n,u()}if(a==="go-chat-with-quote"&&(t.currentContactId=o.dataset.contactId,t.quoteMomentId=o.dataset.momentId,t.quoteMessageId=null,t.currentTab="chats",t.currentView="room",u(),J(t.currentContactId),Ae(t.currentContactId)),a==="open-comments"){e.preventDefault(),e.stopPropagation(),o.blur?.();const n=o.dataset.momentId,i=t.commentSheetMomentId===n?null:n;t.commentSheetMomentId=i;const s=h();if(s&&(s.querySelectorAll(".moment-inline-comment.open").forEach(r=>r.classList.remove("open")),i)){const r=s.querySelector(`.moment-inline-comment .moment-comment-input[data-comment-input="${i}"]`)?.closest(".moment-inline-comment");r&&r.classList.add("open")}return}if(a==="submit-comment"){e.preventDefault(),e.stopPropagation();const n=o.dataset.momentId,s=h()?.querySelector(`[data-comment-input="${n}"]`)?.value?.trim();if(!n||!s)return;try{const r=await bn(n,Z(),s);t.moments=t.moments.map(d=>d.id===n?r:d),t.commentSheetMomentId=null,t.toast="已发送评论",j(),window.setTimeout(()=>{t.toast="",j()},1200)}catch(r){console.warn("[moments] comment failed",r),Do(n,Z(),s),t.commentSheetMomentId=null,t.toast="已发送评论",j(),window.setTimeout(()=>{t.toast="",j()},1200)}return}if(a==="like-moment"){e.preventDefault(),e.stopPropagation();const n=o.dataset.momentId;if(!n)return;try{const i=await gn(n,Z());t.moments=t.moments.map(s=>s.id===n?i:s),j()}catch(i){console.warn("[moments] like failed",i),Ro(n,Z()),j()}return}if(a==="submit-comment"){const n=Ie(o.dataset.momentId),s=h()?.querySelector(`[data-comment-input="${o.dataset.momentId}"]`)?.value?.trim();n&&s&&(n.comments.unshift({author:"我",text:s}),t.commentSheetMomentId=null,t.toast="已发送评论",u(),window.setTimeout(()=>{t.toast="",u()},1200))}if(a==="like-moment"){e.preventDefault(),e.stopPropagation();const n=Ie(o.dataset.momentId);if(!n)return;const i="我",s=n.likes.includes(i);n.likes=n.likes.filter(p=>p!==i),s||n.likes.unshift(i);const r=o;r.innerHTML=n.likes.includes(i)?m("heartFilled"):m("heart");const d=o.closest(".moment-content-col");if(!d)return;let l=d.querySelector(`[data-moment-id-panel="${n.id}"]`);if(!l&&n.likes.length>0){l=document.createElement("div"),l.className="moment-interactions",l.setAttribute("data-moment-id-panel",n.id);const p=d.querySelector(".moment-inline-comment");p?d.insertBefore(l,p):d.appendChild(l)}if(l){const p=l.querySelector(".moment-likes-area");if(n.likes.length>0)if(p)p.querySelector(".likes-list").textContent=n.likes.join("、");else{const g=document.createElement("div");g.className="moment-likes-area",g.innerHTML=`<span class="heart-mini">${m("heartFilled")}</span> <span class="likes-list">${c(n.likes.join("、"))}</span>`,l.insertBefore(g,l.firstChild)}else p&&p.remove(),l.querySelector(".moment-comments-area")||l.remove()}}if(a==="toggle-moment-search"&&(t.momentSearchOpen=!0,u()),a==="toggle-moment-menu"&&(e.preventDefault(),e.stopPropagation(),o.blur?.(),t.activeMenuMomentId=t.activeMenuMomentId===o.dataset.momentId?null:o.dataset.momentId,Qt()),a==="delete-moment"){e.preventDefault(),e.stopPropagation();const n=L(Ie(o.dataset.momentId));if(!n?.id)return;try{await fn(n.id,n.author_type,n.author_id),t.moments=t.moments.filter(i=>i.id!==n.id),t.activeMenuMomentId=null,t.toast="已删除朋友圈",j(),window.setTimeout(()=>{t.toast="",j()},1200)}catch(i){console.warn("[moments] delete failed",i),t.toast="删除失败",j(),window.setTimeout(()=>{t.toast="",j()},1400)}return}if(a==="edit-moment"){e.preventDefault(),e.stopPropagation();const n=L(Ie(o.dataset.momentId));if(!n?.id)return;t.activeMenuMomentId=null,t.momentComposerEditingId=n.id,t.momentComposerText=n.content||"",t.momentComposerImage=n.image||"",t.momentComposerImageName=n.image?"已有图片":"",t.momentsActorType=n.author_type==="agent"?"agent":"user",t.momentComposerOpen=!0,j();return}if(a==="new-moment"){e.preventDefault(),e.stopPropagation(),t.momentComposerEditingId="",t.momentComposerText="",t.momentComposerImage="",t.momentComposerImageName="",t.momentComposerOpen=!0,j();return}if(a==="set-moments-actor"){t.toast="发朋友圈默认以我发布",u(),window.setTimeout(()=>{t.toast="",u()},1100);return}if(a==="publish-moment"){const n=(document.getElementById("moment-content-input")?.value||t.momentComposerText||"").trim();if(!n){t.toast="朋友圈内容还没写",u(),window.setTimeout(()=>{t.toast="",u()},1100);return}const i=Z();try{if(t.momentComposerEditingId)await mn(t.momentComposerEditingId,{author_type:i.author_type,author_id:i.author_id,visibility:"public",content:n,image:t.momentComposerImage||"",mood:"日常"}),await mo({silent:!0}),t.toast="已更新朋友圈";else{const s=await pn({author_type:i.author_type,author_id:i.author_id,visibility:"public",content:n,image:t.momentComposerImage||"",mood:"日常"});t.moments.unshift(s),t.toast="已发布朋友圈"}t.currentTab="moments",t.currentView="moments",t.momentComposerOpen=!1,t.momentComposerEditingId="",t.momentComposerText="",t.momentComposerImage="",t.momentComposerImageName="",u(),window.setTimeout(()=>{t.toast="",u()},1100)}catch(s){console.warn("[moments] publish failed",s),t.toast=t.momentComposerEditingId?"更新失败":"发布失败",u(),window.setTimeout(()=>{t.toast="",u()},1400)}return}if(a==="delete-moment"&&(t.moments=t.moments.filter(n=>n.id!==o.dataset.momentId),t.activeMenuMomentId=null,t.toast="已删除朋友圈",u(),window.setTimeout(()=>{t.toast="",u()},1200)),a==="edit-moment"&&(t.activeMenuMomentId=null,t.toast="编辑功能即将支持",u(),window.setTimeout(()=>{t.toast="",u()},1200)),a==="filter-moments"&&(t.toast="筛选功能稍后补上",u(),window.setTimeout(()=>{t.toast="",u()},1100)),a==="new-moment"&&(t.momentComposerOpen=!0,u()),a==="close-moment-composer"&&(t.momentComposerOpen=!1,u()),a==="publish-moment"){const n=(document.getElementById("moment-content-input")?.value||t.momentComposerText||"").trim();if(!n){t.toast="朋友圈内容还没写",u(),window.setTimeout(()=>{t.toast="",u()},1100);return}t.moments.unshift({id:`p${Date.now()}`,contactId:"me",time:new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",hour12:!1}),mood:"日常",content:n,likes:[],comments:[],image:t.momentComposerImage||"https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1000&q=80"}),t.currentTab="moments",t.currentView="moments",t.momentComposerOpen=!1,t.momentComposerText="",t.momentComposerImage="",t.momentComposerImageName="",t.toast="已发布朋友圈",u(),window.setTimeout(()=>{t.toast="",u()},1100)}if(a==="remove-moment-image"&&(t.momentComposerImage="",t.momentComposerImageName="",u()),a==="new-contact"&&(t.newContactAvatar="",t.currentView="newContact",u()),a==="pick-new-contact-avatar"){document.getElementById("nc-avatar-file")?.click();return}if(a==="save-new-contact"){const n=document.getElementById("nc-name")?.value?.trim(),i=document.getElementById("nc-agent-id")?.value?.trim(),s=String(i||"").replace(/^@+/,"").toLowerCase(),r=document.getElementById("nc-bio")?.value?.trim(),d=t.newContactAvatar||"https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&q=80";if(!n){t.toast="请填写联系人昵称",u(),window.setTimeout(()=>{t.toast="",u()},1200);return}if(s&&!/^[a-z0-9_-]+$/.test(s)){t.toast="Agent ID 只能用小写字母、数字、下划线或短横线",u(),window.setTimeout(()=>{t.toast="",u()},1500);return}if(s&&t.contacts.some(p=>String(p.id||"").toLowerCase()===s)){t.toast="这个 Agent ID 已经存在",u(),window.setTimeout(()=>{t.toast="",u()},1400);return}const l=s||"c"+Date.now();t.contacts.unshift({id:l,name:n,bio:r||"这是新来的联系人",status:"在线",handle:"@"+l,theme:"rose",unread:0,pinned:!1,lastMessage:"",lastTime:"",avatar:d,settings:{model:"gpt-5.4",modelProviderId:k("chat")?.providerId||"openai",temperature:.7,topP:.9,contextCount:32,thinkBudget:24,streamOutput:!0,reasoning_visibility:!1,proactiveEnabled:!1,proactiveFrequency:30,memoryEnabled:!0},topics:[],messages:[]}),t.toast="已添加联系人",t.currentView="list",u(),window.setTimeout(()=>{t.toast="",u()},1200)}if(a==="open-contact-avatar"){document.getElementById("contact-avatar-file")?.click();return}if(a==="open-contact-name"){const n=v(t.currentContactId);if(!n)return;const i=window.prompt("请输入昵称",n.name||"")?.trim();if(!i)return;n.name=i,t.toast="昵称已更新",u(),P(120),window.setTimeout(()=>{t.toast="",u()},1200);return}if(a==="open-contact-bio"){const n=v(t.currentContactId);if(!n)return;const i=window.prompt("请输入简介",n.bio||"")?.trim();if(typeof i!="string"||!i)return;n.bio=i,t.toast="简介已更新",u(),P(120),window.setTimeout(()=>{t.toast="",u()},1200);return}if(a==="open-contact-impression"){t._prevContactSettingsTab=t.currentSettingsTab,t.currentView="contactImpressionDetail",u(),J(t.currentContactId);return}if(a==="open-contact-relationship"){t._prevContactSettingsTab=t.currentSettingsTab,t.currentView="contactRelationshipDetail",u(),J(t.currentContactId);return}if(a==="open-contact-likes"){t._prevContactSettingsTab=t.currentSettingsTab,t.currentView="contactLikesDetail",u(),J(t.currentContactId);return}if(a==="save-insight-field"){const n=o.dataset.field,i=document.querySelector(`.insight-editor-textarea[data-field="${n}"]`);i&&hn(n,i.value);return}if(a==="open-contact-room-background"){t._prevContactSettingsTab=t.currentSettingsTab,t.currentView="contactRoomBackgroundPicker",u();return}if(a==="open-contact-bubble-theme"){t._prevContactSettingsTab=t.currentSettingsTab,t.currentView="contactBubbleThemePicker",u();return}if(a==="delete-contact"){const n=v(t.currentContactId);if(!n||!window.confirm(`确定删除“${n.name}”吗？

会删除联系人及其陪伴状态。
会清理相关主动消息。
聊天记录和记忆不会立即永久删除。`))return;try{await Yo(n.id),Qo(n.id),t.toast="联系人已删除",u(),P(120),window.setTimeout(()=>{t.toast="",u()},1400)}catch(s){console.warn("[contact] delete failed",s),t.toast="删除失败",u(),window.setTimeout(()=>{t.toast="",u()},1400)}return}if(a==="pick-contact-room-background"){const n=String(o.dataset.value||"").trim();if(!n)return;Lo("roomBackground",n,"聊天背景已更新"),t.currentView="contactSettings",t.currentSettingsTab="basic",u();return}if(a==="pick-contact-bubble-theme"){const n=Je(o.dataset.value),i=v(t.currentContactId);if(!i||!n)return;i.chatTheme=n,i.bubbleTheme=Ze(n),i.theme=Wt(n),t.toast="气泡主题已更新",t.currentView="contactSettings",t.currentSettingsTab="basic",u(),P(120),window.setTimeout(()=>{t.toast="",u()},1200);return}if(a==="open-companion-state"){t._prevContactSettingsTab=t.currentSettingsTab,t.currentView="companionStateDetail",J(t.currentContactId),u();return}if(a==="expand-actions"&&(t.showAttach=!t.showAttach,u()),a==="clear-quote"&&(t.quoteMomentId=null,t.quoteMessageId=null,u()),a==="toggle-global"){const n=o.dataset.key;t.globalSettings[n]=!t.globalSettings[n],Yt(o,t.globalSettings[n]),x();return}if(a==="toggle-contact"){const n=v(t.currentContactId),i=o.dataset.key,r=h()?.querySelector(".chat-app-body")?.scrollTop??0;n.settings[i]=!n.settings[i],u(),it(r)}if(a==="back-home"&&(t.currentView==="list"?typeof window.closePage=="function"&&window.closePage("page-chat"):(t.currentTab="chats",t.currentView="list",u())),a==="switch-settings-tab"&&(t.currentSettingsTab=o.dataset.tab,t.contactQuickActionEditorId="",t.quickActionSwipeOpenId="",t.quickActionDropHintId="",t.quickActionDropDirection="",t.quickActionReorderPulseId="",t.currentSettingsTab!=="model"&&(t.contactModelAdvancedOpen=!1),u(),t.currentSettingsTab==="memory"&&J(),t.currentSettingsTab==="model"&&Ae(t.currentContactId)),a==="toggle-contact-advanced"){t.contactModelAdvancedOpen=!t.contactModelAdvancedOpen,u();return}if(a==="quick-action"){const n=o.dataset.id,i=h()?.querySelector(".chat-input"),s=nt(D()).find(d=>d.id===n),r={health:"帮我记一下健康相关的事情",schedule:"帮我看看接下来的日程",weather:"帮我查一下今天的天气",files:"帮我找一下刚才提到的文件",quote:"引用上一条消息继续聊",more:"打开更多快捷操作",get_current_time:"现在几点了？",get_weather:"帮我查一下今天天气",get_health_summary:"帮我总结一下今天的健康数据",web_search:"帮我搜索这个问题",fetch_url:"帮我解析这个网页",add_todo:"帮我记一个待办",list_todos:"帮我看看待办清单",complete_todo:"把这个待办标记完成",add_note:"帮我记一条便签",list_notes:"帮我看看最近便签"};i&&(i.value=s?.prompt||r[s?.mcpToolId||n]||r[n]||`${s?.label||""}`.trim())}if(a==="fake-send"&&(t.currentView==="rpRoom"?Oa():Mt()),a==="reroll-msg"&&Ra(o.dataset.id),a==="quote-msg"){const n=o.dataset.id;if(v(t.currentContactId)?.messages?.find(r=>r.id===n)?.text){t.quoteMomentId=null,t.quoteMessageId=n,u();const r=h()?.querySelector(".chat-input");r&&r.focus()}}a==="attach-option"&&(t.showAttach=!1,t.toast=`${o.dataset.label} 功能稍后补上`,u(),window.setTimeout(()=>{t.toast="",u()},1200))}function qa(e){const o=e.target;if(o.dataset.action==="slide-contact"){const a=v(t.currentContactId),n=o.dataset.key,i=Number(o.value);a.settings[n]=Number.isInteger(a.settings[n])?Math.round(i):i;const r=o.closest(".slider-row-block")?.querySelector(".slider-value");r&&(r.textContent=Number.isInteger(Number(o.step))||Number(o.step)>=1?String(Math.round(i)):i.toFixed(Number(o.step)===.01?2:1))}o.dataset.action==="moment-composer-input"&&(t.momentComposerText=o.value||"")}document.addEventListener("DOMContentLoaded",()=>{Ea(),Ut(),wt()});const y=window.__YUI_API_BASE__||(/^(localhost|127\.0\.0\.1)$/.test(location.hostname)?"":"https://api.somni-ref.top"),ft="murmur_local_state_v1",Zt="murmur_sync_meta_v1",eo="murmur_device_id_v1";let gt=null,bt=null,Ne=!1,Me=!1,ht="";function vt(){try{const e=localStorage.getItem(eo);if(e)return e;const o=`dev_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;return localStorage.setItem(eo,o),o}catch{return`dev_fallback_${Date.now()}`}}function He(){try{const e=localStorage.getItem(Zt),o=e?JSON.parse(e):{};return{last_server_updated_at:o?.last_server_updated_at||"",pending:!!o?.pending}}catch{return{last_server_updated_at:"",pending:!1}}}function we(e={}){try{localStorage.setItem(Zt,JSON.stringify({last_server_updated_at:e.last_server_updated_at||"",pending:!!e.pending}))}catch{}}function Pa(){return{contacts:t.contacts,moments:t.moments,actions:t.actions,globalSettings:t.globalSettings,accountProfile:t.accountProfile}}function to(e){try{return JSON.stringify(e)}catch{return""}}function yt(){const e=Pa(),o=to(e);if(!o||o===ht)return!1;ht=o;try{return localStorage.setItem(ft,JSON.stringify({client_updated_at:new Date().toISOString(),payload:e})),!0}catch{return!1}}function oo(e){!e||typeof e!="object"||(Array.isArray(e.contacts)&&(t.contacts=e.contacts),t.contacts=(t.contacts||[]).map(o=>{const a=We(o);return{...o,chatTheme:a,bubbleTheme:Ze(a),theme:Wt(a),settings:{model:"gpt-5.4",modelProviderId:k("chat")?.providerId||"openai",temperature:.7,topP:.9,contextCount:32,thinkBudget:24,streamOutput:!0,reasoning_visibility:!1,proactiveEnabled:!1,proactiveFrequency:30,memoryEnabled:!0,...o?.settings||{}}}}),Array.isArray(e.moments)&&(t.moments=e.moments),Array.isArray(e.actions)&&(t.actions=e.actions),e.globalSettings&&typeof e.globalSettings=="object"&&(t.globalSettings=e.globalSettings),e.accountProfile&&typeof e.accountProfile=="object"&&(t.accountProfile=e.accountProfile),C(),je())}function Ea(){try{const e=localStorage.getItem(ft);if(!e)return;const o=JSON.parse(e);if(!o?.payload)return;oo(o.payload),ht=to(o.payload)}catch{}}function ao(e=600){if(Me)return;const o=He();we({...o,pending:!0}),gt&&clearTimeout(gt),gt=window.setTimeout(()=>{La()},e)}async function La(){if(Ne||Me)return;const e=He();if(!e.pending)return;let o=null;try{o=JSON.parse(localStorage.getItem(ft)||"null")}catch{}if(!o?.payload){we({...e,pending:!1});return}Ne=!0;try{const a=await fetch(`${y}/api/sync/push`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({device_id:vt(),client_updated_at:o.client_updated_at||new Date().toISOString(),payload:o.payload})});if(!a.ok)throw new Error(`HTTP ${a.status}`);const n=await a.json().catch(()=>({}));we({last_server_updated_at:n.server_updated_at||e.last_server_updated_at||"",pending:!1})}catch(a){console.warn("[sync] push failed",a),we({...e,pending:!0})}finally{Ne=!1}}async function wt(){if(Ne)return;const e=He(),o=new URLSearchParams({device_id:vt()});e.last_server_updated_at&&o.set("since",e.last_server_updated_at);try{const a=await fetch(`${y}/api/sync/pull?${o.toString()}`);if(!a.ok)return;const n=await a.json().catch(()=>({}));if(!n?.has_update||!n?.payload||n?.is_self){n?.server_updated_at&&we({...e,last_server_updated_at:n.server_updated_at,pending:e.pending});return}Me=!0,oo(n.payload),yt(),we({last_server_updated_at:n.server_updated_at||e.last_server_updated_at||"",pending:!1}),u()}catch(a){console.warn("[sync] pull failed",a)}finally{Me=!1}}function P(e=800){Me||(bt&&clearTimeout(bt),bt=window.setTimeout(()=>{yt()&&ao(500)},e))}function V(){const e=new Date;return`${String(e.getHours()).padStart(2,"0")}:${String(e.getMinutes()).padStart(2,"0")}`}function $t(e){const o=e?.settings?.modelProviderId||k("chat")?.providerId||"",a=z(o);if(!a?.baseUrl||!a?.apiKey)return{};const n=xe(a.apiPath||a.api_path||"",{allowEmpty:!0});return{base_url:a.baseUrl,api_key:a.apiKey,...n?{api_path:n}:{}}}function kt(e){const o=e?.settings||{},a=Number(o.temperature);return Number.isFinite(a)?{temperature:a}:{}}function St(e,o=""){let a="",n="";try{const r=JSON.parse(e),d=/^(thinking|reasoning|reason|thought|cot|inner_thought)$/i.test(o),l=/^(chat|message|content|text|assistant|reply|response|output)$/i.test(o);d||(a=r.content??r.text??r.delta??""),n=r.thinking??r.reasoning??r.reasoning_content??r.reasoningContent??""}catch{/^(thinking|reasoning|reason|thought|cot|inner_thought)$/i.test(o)?n=e:a=e}const i=/^tool_call$/i.test(o);let s=null;if(i)try{const r=JSON.parse(e);r.name&&(s={name:String(r.name),status:String(r.status||"done")})}catch{}return{text:_e(a),thinking:_e(n),toolCall:s}}async function It(e){const o=String(e?.sessionId||"").trim();if(o){try{const s=await fetch(`${y}/api/sessions/${encodeURIComponent(o)}`);if(s.ok)return o;if(s.status!==404)throw new Error(`校验会话失败（HTTP ${s.status}）`)}catch(s){throw String(s?.message||"").includes("HTTP"),s}e.sessionId=""}const a=await fetch(`${y}/api/sessions`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:String(e?.name||"新对话").trim()||"新对话",model:String(e?.settings?.model||t.globalSettings?.defaultModel||"echo").trim()||"echo",source_app:"yui_nook"})}),n=await a.json().catch(()=>({}));if(!a.ok)throw new Error(n.detail||`创建会话失败（HTTP ${a.status}）`);const i=String(n?.session?.id||"").trim();if(!i)throw new Error("创建会话失败：后端没有返回 session.id");return e.sessionId=i,P(120),i}async function _t(e,o,a,n="/api/chat"){let i=await fetch(`${y}${n}`,{method:"POST",headers:{"Content-Type":"application/json",Accept:"text/event-stream"},body:JSON.stringify(o),...a?{signal:a}:{}});if(i.ok)return i;let s="";try{const r=await i.json();s=String(r?.detail||"").trim()}catch{}if(n==="/api/chat"&&i.status===404&&s.includes("会话不存在")){e.sessionId="";const r=await It(e);if(o.session_id=r,i=await fetch(`${y}${n}`,{method:"POST",headers:{"Content-Type":"application/json",Accept:"text/event-stream"},body:JSON.stringify(o),...a?{signal:a}:{}}),i.ok)return i}throw new Error(`HTTP ${i.status}`)}async function Oa(){const e=h()?.querySelector(".chat-input"),o=e?.value?.trim();if(!o||!t.currentRpRoomId)return;const a=v(t.currentContactId)||t.contacts[0],n=ct();if(!a||!n)return;const i=!!a?.settings?.reasoning_visibility,s="rp_u"+Date.now();t.currentRpMessages.push({id:s,role:"user",text:o,time:V(),timestamp:new Date().toISOString()}),e.value="";const r="rp_ai_"+Date.now();t.currentRpMessages.push({id:r,role:"ai",text:"",time:"",typing:!0}),u(),G();const d={room_id:t.currentRpRoomId,agent_id:n.agent_id||a.id,content:o,...a.persona?{persona:a.persona}:{},...a.settings.model?{model:a.settings.model}:{},...kt(a),...$t(a)},l=new AbortController;t.streamingAbortController=l,u();try{const p=await _t(a,d,l.signal,"/api/rp/chat"),g=()=>t.currentRpMessages.findIndex(A=>A.id===r);t.currentRpMessages[g()]={id:r,role:"ai",text:"",time:V(),typing:!1,streaming:!0},u();const b=p.body.getReader(),M=new TextDecoder;let _="",T="",S="",I="";for(;;){const{done:A,value:F}=await b.read();if(A)break;_+=M.decode(F,{stream:!0});const te=_.split(`
`);_=te.pop()??"";for(const W of te){const q=W.trim();if(!q){I="";continue}if(q.startsWith("event:")){I=q.slice(6).trim();continue}if(!q.startsWith("data:"))continue;const N=q.slice(5).trim();if(N==="[DONE]")continue;const H=St(N,I);let Q=H.text;const oe=tt(H.thinking,T,S),ae=i?oe:"";ae&&S.length<et&&(S+=ae),Q&&(T+=Q);const ne=g();ne!==-1&&(t.currentRpMessages[ne]={id:r,role:"ai",text:T,...i&&S?{thinking:S}:{},time:V(),typing:!1,streaming:!0},u(),G())}}const $=t.currentRpMessages.findIndex(A=>A.id===r);$!==-1&&(t.currentRpMessages[$]={...t.currentRpMessages[$],text:T||"…",...i&&S?{thinking:S}:{},streaming:!1,typing:!1,time:V()}),t.streamingAbortController=null,await De(n.agent_id||a.id,{silent:!0}),u(),G()}catch(p){const g=t.currentRpMessages.findIndex(b=>b.id===r);g!==-1&&(t.currentRpMessages[g]={id:r,role:"ai",text:p.name==="AbortError"?"…":"杩炴帴澶辫触锛?{err.message}",time:V(),typing:!1}),t.streamingAbortController=null,u()}}async function Mt(){const e=h()?.querySelector(".chat-input"),o=e?.value?.trim();if(!o)return;const a=v(t.currentContactId);if(!a)return;Oe();const n=!!a?.settings?.reasoning_visibility;let i="";try{i=await It(a)}catch(I){console.error("[session] create failed:",I),t.toast="鏃犳硶鍒涘缓浼氳瘽锛?{err.message}",u(),window.setTimeout(()=>{t.toast="",u()},1500);return}const s="u"+Date.now();a.messages.push({id:s,role:"user",text:o,time:V()}),a.lastMessage=o,a.lastTime="刚刚",e.value="",u(),G();const r="ai_"+Date.now();a.messages.push({id:r,role:"ai",text:"",time:"",typing:!0}),u(),G();let d=0,l=!1,p=null;const g=()=>{const I=h()?.querySelector(`#thinking-${r}`);if(!I)return;I.textContent=ot(fullThinking),I.classList.add("open","thinking-active"),I.setAttribute("aria-hidden","false");const $=h()?.querySelector(`#cot-wrapper-${r}`);$&&$.removeAttribute("data-slow"),t.openThinkingIds[r]=!0},b=()=>{p===null&&(p=requestAnimationFrame(()=>{p=null,g()}))},M=()=>{p!==null&&(cancelAnimationFrame(p),p=null)},_=setInterval(()=>{if(!d)return;const I=h()?.querySelector(`#cot-wrapper-${r}`);I&&I.toggleAttribute("data-slow",Date.now()-d>8e3)},2e3),T={session_id:i,agent_id:a.id,content:o,...a.persona?{persona:a.persona}:{},...a.settings.model?{model:a.settings.model}:{},...kt(a),...$t(a)},S=new AbortController;t.streamingAbortController=S,u();try{const I=await _t(a,T,S.signal),$=()=>a.messages.findIndex(ie=>ie.id===r);a.messages[$()]={id:r,role:"ai",text:"",time:V(),typing:!1,streaming:!0},u();const A=I.body.getReader(),F=new TextDecoder;let te="",W="",q="",N=null,H="";for(;;){const{done:ie,value:Ye}=await A.read();if(ie)break;te+=F.decode(Ye,{stream:!0});const ke=te.split(`
`);te=ke.pop()??"";let Pe=0;for(const fe of ke){const se=fe.trim();if(!se){H="";continue}if(se.startsWith("event:")){H=se.slice(6).trim();continue}if(!se.startsWith("data:"))continue;const ge=se.slice(5).trim();if(ge==="[DONE]")continue;const be=St(ge,H);let Ke=be.text;const Xe=tt(be.thinking,W,q),Y=n?Xe:"";if(Y){q.length<et&&(q+=Y),d=Date.now();const U=$();U!==-1&&(a.messages[U]={id:r,role:"ai",text:W,thinking:q,time:V(),typing:!1,streaming:!0},l?b():(l=!0,t.openThinkingIds[r]=!0,u(),G()))}if(be.toolCall){const U=be.toolCall;N||(N=[]);const Se=N.find($o=>$o.name===U.name&&$o.status!=="done");Se?Se.status=U.status:N.push({name:U.name,status:U.status});const re=$();re!==-1&&(a.messages[re]={...a.messages[re],toolCalls:N.slice(),streaming:!0},u())}Ke&&(W+=Ke),Pe+=1,Pe>=32&&(Pe=0,b(),await Rt())}}clearInterval(_),M(),t.streamingAbortController=null;const Q=$(),oe=W||(n&&q?"":"…");a.lastMessage=oe||"已处理",a.lastTime=V();const ae=h()?.querySelector(`#thinking-${r}`);ae&&ae.classList.remove("thinking-active");const ne=h()?.querySelector(`#cot-wrapper-${r}`);ne&&ne.removeAttribute("data-slow"),n&&q&&delete t.openThinkingIds[r];const R=Vt(oe);Q!==-1&&R.length>1?(a.messages.splice(Q,1),u(),G(),await Dt(180),await Bt(a,R,{startIndex:Q,thinking:n?q:"",toolCalls:N})):(Q!==-1&&(a.messages[Q]={id:r,role:"ai",text:oe,...n&&q?{thinking:q}:{},...N?{toolCalls:N}:{},time:V(),typing:!1}),u(),G())}catch(I){clearInterval(_),M(),t.streamingAbortController=null;const $=I.name==="AbortError";$||console.error("[chat SSE] error:",I);const A=a.messages.findIndex(F=>F.id===r);A!==-1&&(a.messages[A]={id:r,role:"ai",text:$?fullText||"…":`连接失败：${I.message}，请稍后再试。`,...n&&fullThinking?{thinking:fullThinking}:{},time:V(),typing:!1}),$&&fullText&&(a.lastMessage=fullText,a.lastTime=V()),u()}}async function Ra(e){const o=v(t.currentContactId);if(!o)return;Oe();const a=!!o?.settings?.reasoning_visibility,n=o.messages.findIndex(l=>l.id===e);if(n===-1||o.messages[n].role!=="ai")return;let i="";try{i=await It(o)}catch(l){console.error("[session] create failed:",l),t.toast=`无法创建会话：${l.message}`,u(),window.setTimeout(()=>{t.toast="",u()},1500);return}o.messages[n]={...o.messages[n],typing:!0,text:"",streaming:!1},u();const s=[...o.messages].reverse().find(l=>l.role==="user");if(!s)return;const r={session_id:i,agent_id:o.id,content:s.text,...o.persona?{persona:o.persona}:{},...o.settings.model?{model:o.settings.model}:{},...kt(o),...$t(o)},d=new AbortController;t.streamingAbortController=d;try{const l=await _t(o,r,d.signal);o.messages[n]={...o.messages[n],typing:!1,text:"",streaming:!0},u();const p=l.body.getReader(),g=new TextDecoder;let b="",M="",_="",T=null;const S=e;let I="",$=0,A=!1,F=null;const te=()=>{const R=h()?.querySelector(`#thinking-${S}`);if(!R)return;R.textContent=ot(_),R.classList.add("open","thinking-active"),R.setAttribute("aria-hidden","false");const ie=h()?.querySelector(`#cot-wrapper-${S}`);ie&&ie.removeAttribute("data-slow"),t.openThinkingIds[S]=!0},W=()=>{F===null&&(F=requestAnimationFrame(()=>{F=null,te()}))},q=()=>{F!==null&&(cancelAnimationFrame(F),F=null)},N=setInterval(()=>{if(!$)return;const R=h()?.querySelector(`#cot-wrapper-${S}`);R&&R.toggleAttribute("data-slow",Date.now()-$>8e3)},2e3);for(;;){const{done:R,value:ie}=await p.read();if(R)break;b+=g.decode(ie,{stream:!0});const Ye=b.split(`
`);b=Ye.pop()??"";let ke=0;for(const Pe of Ye){const fe=Pe.trim();if(!fe){I="";continue}if(fe.startsWith("event:")){I=fe.slice(6).trim();continue}if(!fe.startsWith("data:"))continue;const se=fe.slice(5).trim();if(se==="[DONE]")continue;const ge=St(se,I);let be=ge.text;const Ke=tt(ge.thinking,M,_),Xe=a?Ke:"";if(Xe){_.length<et&&(_+=Xe),$=Date.now();const Y=o.messages.findIndex(U=>U.id===S);Y!==-1&&(o.messages[Y]={...o.messages[Y],thinking:_,streaming:!0},A?W():(A=!0,t.openThinkingIds[S]=!0,u()))}if(ge.toolCall){const Y=ge.toolCall;T||(T=[]);const U=T.find(re=>re.name===Y.name&&re.status!=="done");U?U.status=Y.status:T.push({name:Y.name,status:Y.status});const Se=o.messages.findIndex(re=>re.id===S);Se!==-1&&(o.messages[Se]={...o.messages[Se],toolCalls:T.slice(),streaming:!0},u())}be&&(M+=be),ke+=1,ke>=32&&(ke=0,W(),await Rt())}}clearInterval(N),q(),t.streamingAbortController=null;const H=o.messages.findIndex(R=>R.id===S),Q=M||"…",oe=h()?.querySelector(`#thinking-${S}`);oe&&oe.classList.remove("thinking-active");const ae=h()?.querySelector(`#cot-wrapper-${S}`);ae&&ae.removeAttribute("data-slow"),a&&_&&delete t.openThinkingIds[S];const ne=Vt(Q);H!==-1&&ne.length>1?(o.messages.splice(H,1),u(),await Dt(180),await Bt(o,ne,{startIndex:H,thinking:a?_:"",toolCalls:T})):(H!==-1&&(o.messages[H]={...o.messages[H],text:Q,...a&&_?{thinking:_}:{},...T?{toolCalls:T}:{},streaming:!1}),u())}catch(l){clearInterval(_rerollSlowTimer),_cancelRerollFlush(),t.streamingAbortController=null;const p=l.name==="AbortError";p||console.error("[reroll SSE] error:",l);const g=o.messages.findIndex(b=>b.id===rerollId);g!==-1&&(o.messages[g]={...o.messages[g],text:p?fullText||"…":`重试失败：${l.message}`,...fullThinking?{thinking:fullThinking}:{},...fullToolCalls?{toolCalls:fullToolCalls}:{},streaming:!1}),u()}}function G(){requestAnimationFrame(()=>{const e=h()?.querySelector(".messages-panel");e&&(e.scrollTop=e.scrollHeight)})}function Da(){return`
      <div class="attach-panel glass-frost">
        <button class="attach-option" data-action="attach-option" data-label="图片">
          <span class="attach-icon">🖼️</span><span>图片</span>
        </button>
        <button class="attach-option" data-action="attach-option" data-label="文件">
          <span class="attach-icon">📄</span><span>文件</span>
        </button>
        <button class="attach-option" data-action="attach-option" data-label="语音">
          <span class="attach-icon">🎤</span><span>语音</span>
        </button>
        <button class="attach-option" data-action="attach-option" data-label="拍照">
          <span class="attach-icon">📸</span><span>拍照</span>
        </button>
      </div>
    `}const no=window.openPage;typeof no=="function"&&(window.openPage=function(o,a){no(o,a),o==="page-chat"&&Ut()});const Va=[{id:"openai",name:"OpenAI",enabled:!0,baseUrl:"https://api.openai.com/v1",apiPath:"",apiKey:"",models:["gpt-5.4","gpt-5.4-mini","gpt-4.1-mini"],defaultModel:"gpt-5.4"},{id:"openrouter",name:"OpenRouter",enabled:!0,baseUrl:"https://openrouter.ai/api/v1",apiPath:"",apiKey:"",models:["openai/gpt-5","anthropic/claude-3.7-sonnet"],defaultModel:"openai/gpt-5"},{id:"gemini",name:"Gemini",enabled:!0,baseUrl:"https://generativelanguage.googleapis.com/v1beta/openai",apiPath:"",apiKey:"",models:["gemini-2.5-pro","gemini-2.5-flash"],defaultModel:"gemini-2.5-pro"},{id:"deepseek",name:"DeepSeek",enabled:!1,baseUrl:"https://api.deepseek.com/v1",apiPath:"",apiKey:"",models:["deepseek-chat","deepseek-reasoner"],defaultModel:"deepseek-chat"},{id:"qwen",name:"阿里云千问",enabled:!1,baseUrl:"https://dashscope.aliyuncs.com/compatible-mode/v1",apiPath:"",apiKey:"",models:["qwen-max","qwen-plus","qwen-turbo"],defaultModel:"qwen-max"},{id:"zhipu",name:"智谱",enabled:!1,baseUrl:"https://open.bigmodel.cn/api/paas/v4",apiPath:"",apiKey:"",models:["glm-4.5","glm-4-air"],defaultModel:"glm-4.5"}],xt=new Set(["aiInterface","defaultModels","modelSlot","providerCatalog","providerEditor","promptEditor","themeSettings","accountSettings","memoryService","backendSync","exportSettings","mcpLibrary"]),Ba=Re,Na=st,Ha=rt,io=mt;t.viewStack=t.viewStack||[],t.activeModelSlot=t.activeModelSlot||"chat",t.activeModelSlotContext=t.activeModelSlotContext||"global",t.activeModelProviderId=t.activeModelProviderId||"",t.providerDraftId=t.providerDraftId||null,t.providerAdvancedOpen=!!t.providerAdvancedOpen,t.providerEditorDraft=t.providerEditorDraft||null,t.providerModelMenuOpen=!!t.providerModelMenuOpen,t.modelSlotMenuOpen=!!t.modelSlotMenuOpen,t.providerSearch=t.providerSearch||"",t.activePromptSlot=t.activePromptSlot||"summary";function O(e){const o=String(e||"").trim();return o?o==="ocr"?"vision":o==="title"?"summary":o:"chat"}t.aiSettingsSaving=!1,t.memoryServiceEntries=Array.isArray(t.memoryServiceEntries)?t.memoryServiceEntries:[],t.memoryServiceLoading=!!t.memoryServiceLoading,t.slotVendorGroupOpen=t.slotVendorGroupOpen&&typeof t.slotVendorGroupOpen=="object"?t.slotVendorGroupOpen:{},t.providerModelVendorOpen=t.providerModelVendorOpen&&typeof t.providerModelVendorOpen=="object"?t.providerModelVendorOpen:{};function ja(){return"/chat/completions"}function xe(e,{allowEmpty:o=!1}={}){const a=String(e||"").trim();return a?a.startsWith("/")?a:`/${a}`:o?"":ja()}function za(e={}){return xe(e.apiPath||e.api_path||"",{allowEmpty:!1})}function Ct(e={}){const o=xe(e.apiPath||e.api_path||"",{allowEmpty:!0});return{...e,baseUrl:e.baseUrl||e.base_url||"",apiKey:e.apiKey||e.api_key||"",apiPath:o,api_path:o,models:Array.isArray(e.models)?e.models:[]}}function Ce(){return{providers:Va.map(e=>Ct({...e,models:[...e.models]})),defaultModels:{chat:{providerId:"openai",model:"gpt-5.4",useChatModel:!1},summary:{providerId:"openai",model:"gpt-5.4-mini",useChatModel:!1},vision:{providerId:"openai",model:"gpt-5.4-mini",useChatModel:!1},translate:{providerId:"openai",model:"gpt-5.4-mini",useChatModel:!1},consciousness:{providerId:"openai",model:"gpt-5.4-mini",useChatModel:!1},voice:{provider:"",service_url:"",base_url:"",voice_id:"",speaker:"",emotion:"",speed:1,format:""}},defaultPrompts:{chat:"Respond naturally, stay consistent with the current role and context, and keep the tone warm and clear.",summary:"Write a concise conversation summary with key facts, action items, and follow-ups.",translate:"Translate the content accurately while preserving tone and formatting when possible.",vision:"Extract visible text from the image and explain key visual information clearly.",consciousness:"Review recent context, infer useful next-step thoughts, and keep the result concise and actionable."},mcpLibrary:So()}}function C(){if(!t.globalSettings.aiSettings)t.globalSettings.aiSettings=Ce();else{const e=t.globalSettings.aiSettings;e.defaultModels=e.defaultModels||{},e.defaultPrompts=e.defaultPrompts||{},e.defaultModels.ocr&&!e.defaultModels.vision&&(e.defaultModels.vision={...e.defaultModels.ocr}),e.defaultPrompts.ocr&&!e.defaultPrompts.vision&&(e.defaultPrompts.vision=e.defaultPrompts.ocr),delete e.defaultModels.ocr,delete e.defaultPrompts.ocr,delete e.defaultModels.title,delete e.defaultPrompts.title,Object.entries(Ce().defaultModels).forEach(([o,a])=>{e.defaultModels[o]||(e.defaultModels[o]={...a})}),Object.entries(Ce().defaultPrompts).forEach(([o,a])=>{typeof e.defaultPrompts[o]!="string"&&(e.defaultPrompts[o]=a)})}return t.globalSettings.aiSettings}function Fa(e={}){const o=Ce(),a={...e||{}};a.defaultModels?.ocr&&!a.defaultModels?.vision&&(a.defaultModels={...a.defaultModels,vision:a.defaultModels.ocr}),a.defaultPrompts?.ocr&&!a.defaultPrompts?.vision&&(a.defaultPrompts={...a.defaultPrompts,vision:a.defaultPrompts.ocr});const n={providers:o.providers,defaultModels:{...o.defaultModels},defaultPrompts:{...o.defaultPrompts},mcpLibrary:{...o.mcpLibrary,tools:[...o.mcpLibrary?.tools||[]]}};if(Array.isArray(a.providers)&&a.providers.length){const i=new Map(o.providers.map(s=>[s.id,s]));a.providers.forEach(s=>{const r=Ct(s);i.set(r.id,{...i.get(r.id),...r,models:Array.isArray(r.models)&&r.models.length?r.models:i.get(r.id)?.models||[]})}),n.providers=[...i.values()]}a.defaultModels&&Object.keys(n.defaultModels).forEach(i=>{a.defaultModels[i]&&(n.defaultModels[i]={...n.defaultModels[i],...a.defaultModels[i]})}),a.defaultPrompts&&Object.keys(n.defaultPrompts).forEach(i=>{typeof a.defaultPrompts[i]=="string"&&(n.defaultPrompts[i]=a.defaultPrompts[i])}),a.mcpLibrary&&Array.isArray(a.mcpLibrary.tools)&&(n.mcpLibrary={...n.mcpLibrary,...a.mcpLibrary,tools:a.mcpLibrary.tools.map(ee)}),t.globalSettings.aiSettings=n,typeof a.consciousnessLoop=="boolean"&&(t.globalSettings.consciousnessLoop=a.consciousnessLoop),je()}function je(){const e=C(),o=e.defaultModels.chat,a=e.providers.find(n=>n.id===o.providerId);t.globalSettings.defaultModel=o.model,t.globalSettings.provider=a?.name||"OpenAI"}function z(e){return C().providers.find(o=>o.id===e)}function Tt(e=t.providerDraftId){const o=Ct(z(e)||{id:e||`custom_${Date.now()}`,name:"",enabled:!0,baseUrl:"",apiPath:"",apiKey:"",models:[],defaultModel:""}),a=Array.isArray(o.models)?[...o.models]:[],n=a.map(At);return{...o,models:a,_allModels:n,_selectedModelIds:new Set(a)}}function E(){return(!t.providerEditorDraft||t.providerEditorDraft.id!==t.providerDraftId)&&(t.providerEditorDraft=Tt()),t.providerEditorDraft}function ze(e="",o=[]){const a=String(e||"").trim().toLowerCase();return a?o.filter(n=>String(n||"").toLowerCase().includes(a)):[...o]}function so(e){const o=String(e||"").toLowerCase();return/deepseek/.test(o)?"DeepSeek":/\bglm\b|chatglm/.test(o)?"GLM":/\bqwen\b|qwq/.test(o)?"Qwen":/\bgpt[-\d]|^gpt|^o[134][-\d]|text-davinci|text-curie/.test(o)?"OpenAI":/claude/.test(o)?"Anthropic":/gemini|gemma/.test(o)?"Google":/\bllama\b|meta-llama/.test(o)?"Meta":/mistral|mixtral|codestral/.test(o)?"Mistral":/\byi[-/_]/.test(o)?"闆朵竴涓囩墿":/moonshot|kimi/.test(o)?"Moonshot":/hunyuan/.test(o)?"娣峰厓":/ernie|wenxin/.test(o)?"鏂囧績":/doubao/.test(o)?"璞嗗寘":/baichuan/.test(o)?"鐧惧窛":/spark/.test(o)?"鏄熺伀":/internlm/.test(o)?"InternLM":"Other"}function ro(e){const o=String(e||"").toLowerCase(),a=["chat","text"];return/vl\b|vision|visual|\bvision\b|-v\d|\bimg\b/.test(o)&&a.push("vision"),/reason|r1\b|think\b|cot\b/.test(o)&&a.push("reasoning"),/image|draw|flux|paint|artist|diffusion/.test(o)&&a.push("image"),a.push("tools"),a}function At(e){const o=String(e||"").trim();return{id:o,name:o,vendor:so(o),capabilities:ro(o)}}const Ua={chat:"瀵硅瘽",text:"鏂囨湰",reasoning:"鎺ㄧ悊",tools:"宸ュ叿璋冪敤",vision:"瑙嗚",image:"鐢熷浘"},Qa=["reasoning","tools","vision","image"],Ya={reasoning:'<svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true"><path d="M5 .5A3 3 0 0 0 2.8 5.9l.2.3V8h4V6.2l.2-.3A3 3 0 0 0 5 .5zm-1.2 8h2.4v.5c0 .28-.22.5-.5.5H4.3a.5.5 0 0 1-.5-.5V8.5z"/></svg>',tools:'<svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true"><path d="M7.5 1a2 2 0 0 0-1.86 2.73L1.2 8.16a.6.6 0 0 0 .84.84l4.43-4.44A2 2 0 1 0 7.5 1zm0 3a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/></svg>',vision:'<svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M5 2C2.5 2 .8 5 .8 5S2.5 8 5 8s4.2-3 4.2-3S7.5 2 5 2zm0 4.5A1.5 1.5 0 1 1 5 3.5a1.5 1.5 0 0 1 0 3z"/></svg>',image:'<svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M1.5 1A.5.5 0 0 0 1 1.5v7a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 .5-.5v-7A.5.5 0 0 0 8.5 1h-7zM2 8l2-2.5 1.3 1.7 1.7-2.2L9 8H2zm.8-4.3a.7.7 0 1 0 1.4 0 .7.7 0 0 0-1.4 0z"/></svg>'};function Ka(e){return(Array.isArray(e?.capabilities)?e.capabilities:ro(e?.name||"")).filter(a=>Qa.includes(a)).map(a=>`<span class="model-cap-badge cap-${a}" title="${Ua[a]||a}">${Ya[a]||a}</span>`).join("")}function uo(e="",o=[]){const a=String(e||"").trim();return!Array.isArray(o)||!o.length?"还没有已同步模型，仍可手动输入并保存。":a?o.some(i=>String(i).toLowerCase()===a.toLowerCase())?"已匹配到已同步列表中的模型。":"当前模型不在已同步列表中，可继续手动保存。":`已同步 ${o.length} 个模型，可搜索或展开列表选择。`}function qt(e="",o=[]){const a=String(e||"").trim();return!Array.isArray(o)||!o.length?"当前供应商还没有同步模型，可切换供应商或先同步。":a?o.some(i=>String(i).toLowerCase()===a.toLowerCase())?"已匹配到当前供应商模型。":"当前输入不在同步列表中。":`已同步 ${o.length} 个模型，可搜索或展开列表选择。`}function pe(){const e=E(),o=document.getElementById("provider-default-model-input"),a=document.getElementById("provider-default-model-menu"),n=document.getElementById("provider-default-model-hint");if(!a||!n)return;const i=o?.value||e.defaultModel||"",s=Array.isArray(e.models)?e.models:[],r=ze(i,s);if(n.textContent=uo(i,s),!t.providerModelMenuOpen){a.innerHTML="",a.classList.remove("open");return}a.classList.add("open"),a.innerHTML=r.length?r.map(d=>`
          <button class="provider-model-option ${String(d).toLowerCase()===String(i).trim().toLowerCase()?"active":""}" data-action="pick-provider-default-model" data-model="${c(d)}" type="button">
            ${c(d)}
          </button>
        `).join(""):'<div class="provider-model-empty">娌℃湁鍖归厤鍒板凡鍚屾妯″瀷锛屽彲缁х画鎵嬪姩杈撳叆淇濆瓨銆?/div>'}function k(e){return C().defaultModels[O(e)]}function Xa(){const e=t.activeModelSlot,o=t.activeModelSlotContext==="contact",a=v(t.currentContactId)||t.contacts[0],n=o?{providerId:a?.settings?.modelProviderId||t.activeModelProviderId||k("chat")?.providerId||"openai",model:e==="consciousness"?a?.settings?.loopModel||"":a?.settings?.model||""}:Ue(e),i=z(n?.providerId)||z(k("chat")?.providerId);return{slot:n,provider:i,models:i?.models||[]}}function Fe(){const e=document.getElementById("model-slot-menu"),o=document.getElementById("model-slot-hint"),a=document.getElementById("model-slot-input");if(!e||!o)return;const{slot:n,models:i}=Xa(),s=a?.value||n?.model||"",r=ze(s,i);if(o.textContent=qt(s,i),!t.modelSlotMenuOpen){e.innerHTML="",e.classList.remove("open");return}e.classList.add("open"),e.innerHTML=r.length?r.map(d=>`
          <button class="provider-model-option ${String(n?.model||"").trim().toLowerCase()===String(d).toLowerCase()?"active":""}" data-action="pick-slot-model" data-slot="${t.activeModelSlot}" data-model="${c(d)}" type="button">
            ${c(d)}
          </button>
        `).join(""):'<div class="provider-model-empty">娌℃湁鍖归厤鍒板綋鍓嶄緵搴斿晢妯″瀷銆?/div>'}function Ue(e){return k(O(e))}function $e(e){const o=O(e);return{chat:"聊天模型",summary:"摘要模型",vision:"Vision 模型",translate:"翻译模型",consciousness:"意识循环模型",voice:"语音模型"}[o]||o}function Qe(e){const o=O(e);return{chat:"全局默认使用的聊天模型。",summary:"用于生成对话摘要，推荐选择便宜且稳定的模型。",vision:"用于识图、OCR 与截图分析的统一入口。",translate:"用于翻译消息内容，推荐选择速度快的模型。",consciousness:"用于意识循环、主动思考与相关后台能力。",voice:"用于文本转语音，读取语音服务地址与 voice ID。"}[o]||""}function co(e){const o=O(e),a=Ue(o);if(o==="voice"){if(!a)return"未设置";const i=a.provider||"语音服务",s=a.voice_id||a.voiceId||"未设置";return`${i} / ${s}`}const n=z(a?.providerId);return a?`${n?.name||"未设置"} / ${a.model||"未设置"}`:"未设置"}function Ga(e){return C().defaultPrompts?.[O(e)]||""}function Ja(e){const o=O(e);return{chat:m("comment"),summary:m("file"),vision:m("search"),translate:m("chatArrow"),consciousness:m("history"),voice:m("mic")}[o]||m("file")}function Wa(e){const o=O(e);return o!=="chat"&&o!=="voice"}function Za(e){return`
      <article class="default-model-card">
        <div class="default-model-head">
          <div class="default-model-icon">${Ja(e)}</div>
          <div class="default-model-copy">
            <strong>${c($e(e))}</strong>
            <p>${c(Qe(e))}</p>
          </div>
          ${Wa(e)?`<button class="model-gear-btn" data-action="open-prompt-editor" data-slot="${e}" aria-label="提示词设置">${m("settings")}</button>`:'<span class="header-spacer"></span>'}
        </div>
        <button class="model-value-pill" data-action="open-model-slot" data-slot="${e}">
          <span class="model-value-badge">使</span>
          <span>${c(co(e))}</span>
        </button>
      </article>
    `}function en(){const e=O(t.activePromptSlot),o=Ga(e);return`
      <section class="settings-page page-block ai-settings-page ai-prompt-page">
        <div class="settings-group glass-frost ai-panel ai-form-group">
          <h3>${c($e(e))} 提示词</h3>
          <p class="section-eyebrow">用于定义这个能力位的默认提示词模板，后续接入对应后端任务时会直接使用这里的内容。</p>
          <textarea id="slot-prompt-input" class="ai-textarea ai-prompt-textarea" placeholder="在这里输入默认提示词">${c(o)}</textarea>
          <p class="section-eyebrow">变量位后续可以继续扩展，目前先支持按能力位单独保存。</p>
        </div>
        <div class="settings-group glass-frost ai-panel ai-prompt-actions">
          <button class="ghost-action prompt-reset-btn" data-action="reset-slot-prompt" data-slot="${e}">重置为默认</button>
          <button class="bottom-tab active prompt-save-btn" data-action="save-slot-prompt" data-slot="${e}">保存</button>
        </div>
      </section>
    `}function tn(){const e=[{id:"奶油粉",key:"rose",desc:"柔和粉白"},{id:"云雾灰",key:"mist",desc:"冷淡浅灰"},{id:"奶油杏",key:"cream",desc:"暖调米白"}],o=t.globalSettings.theme;return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>主题模式</h3>
          <p class="section-eyebrow">选择首页和聊天页共用的浅色主题。</p>
          <div class="theme-choice-list">
            ${e.map(a=>`
              <button class="theme-choice-item ${o===a.id||o===a.key?"active":""}" data-action="pick-theme-mode" data-theme="${a.id}">
                <span class="theme-choice-copy">
                  <strong>${c(a.id)}</strong>
                  <em>${c(a.desc)}</em>
                </span>
                <span class="theme-choice-check">${o===a.id||o===a.key?"已选":""}</span>
              </button>
            `).join("")}
          </div>
        </div>
      </section>
    `}function on(){const e=t.accountProfile||{};return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>我的账号</h3>
          ${w("头像","更换头像","open-account-avatar")}
          ${w("昵称",e.nickname||"小酒","open-account-nickname")}
          ${w("个性签名",e.signature||"管理个人资料与基础偏好","open-account-signature")}
          <input id="account-avatar-file" class="moment-image-input" type="file" accept="image/*" />
        </div>
      </section>
    `}function an(){const e=v(t.currentContactId)||t.contacts[0],o=Array.isArray(t.memoryServiceEntries)?t.memoryServiceEntries:[];return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>记忆服务</h3>
          <p class="section-eyebrow">当前联系人：${c(e?.name||"未命名")} 。这里直接读写后端 memories，不再以本地假数据为准。</p>
          <div class="ai-inline-actions" style="margin-top:10px;">
            <button class="ghost-action" data-action="memory-service-refresh">刷新</button>
            <button class="ghost-action" data-action="memory-service-create">新建记忆</button>
          </div>
        </div>
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>记忆列表</h3>
          ${t.memoryServiceLoading?'<p class="section-eyebrow">正在加载…</p>':""}
          ${!t.memoryServiceLoading&&!o.length?'<p class="section-eyebrow">这个角色还没有记忆。</p>':""}
          ${o.map(a=>`
            <div class="theme-choice-item active" style="cursor:default; display:block;">
              <div class="theme-choice-copy" style="display:block;">
                <strong>${c(a.compressed_content||a.raw_content||a.content||"未命名记忆")}</strong>
                <em>${c(`${a.category||""} / ${a.visibility||"private"} / importance ${a.importance??3}`)}</em>
                ${a.expires_at?`<em>过期：${c(String(a.expires_at))}</em>`:""}
              </div>
              <div class="ai-inline-actions" style="margin-top:10px;">
                <button class="ghost-action" data-action="memory-service-edit" data-memory-id="${c(String(a.id||""))}">编辑</button>
                <button class="ghost-action" data-action="memory-service-delete" data-memory-id="${c(String(a.id||""))}">删除</button>
              </div>
            </div>
          `).join("")}
        </div>
      </section>
    `}function lo(){return String(t.currentContactId||v(t.currentContactId)?.id||"default").trim()||"default"}async function Te(e=lo(),{silent:o=!0}={}){const a=String(e||"").trim();if(a){t.memoryServiceLoading=!0,u();try{const n=new URLSearchParams({agent_id:a,sort_by:"updated_at",order:"desc",limit:"100"}),i=await fetch(`${y}/api/memories?${n.toString()}`);if(!i.ok)throw new Error(`HTTP ${i.status}`);const s=await i.json().catch(()=>({}));t.memoryServiceEntries=Array.isArray(s?.memories)?s.memories:[]}catch(n){console.warn("[memory service] load failed",n),o||(t.toast="记忆加载失败",window.setTimeout(()=>{t.toast="",u()},1200))}finally{t.memoryServiceLoading=!1,u()}}}function po(e=null){const o=e||{},a=window.prompt("记忆内容",String(o.raw_content||o.content||"").trim());if(a===null)return null;const n=window.prompt("分层 / category（core_profile / recent_pending / deep / ephemeral）",String(o.category||"recent_pending"));if(n===null)return null;const i=window.prompt("可见范围（private / shared / public）",String(o.visibility||"private"));if(i===null)return null;const s=window.prompt("重要度（1-5）",String(o.importance??3));if(s===null)return null;const r=window.prompt("过期时间 ISO（可留空）",String(o.expires_at||""));return r===null?null:{agent_id:lo(),content:String(a||"").trim(),raw_content:String(a||"").trim(),category:String(n||"").trim()||"recent_pending",visibility:String(i||"").trim()||"private",importance:Math.max(1,Math.min(5,Number(s)||3)),expires_at:String(r||"").trim()||null}}async function nn(){const e=po();if(!e||!e.content)return;const o=await fetch(`${y}/api/memories`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)}),a=await o.json().catch(()=>({}));if(!o.ok)throw new Error(a?.detail||`HTTP ${o.status}`)}async function sn(e){const o=t.memoryServiceEntries.find(s=>String(s.id)===String(e));if(!o)return;const a=po(o);if(!a||!a.content)return;const n=await fetch(`${y}/api/memories/${encodeURIComponent(e)}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(a)}),i=await n.json().catch(()=>({}));if(!n.ok)throw new Error(i?.detail||`HTTP ${n.status}`)}async function rn(e){if(!window.confirm("删除这条记忆？"))return;const o=await fetch(`${y}/api/memories/${encodeURIComponent(e)}`,{method:"DELETE"}),a=await o.json().catch(()=>({}));if(!o.ok)throw new Error(a?.detail||`HTTP ${o.status}`)}function un(){const e=He();return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>同步后端</h3>
          <p class="section-eyebrow">前端快照会本地保存，并自动 push/pull 到后端。</p>
          ${w("数据库","Supabase")}
          ${w("后端接口",y)}
          ${w("设备 ID",vt())}
          ${w("上次同步",de(e.last_server_updated_at,{fallback:"暂无",includeYear:!0}))}
          <div class="ai-inline-actions" style="margin-top:10px;">
            <button class="ghost-action" data-action="sync-pull-now">立即拉取</button>
            <button class="ghost-action" data-action="sync-push-now">立即上传</button>
          </div>
        </div>
      </section>
    `}function cn(){const e=t.globalSettings;return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>导出格式</h3>
          <div class="theme-choice-list">
            ${["Markdown","JSON","TXT"].map(a=>`
              <button class="theme-choice-item ${e.exportFormat===a?"active":""}" data-action="pick-export-format" data-format="${a}">
                <span class="theme-choice-copy">
                  <strong>${c(a)}</strong>
                  <em>用于聊天记录导出</em>
                </span>
                <span class="theme-choice-check">${e.exportFormat===a?"已选":""}</span>
              </button>
            `).join("")}
          </div>
        </div>
      </section>
    `}function w(e,o,a="noop",n={}){const i=Object.entries(n).map(([s,r])=>` data-${s}="${c(String(r))}"`).join("");return`
      <button class="setting-row nav-row" data-action="${a}"${i}>
        <div class="setting-copy"><strong>${c(e)}</strong>${o?`<p>${c(o)}</p>`:""}</div>
        <span class="row-chevron">${m("chevron")}</span>
      </button>
    `}function B(e,o){t.viewStack.push(t.currentView),typeof o=="function"&&o(),t.currentView=e,u()}function ln(){t.currentView=t.viewStack.pop()||"settings",u()}async function dn(){try{const e=await fetch(`${y}/api/settings/ai`);if(!e.ok)return;const o=await e.json();Fa(o.settings?.aiSettings||o.settings?.ai||o.settings?.ai_settings||o.settings||{}),u()}catch(e){console.warn("[ai settings] load failed",e)}}async function mo({silent:e=!0}={}){try{(!Array.isArray(t.moments)||t.moments.length===0)&&(t.moments=structuredClone(Ge));const o=new URLSearchParams({viewer_type:"user",viewer_id:"me"}),a=await fetch(`${y}/api/moments?${o.toString()}`);if(!a.ok){if(!e)throw new Error(`HTTP ${a.status}`);return}const n=await a.json().catch(()=>({}));if(!Array.isArray(n?.moments))return;n.moments.length>0&&(t.moments=n.moments.map(L)),u()}catch(o){console.warn("[moments] load failed",o),e||(t.toast="朋友圈加载失败",u(),window.setTimeout(()=>{t.toast="",u()},1400))}}async function pn(e){const o=await fetch(`${y}/api/moments`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)}),a=await o.json().catch(()=>({}));if(!o.ok)throw new Error(a?.detail||`HTTP ${o.status}`);return L(a?.moment||e)}async function mn(e,o){const a=await fetch(`${y}/api/moments/${encodeURIComponent(e)}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)}),n=await a.json().catch(()=>({}));if(!a.ok)throw new Error(n?.detail||`HTTP ${a.status}`);return n}async function fn(e,o,a){const n=new URLSearchParams({author_type:String(o||"user"),author_id:String(a||"me")}),i=await fetch(`${y}/api/moments/${encodeURIComponent(e)}?${n.toString()}`,{method:"DELETE"}),s=await i.json().catch(()=>({}));if(!i.ok)throw new Error(s?.detail||`HTTP ${i.status}`);return s}async function gn(e,o){const a=await fetch(`${y}/api/moments/${encodeURIComponent(e)}/like`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({actor_type:o.author_type,actor_id:o.author_id,actor_name:o.author_name})}),n=await a.json().catch(()=>({}));if(!a.ok)throw new Error(n?.detail||`HTTP ${a.status}`);return L(n?.moment||{})}async function bn(e,o,a){const n=await fetch(`${y}/api/moments/${encodeURIComponent(e)}/comments`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({actor_type:o.author_type,actor_id:o.author_id,actor_name:o.author_name,text:a})}),i=await n.json().catch(()=>({}));if(!n.ok)throw new Error(i?.detail||`HTTP ${n.status}`);return L(i?.moment||{})}async function hn(e,o){const a=t.currentContactId||"",n=(o||"").trim()||null,i={agentId:a};if(e==="impression")i.impression=n;else if(e==="relationshipProgress")i.relationshipProgress=n;else if(e==="likesSummary")i.likesSummary=n;else return;try{t.toast="保存中…",u();const s=await fetch(`${y}/api/companion-state/summary`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)});if(!s.ok)throw new Error(`HTTP ${s.status}`);const r=await s.json().catch(()=>({}));t.companionState=he(r?.state||t.companionState),t.toast="已保存",u(),window.setTimeout(()=>{t.toast="",u()},1200)}catch(s){console.warn("[insight save]",s),t.toast="保存失败",u(),window.setTimeout(()=>{t.toast="",u()},1400)}}async function J(e=t.currentContactId,{silent:o=!0}={}){try{const a=String(e||"").trim(),n=a?`?agent_id=${encodeURIComponent(a)}`:"",i=await fetch(`${y}/api/companion-state${n}`);if(!i.ok){if(!o)throw new Error(`HTTP ${i.status}`);return}const s=await i.json().catch(()=>({}));t.companionState=he(s?.state||{}),u()}catch(a){console.warn("[companion state] load failed",a),o||(t.toast="状态读取失败",u(),window.setTimeout(()=>{t.toast="",u()},1200))}}async function Ae(e,{silent:o=!0}={}){const a=String(e||"").trim();if(!a)return"";try{const n=await fetch(`${y}/api/agents/${encodeURIComponent(a)}/persona`);if(!n.ok){if(!o)throw new Error(`HTTP ${n.status}`);return""}const i=await n.json().catch(()=>({})),s=v(a);return s&&(s.persona=String(i?.persona||""),t.currentView==="contactSettings"&&t.currentContactId===a&&u()),String(i?.persona||"")}catch(n){return console.warn("[agent persona] load failed",n),o||(t.toast="浜鸿璇诲彇澶辫触",u(),window.setTimeout(()=>{t.toast="",u()},1200)),""}}async function vn(e,o){const a=String(e||"").trim();if(a)try{await fetch(`${y}/api/agents/${encodeURIComponent(a)}/persona`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({persona:String(o||"")})})}catch(n){console.warn("[agent persona] save failed",n)}}function yn(e,o,a=260){const n=String(e||"").trim();if(!n)return;ue.has(n)&&clearTimeout(ue.get(n));const i=window.setTimeout(()=>{ue.delete(n),vn(n,o)},a);ue.set(n,i)}async function fo({silent:e=!0}={}){try{const o=await fetch(`${y}/api/mcp/library`);if(!o.ok){if(!e)throw new Error(`HTTP ${o.status}`);return}const a=await o.json();if(!Array.isArray(a.tools))return;const n=C(),i=a.tools.map(ee).filter(s=>ce(s.id));n.mcpLibrary={...n.mcpLibrary||{},tools:i},x(),u()}catch(o){console.warn("[mcp library] load failed",o),e||(t.toast="同步 MCP 工具失败",u(),window.setTimeout(()=>{t.toast="",u()},1300))}}async function x(){je(),t.aiSettingsSaving=!0;try{await fetch(`${y}/api/settings/ai`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({settings:{...t.globalSettings,aiSettings:C()}})})}catch(e){console.error("[ai settings] save failed",e)}finally{t.aiSettingsSaving=!1}}function wn(){const e=C(),o=(e.mcpLibrary?.tools||[]).filter(a=>a.enabled!==!1).length;return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel">
          <h3>AI 接口</h3>
          ${w("默认模型","聊天 / 摘要 / Vision / 翻译 / 意识循环 / 语音","open-default-models")}
          ${w("模型供应商",`共 ${e.providers.length} 个`,"open-provider-catalog")}
          ${w("MCP 工具库",`已启用 ${o} 个`,"open-mcp-library")}
        </div>
        <div class="settings-group glass-frost ai-panel">
          <h3>当前聊天默认</h3>
          ${w("聊天模型",co("chat"))}
        </div>
      </section>
    `}function $n(){const e=C();return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <div class="ai-inline-actions">
            <h3 style="margin:0;">MCP 工具库</h3>
            <button class="ghost-action" data-action="sync-mcp-library">同步工具</button>
          </div>
          <p class="section-eyebrow">只展示聊天主动场景常用工具，同步到输入框上方分类。</p>
          ${(Array.isArray(e.mcpLibrary?.tools)?e.mcpLibrary.tools:[]).map(ee).filter(a=>ce(a.id)).map(a=>`
            <div class="provider-catalog-row">
              <div class="provider-row-main" style="cursor:default;">
                <div class="setting-copy">
                  <strong>${c(a.label||a.id||"")}</strong>
                  <p>${c(a.description||a.prompt||a.id||"")}</p>
                </div>
              </div>
              <button class="switch-btn ${a.enabled!==!1?"on":"off"}" data-action="toggle-mcp-tool" data-tool-id="${c(a.id||"")}" aria-pressed="${a.enabled!==!1}">
                ${Ve(a.enabled!==!1)}
              </button>
            </div>
          `).join("")}
        </div>
      </section>
    `}function kn(){return`
      <section class="settings-page page-block ai-settings-page">
        <div class="default-model-list">
          ${["chat","summary","vision","translate","consciousness","voice"].map(o=>Za(o)).join("")}
        </div>
      </section>
    `}function Sn(){const e=O(t.activeModelSlot),o=t.activeModelSlotContext==="contact",a=v(t.currentContactId)||t.contacts[0];if(!o&&e==="voice"){const l=Ue("voice")||{};return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>${c($e("voice"))}</h3>
          <p class="section-eyebrow">${c(Qe("voice"))}</p>
        </div>
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>语音服务配置</h3>
          <label class="ai-field-label">Provider</label>
          <input id="voice-slot-provider-input" class="ai-input" value="${c(l.provider||"")}" placeholder="voice-mcp" />
          <label class="ai-field-label">Service URL</label>
          <input id="voice-slot-service-url-input" class="ai-input" value="${c(l.service_url||l.base_url||"")}" placeholder="https://voice.example.com/speak" />
          <label class="ai-field-label">Voice ID</label>
          <input id="voice-slot-voice-id-input" class="ai-input" value="${c(l.voice_id||l.voiceId||"")}" placeholder="default voice_id" />
          <label class="ai-field-label">Speaker</label>
          <input id="voice-slot-speaker-input" class="ai-input" value="${c(l.speaker||"")}" placeholder="可选 speaker" />
          <label class="ai-field-label">Emotion</label>
          <input id="voice-slot-emotion-input" class="ai-input" value="${c(l.emotion||"")}" placeholder="可选 emotion" />
          <label class="ai-field-label">Speed</label>
          <input id="voice-slot-speed-input" class="ai-input" value="${c(l.speed??1)}" placeholder="1.0" />
          <label class="ai-field-label">Format</label>
          <input id="voice-slot-format-input" class="ai-input" value="${c(l.format||"")}" placeholder="audio/mpeg" />
        </div>
      </section>
    `}const n=o?{providerId:a?.settings?.modelProviderId||t.activeModelProviderId||k("chat")?.providerId||"openai",model:e==="consciousness"?a?.settings?.loopModel||"":a?.settings?.model||""}:Ue(e),i=C().providers.filter(l=>l.enabled),r=(z(n.providerId)||z(k("chat")?.providerId)||i[0])?.models||[];if(o){const l=ze(n.model||"",r);return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>${c($e(e))}</h3>
          <p class="section-eyebrow">${c(Qe(e))}</p>
        </div>
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>模型供应商</h3>
          <div class="ai-chip-row">
            ${i.map(p=>`<button class="ai-chip ${n.providerId===p.id?"active":""}" data-action="pick-slot-provider" data-slot="${e}" data-provider-id="${p.id}">${c(p.name)}</button>`).join("")}
          </div>
        </div>
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>模型列表</h3>
          <div class="provider-model-picker">
            <div class="provider-model-input-row">
              <input id="model-slot-input" class="ai-input provider-model-input" value="${c(n.model||"")}" placeholder="${c(r[0]||"杈撳叆鎴栭€夋嫨妯″瀷")}" autocomplete="off" />
              <button class="provider-model-toggle" data-action="toggle-model-slot-menu" type="button" aria-label="灞曞紑妯″瀷鍒楄〃">
                ${m("chevron")}
              </button>
            </div>
            <p id="model-slot-hint" class="section-eyebrow provider-model-hint">${c(qt(n.model||"",r))}</p>
            <div id="model-slot-menu" class="provider-model-menu ${t.modelSlotMenuOpen?"open":""}">
              ${t.modelSlotMenuOpen?l.length?l.map(p=>`
                  <button class="provider-model-option ${n.model===p?"active":""}" data-action="pick-slot-model" data-slot="${e}" data-model="${c(p)}" type="button">
                    ${c(p)}
                  </button>
                `).join(""):'<div class="provider-model-empty">没有匹配到当前供应商模型。</div>':""}
            </div>
          </div>
          <div class="model-choice-list">
            ${r.length?r.map(p=>`
              <button class="model-choice-item ${n.model===p?"active":""}" data-action="pick-slot-model" data-slot="${e}" data-model="${c(p)}">
                <span class="model-choice-name">${c(p)}</span>
                <span class="model-choice-check">${n.model===p?"已选":""}</span>
              </button>
            `).join(""):'<div class="model-choice-empty">当前供应商还没有可选模型</div>'}
          </div>
        </div>
      </section>
    `}const d=ze(n.model||"",r);return`
      <section class="settings-page page-block ai-settings-page">
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>${c($e(e))}</h3>
          <p class="section-eyebrow">${c(Qe(e))}</p>
        </div>
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>模型供应商</h3>
          <div class="ai-chip-row">
            ${i.map(l=>`<button class="ai-chip ${n.providerId===l.id?"active":""}" data-action="pick-slot-provider" data-slot="${e}" data-provider-id="${l.id}">${c(l.name)}</button>`).join("")}
          </div>
        </div>
        <div class="settings-group glass-frost ai-panel compact-panel">
          <h3>模型列表</h3>
          <div class="provider-model-picker">
            <div class="provider-model-input-row">
              <input id="model-slot-input" class="ai-input provider-model-input" value="${c(n.model||"")}" placeholder="${c(r[0]||"杈撳叆鎴栭€夋嫨妯″瀷")}" autocomplete="off" />
              <button class="provider-model-toggle" data-action="toggle-model-slot-menu" type="button" aria-label="展开模型列表">
                ${m("chevron")}
              </button>
            </div>
            <p id="model-slot-hint" class="section-eyebrow provider-model-hint">${c(qt(n.model||"",r))}</p>
            <div id="model-slot-menu" class="provider-model-menu ${t.modelSlotMenuOpen?"open":""}">
              ${t.modelSlotMenuOpen?d.length?d.map(l=>`
                  <button class="provider-model-option ${n.model===l?"active":""}" data-action="pick-slot-model" data-slot="${e}" data-model="${c(l)}" type="button">
                    ${c(l)}
                  </button>
                `).join(""):'<div class="provider-model-empty">没有匹配到当前供应商模型。</div>':""}
            </div>
          </div>
          <div class="model-choice-list">
            ${r.length?r.map(l=>`
              <button class="model-choice-item ${n.model===l?"active":""}" data-action="pick-slot-model" data-slot="${e}" data-model="${c(l)}">
                <span class="model-choice-name">${c(l)}</span>
                <span class="model-choice-check">${n.model===l?"已选":""}</span>
              </button>
            `).join(""):'<div class="model-choice-empty">当前供应商还没有可选模型，请先在“模型供应商”页选择并保存</div>'}
          </div>
        </div>
      </section>
    `}function In(e){return`
      <div class="provider-catalog-row">
        <button class="provider-row-main" data-action="open-provider-editor" data-provider="${e.id}">
          <div class="setting-copy">
            <strong>${c(e.name)}</strong>
            <p>${c(e.defaultModel||"未设置默认模型")}</p>
          </div>
          <span class="provider-inline-state ${e.enabled?"enabled":"disabled"}">${e.enabled?"已启用":"已禁用"}</span>
          <span class="row-chevron">${m("chevron")}</span>
        </button>
        <button class="switch-btn ${e.enabled?"on":"off"}" data-action="toggle-provider-enabled" data-provider-id="${e.id}" aria-pressed="${e.enabled}">
          ${Ve(e.enabled)}
        </button>
      </div>
    `}function _n(){const e=t.providerSearch.trim().toLowerCase(),o=C().providers.filter(a=>!e||a.name.toLowerCase().includes(e)||a.id.toLowerCase().includes(e)).sort((a,n)=>{const i=+!!n.enabled-+!!a.enabled;return i!==0?i:String(a.name||a.id||"").localeCompare(String(n.name||n.id||""),"zh-Hans-CN")});return`
      <section class="settings-page page-block ai-settings-page">
        <div class="search-pill glass-frost ai-search-row">
          <span class="search-icon">${m("search")}</span>
          <input class="ai-search-input" value="${c(t.providerSearch)}" data-action="provider-search" placeholder="搜索供应商" />
        </div>
        <div class="settings-group glass-frost ai-panel provider-catalog-group">
          ${o.map(a=>In(a)).join("")}
        </div>
      </section>
    `}function Mn(e){const o=Array.isArray(e._allModels)?e._allModels:[],a=e._selectedModelIds instanceof Set?e._selectedModelIds:new Set(e._selectedModelIds||[]),n=a.size,i={};for(const b of o){const M=b.vendor||"Other";i[M]||(i[M]=[]),i[M].push(b)}const s=["OpenAI","Anthropic","Google","DeepSeek","Qwen","GLM","Meta","Mistral","Moonshot","璞嗗寘","鏂囧績","娣峰厓","鐧惧窛","鏄熺伀","闆朵竴涓囩墿","InternLM","Other"],r=[...new Set([...s.filter(b=>i[b]),...Object.keys(i)])],d=o.map(b=>b.id),l=d.length>0&&d.every(b=>a.has(b)),p=r.map(b=>{const M=i[b]||[],_=!!t.providerModelVendorOpen[b],T=M.filter($=>a.has($.id)).length,S=M.length>0&&M.every($=>a.has($.id)),I=_?`
          <div class="vendor-group-body">
            ${M.map($=>{const A=a.has($.id);return`
              <div class="pool-model-row">
                <span class="pool-model-name">${c($.name)}</span>
                <span class="pool-model-caps">${Ka($)}</span>
                <button class="pool-model-btn${A?" selected":""}"
                  data-action="${A?"remove-provider-model":"add-provider-model"}"
                  data-model-id="${c($.id)}" type="button">${A?"−":"+"}</button>
              </div>`}).join("")}
          </div>`:"";return`
        <div class="vendor-group">
          <div class="vendor-group-head">
            <button class="vendor-group-toggle" data-action="toggle-provider-vendor-group" data-vendor="${c(b)}" type="button">
              <span class="vendor-group-name">${c(b)}</span>
              ${T?`<span class="vendor-group-sel">${T} 已选</span>`:""}
              <span class="vendor-group-badge">${M.length}</span>
              <span class="vendor-group-chevron${_?" open":""}">${m("chevron")}</span>
            </button>
            <button class="pool-vendor-selall${S?" all-selected":""}" data-action="toggle-vendor-all-provider-models" data-vendor="${c(b)}" type="button" title="${S?"全不选":"全选"}">${S?"−全":"+全"}</button>
          </div>
          ${I}
        </div>`}).join(""),g=o.length?"":'<p class="pool-model-empty" style="padding:10px 2px;">还没有模型，点击“同步模型”获取，或手动添加。</p>';return`
      <div class="prov-model-pool">
        <div class="prov-pool-header">
          <span class="prov-pool-count">${n?`已选 <strong>${n}</strong> 个模型`:"还没有已选模型"}</span>
          ${o.length?`<button class="pool-selall-btn${l?" all-selected":""}" data-action="toggle-all-provider-models" type="button">${l?"全不选":"全选"}</button>`:""}
        </div>
        ${g}
        ${p}
        <div class="pool-manual-row">
          <input id="provider-manual-model-input" class="ai-input provider-model-input" placeholder="手动输入模型名" autocomplete="off" />
          <button class="pool-manual-add-btn" data-action="add-manual-provider-model" type="button">＋</button>
        </div>
      </div>`}function xn(){const e=E(),o=xe(e.apiPath||e.api_path||"",{allowEmpty:!0}),a=za(e),n=!!t.providerAdvancedOpen||!!o;return`
      <section class="settings-page page-block ai-settings-page provider-editor-page">
        <div class="settings-group glass-frost ai-panel provider-editor-card">

          <div class="prov-sec">
            <h3 class="prov-sec-title">接口配置</h3>
            <label class="ai-field-label">名称</label>
            <input id="provider-name-input" class="ai-input" value="${c(e.name||"")}" placeholder="例如 SiliconFlow" />
            <label class="ai-field-label">Base URL</label>
            <input id="provider-base-input" class="ai-input" value="${c(e.baseUrl||"")}" placeholder="https://api.example.com/v1" />
            <div class="provider-advanced-head">
              <span class="section-eyebrow">Base URL 与 API 路径一起拼接请求地址</span>
              <button class="provider-advanced-toggle" data-action="toggle-provider-advanced" type="button">
                <span>高级选项</span>
                <span class="advanced-chevron ${n?"open":""}">${m("chevron")}</span>
              </button>
            </div>
            <div class="provider-advanced-panel ${n?"open":""}">
              <label class="ai-field-label">API 路径（可选）</label>
              <input id="provider-api-path-input" class="ai-input" value="${c(o)}" placeholder="${c(a)}" />
              <p class="section-eyebrow">留空时自动使用 ${c(a)}</p>
            </div>
            <label class="ai-field-label">API Key</label>
            <input id="provider-key-input" class="ai-input" value="${c(e.apiKey||"")}" placeholder="sk-..." />
          </div>

          <div class="prov-sec-divider"></div>

          <div class="prov-sec">
            <h3 class="prov-sec-title">默认模型</h3>
            <div class="provider-model-picker">
              <div class="provider-model-input-row">
                <input id="provider-default-model-input" class="ai-input provider-model-input" value="${c(e.defaultModel||"")}" placeholder="gpt-5.4" autocomplete="off" />
                <button class="provider-model-toggle" data-action="toggle-provider-model-menu" type="button" aria-label="展开模型列表">
                  ${m("chevron")}
                </button>
              </div>
              <p id="provider-default-model-hint" class="section-eyebrow provider-model-hint">${c(uo(e.defaultModel||"",e.models||[]))}</p>
              <div id="provider-default-model-menu" class="provider-model-menu ${t.providerModelMenuOpen?"open":""}"></div>
            </div>
          </div>

          <div class="prov-sec-divider"></div>

          <div class="prov-sec">
            <div class="prov-sec-title-row">
              <h3 class="prov-sec-title" style="margin:0;">模型列表</h3>
              <button class="prov-sync-btn" data-action="sync-provider-models" data-provider="${e.id}" type="button">${m("reroll")}同步</button>
            </div>
            ${Mn(e)}
            <p class="section-eyebrow" style="margin-top:4px;">同步会尝试请求 /models 接口；不兼容时可手动添加。</p>
          </div>

          <div class="prov-sec-divider"></div>

          ${X("启用供应商","关闭后将不会出现在模型选择中",!!e.enabled,"toggle-provider-enabled",e.id)}

          <div class="prov-save-row">
            <button class="prov-save-btn-main" data-action="save-provider-editor" data-provider="${e.id}" type="button">保存供应商</button>
          </div>
        </div>
      </section>
    `}async function Cn(){const e=document.getElementById("provider-base-input")?.value?.trim()||"",o=document.getElementById("provider-key-input")?.value?.trim()||"";if(!e){alert("请先填写 Base URL 再同步模型");return}try{const a=await fetch(`${y}/api/settings/ai/discover-models`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({base_url:e,api_key:o})}),n=await a.json().catch(()=>({}));if(!a.ok)throw new Error(n.detail||"同步失败");const i=Array.isArray(n.models)?n.models:[],s=E(),r=new Set((s._allModels||[]).map(b=>b.id)),d=i.map(At),l=[...d,...(s._allModels||[]).filter(b=>!i.includes(b.id))];s._allModels=l,[...new Set(d.map(b=>b.vendor))].forEach(b=>{t.providerModelVendorOpen[b]=!0}),s._selectedModelIds instanceof Set||(s._selectedModelIds=new Set(s._selectedModelIds||[])),s.models=[...s._selectedModelIds];const g=document.getElementById("provider-default-model-input");g&&(!g.value||!i.includes(g.value))&&(g.value=i[0]||g.value),s.defaultModel=g?.value?.trim()||s.defaultModel||"",u(),pe(),alert(i.length?`已同步 ${i.length} 个模型，请在模型池中选择需要的模型`:"接口已连接，但供应商没有返回可用模型")}catch(a){const n=String(a?.message||"同步模型失败");if(n.includes("Failed to fetch")){alert("同步失败：当前前端连不上后端接口。请确认 API base 配置正确，且后端可以访问。");return}alert(`同步失败：${n}`)}}Re=function(){return xt.has(t.currentView)?!1:Ba()},st=function(){if(!xt.has(t.currentView))return Na();const o={aiInterface:"AI 接口",mcpLibrary:"MCP 工具库",themeSettings:"主题模式",accountSettings:"我的账号",memoryService:"记忆服务",backendSync:"同步后端",exportSettings:"导出格式",defaultModels:"默认模型",modelSlot:$e(t.activeModelSlot),providerCatalog:"模型供应商",providerEditor:"编辑供应商",promptEditor:"提示词"},a=`chat-page-title ${t.currentView==="providerCatalog"?"provider-catalog-title":""}`.trim(),n=t.currentView==="providerCatalog"?`<button class="icon-btn ghost-circle" data-action="open-provider-editor-new" aria-label="新增供应商">${m("plus")}</button>`:'<span class="header-spacer"></span>';return`
      <header class="chat-page-header simple-header">
        <button class="icon-btn text-btn" data-action="back-sub-settings" aria-label="返回">${m("back")}</button>
        <div class="${a}">${c(o[t.currentView]||"设置")}</div>
        ${n}
      </header>
    `},rt=function(){return t.currentView==="accountSettings"?on():t.currentView==="memoryService"?an():t.currentView==="backendSync"?un():t.currentView==="exportSettings"?cn():t.currentView==="themeSettings"?tn():t.currentView==="aiInterface"?wn():t.currentView==="mcpLibrary"?$n():t.currentView==="defaultModels"?kn():t.currentView==="modelSlot"?Sn():t.currentView==="providerCatalog"?_n():t.currentView==="providerEditor"?xn():t.currentView==="promptEditor"?en():Ha()},mt=function(o){const a=o.target.closest("[data-action]"),n=a?.dataset.action;if(!n)return io(o);if(n==="open-ai-interface")return B("aiInterface");if(n==="open-mcp-library")return B("mcpLibrary");if(n==="open-theme-settings")return B("themeSettings");if(n==="open-account-settings")return B("accountSettings");if(n==="open-account-avatar"){document.getElementById("account-avatar-file")?.click();return}if(n==="open-account-nickname"){const i=window.prompt("请输入昵称",t.accountProfile?.nickname||"小酒")?.trim();if(!i)return;t.accountProfile.nickname=i,t.toast="昵称已更新",u(),x(),window.setTimeout(()=>{t.toast="",u()},1200);return}if(n==="open-account-signature"){const i=window.prompt("请输入个性签名",t.accountProfile?.signature||"")?.trim();if(!i)return;t.accountProfile.signature=i,t.toast="个性签名已更新",u(),x(),window.setTimeout(()=>{t.toast="",u()},1200);return}if(n==="open-memory-service")return B("memoryService",()=>{Te(t.currentContactId)});if(n==="memory-service-refresh"){Te(t.currentContactId,{silent:!1});return}if(n==="memory-service-create"){nn().then(()=>Te(t.currentContactId,{silent:!1})).catch(i=>{console.warn("[memory service] create failed",i),t.toast="新建记忆失败",u(),window.setTimeout(()=>{t.toast="",u()},1200)});return}if(n==="memory-service-edit"){sn(a.dataset.memoryId).then(()=>Te(t.currentContactId,{silent:!1})).catch(i=>{console.warn("[memory service] update failed",i),t.toast="编辑记忆失败",u(),window.setTimeout(()=>{t.toast="",u()},1200)});return}if(n==="memory-service-delete"){rn(a.dataset.memoryId).then(()=>Te(t.currentContactId,{silent:!1})).catch(i=>{console.warn("[memory service] delete failed",i),t.toast="删除记忆失败",u(),window.setTimeout(()=>{t.toast="",u()},1200)});return}if(n==="open-backend-sync")return B("backendSync");if(n==="sync-pull-now"){wt();return}if(n==="sync-push-now"){yt(),ao(30),t.toast="已加入上传队列",u(),window.setTimeout(()=>{t.toast="",u()},1e3);return}if(n==="open-export-settings")return B("exportSettings");if(n==="open-default-models")return B("defaultModels");if(n==="open-model-slot")return B("modelSlot",()=>{if(t.activeModelSlot=O(a.dataset.slot),t.activeModelSlotContext=a.dataset.context==="contact"?"contact":"global",t.modelSlotMenuOpen=!1,t.activeModelSlotContext==="contact"){const i=D();t.activeModelProviderId=i?.settings?.modelProviderId||k("chat")?.providerId||t.activeModelProviderId||"openai"}else t.activeModelProviderId=k("chat")?.providerId||t.activeModelProviderId||"openai"});if(n==="open-provider-catalog")return B("providerCatalog");if(n==="open-provider-editor-new")return B("providerEditor",()=>{t.providerDraftId=`custom_${Date.now()}`,t.providerAdvancedOpen=!1,t.providerModelMenuOpen=!1,t.providerEditorDraft=Tt(t.providerDraftId)});if(n==="open-provider-editor")return B("providerEditor",()=>{t.providerDraftId=a.dataset.provider;const i=z(t.providerDraftId);t.providerAdvancedOpen=!!String(i?.apiPath||i?.api_path||"").trim(),t.providerModelMenuOpen=!1,t.providerEditorDraft=Tt(t.providerDraftId)});if(n==="open-prompt-editor")return B("promptEditor",()=>{t.activePromptSlot=O(a.dataset.slot)});if(n==="back-sub-settings")return ln();if(n==="sync-provider-models"){Cn();return}if(n==="toggle-provider-advanced"){t.providerAdvancedOpen=!t.providerAdvancedOpen,u();return}if(n==="toggle-model-slot-menu"){t.modelSlotMenuOpen=!t.modelSlotMenuOpen,Fe();return}if(n==="toggle-provider-model-menu"){t.providerModelMenuOpen=!t.providerModelMenuOpen,pe();return}if(n==="pick-provider-default-model"){const i=a.dataset.model||"",s=E();s.defaultModel=i;const r=document.getElementById("provider-default-model-input");r&&(r.value=i),t.providerModelMenuOpen=!1,pe();return}if(n==="pick-slot-provider"){if(t.activeModelSlotContext==="contact"){const r=D(),d=a.dataset.providerId||t.activeModelProviderId,l=z(d);t.activeModelProviderId=d,t.modelSlotMenuOpen=!1,r?.settings&&(r.settings.modelProviderId=d,(!r.settings.model||!(l?.models||[]).includes(r.settings.model))&&(r.settings.model=l?.defaultModel||l?.models?.[0]||r.settings.model||"")),u(),P(150);return}const i=k(a.dataset.slot);i.providerId=a.dataset.providerId;const s=z(i.providerId);s&&(i.model=s.defaultModel||s.models?.[0]||i.model),t.modelSlotMenuOpen=!1,u(),x();return}if(n==="toggle-all-provider-models"){const i=E();i._selectedModelIds instanceof Set||(i._selectedModelIds=new Set(i._selectedModelIds||[]));const r=(Array.isArray(i._allModels)?i._allModels:[]).map(l=>l.id);r.length>0&&r.every(l=>i._selectedModelIds.has(l))?r.forEach(l=>i._selectedModelIds.delete(l)):r.forEach(l=>i._selectedModelIds.add(l)),i.models=[...i._selectedModelIds],u();return}if(n==="toggle-vendor-all-provider-models"){const i=a.dataset.vendor,s=E();s._selectedModelIds instanceof Set||(s._selectedModelIds=new Set(s._selectedModelIds||[]));const d=(Array.isArray(s._allModels)?s._allModels:[]).filter(p=>(p.vendor||"Other")===i).map(p=>p.id);d.length>0&&d.every(p=>s._selectedModelIds.has(p))?d.forEach(p=>s._selectedModelIds.delete(p)):d.forEach(p=>s._selectedModelIds.add(p)),s.models=[...s._selectedModelIds],u();return}if(n==="toggle-provider-vendor-group"){const i=a.dataset.vendor;i&&(t.providerModelVendorOpen[i]=!t.providerModelVendorOpen[i]),u();return}if(n==="add-provider-model"){const i=E();i._selectedModelIds instanceof Set||(i._selectedModelIds=new Set(i._selectedModelIds||[]));const s=a.dataset.modelId;s&&i._selectedModelIds.add(s),i.models=[...i._selectedModelIds],u();return}if(n==="remove-provider-model"){const i=E();i._selectedModelIds instanceof Set||(i._selectedModelIds=new Set(i._selectedModelIds||[]));const s=a.dataset.modelId;s&&i._selectedModelIds.delete(s),i.models=[...i._selectedModelIds],u();return}if(n==="add-manual-provider-model"){const i=E(),r=(document.getElementById("provider-manual-model-input")?.value||"").trim();if(!r)return;if(i._selectedModelIds instanceof Set||(i._selectedModelIds=new Set(i._selectedModelIds||[])),Array.isArray(i._allModels)||(i._allModels=[]),!i._allModels.some(d=>d.id===r)){i._allModels.push(At(r));const d=so(r);t.providerModelVendorOpen[d]=!0}i._selectedModelIds.add(r),i.models=[...i._selectedModelIds],u();return}if(n==="toggle-slot-vendor-group"){const i=a.dataset.providerId;i&&(t.slotVendorGroupOpen[i]=!t.slotVendorGroupOpen[i]),u();return}if(n==="add-model-to-slot"){const i=a.dataset.slot,s=a.dataset.providerId,r=a.dataset.model;if(!i||!s||!r)return;const d=k(i);Array.isArray(d.selectedModels)||(d.selectedModels=[]),d.selectedModels.some(l=>l.providerId===s&&l.model===r)||d.selectedModels.push({providerId:s,model:r}),u(),x();return}if(n==="remove-model-from-slot"){const i=a.dataset.slot,s=a.dataset.providerId,r=a.dataset.model;if(!i||!r)return;const d=k(i);Array.isArray(d.selectedModels)&&(d.selectedModels=d.selectedModels.filter(l=>!(l.providerId===s&&l.model===r))),u(),x();return}if(n==="add-manual-slot-model"){const i=a.dataset.slot,r=(document.getElementById("model-slot-manual-input")?.value||"").trim();if(!i||!r)return;const d=k(i);Array.isArray(d.manualModels)||(d.manualModels=[]),d.manualModels.includes(r)||d.manualModels.push(r),u(),x();return}if(n==="remove-manual-slot-model"){const i=a.dataset.slot,s=a.dataset.model;if(!i||!s)return;const r=k(i);Array.isArray(r.manualModels)&&(r.manualModels=r.manualModels.filter(d=>d!==s)),u(),x();return}if(n==="pick-theme-mode"){t.globalSettings.theme=a.dataset.theme||t.globalSettings.theme,u(),x();return}if(n==="pick-export-format"){t.globalSettings.exportFormat=a.dataset.format||t.globalSettings.exportFormat,u(),x();return}if(n==="toggle-mcp-tool"){const i=a.dataset.toolId,d=(C().mcpLibrary?.tools||[]).find(l=>String(l.id)===String(i));if(!d)return;d.enabled=d.enabled===!1,Yt(a,d.enabled!==!1),x();return}if(n==="sync-mcp-library"){fo({silent:!1});return}if(n==="edit-contact-quick-action"){if(t.quickActionDragId)return;wa(a.dataset.quickId||"");return}if(n==="add-contact-quick-action"){const i=D(),s=le(i),r=`custom_${Date.now()}`;s.push({id:r,label:"新快捷动作",icon:"more",prompt:"",mcpToolId:"",enabled:!0}),i.settings.quickActions=s,t.contactQuickActionEditorId=r,u(),P(150);return}if(n==="close-contact-quick-action-editor"){if(o.target.closest('[data-stop-close="1"]')&&!o.target.hasAttribute("data-action"))return;t.contactQuickActionEditorId="",t.contactQuickMcpMenuOpen=!1,u();return}if(n==="toggle-contact-quick-mcp-menu"){t.contactQuickMcpMenuOpen=!t.contactQuickMcpMenuOpen,a.closest(".qae-select-shell")?.classList.toggle("open",t.contactQuickMcpMenuOpen);return}if(n==="pick-contact-quick-mcp"){const i=a.closest(".qae-select-shell"),s=a.dataset.mcpId||"",r=document.getElementById("contact-quick-mcp");r&&(r.value=s);const d=a.textContent?.trim()||"不调用 MCP",l=i?.querySelector(".qae-select-trigger span");l&&(l.textContent=d),i?.querySelectorAll(".qae-select-option").forEach(p=>{p.classList.toggle("active",p===a)}),t.contactQuickMcpMenuOpen=!1,i?.classList.remove("open");return}if(n==="save-contact-quick-action"){const i=D(),s=le(i),r=a.dataset.quickId||"",d=s.find(l=>l.id===r);if(!d)return;d.label=(document.getElementById("contact-quick-label")?.value||d.label||"").trim()||d.label||"蹇嵎鍔ㄤ綔",d.prompt=(document.getElementById("contact-quick-prompt")?.value||"").trim(),d.mcpToolId=(document.getElementById("contact-quick-mcp")?.value||"").trim(),d.mcpToolId&&ce(d.mcpToolId)&&(d.id=d.id||d.mcpToolId),i.settings.quickActions=s,t.contactQuickActionEditorId="",u(),P(150);return}if(n==="delete-contact-quick-action"){const i=D(),s=a.dataset.quickId||"",r=le(i).filter(d=>d.id!==s);i.settings.quickActions=r,t.contactQuickActionEditorId===s&&(t.contactQuickActionEditorId=""),t.quickActionSwipeOpenId="",u(),P(150);return}if(n==="pick-slot-model"){if(t.activeModelSlotContext==="contact"){const s=v(t.currentContactId)||t.contacts[0];s?.settings&&(a.dataset.slot==="consciousness"?s.settings.loopModel=a.dataset.model:(s.settings.model=a.dataset.model,s.settings.modelProviderId=t.activeModelProviderId||s.settings.modelProviderId||k("chat")?.providerId||"openai")),t.modelSlotMenuOpen=!1,u(),P(150);return}const i=k(a.dataset.slot);i.model=a.dataset.model,a.dataset.providerId&&(i.providerId=a.dataset.providerId),t.modelSlotMenuOpen=!1,u(),x();return}if(n==="toggle-provider-enabled"){const i=z(a.dataset.providerId||a.dataset.key);i&&(i.enabled=!i.enabled,t.providerEditorDraft&&t.providerEditorDraft.id===i.id&&(t.providerEditorDraft.enabled=i.enabled)),u(),x();return}if(n==="save-provider-editor"){const i=a.dataset.provider,s=E(),d=[...s._selectedModelIds instanceof Set?s._selectedModelIds:new Set(s._selectedModelIds||[])].filter(Boolean),l=z(i),p=xe(document.getElementById("provider-api-path-input")?.value||"",{allowEmpty:!0}),g={...l||{id:i},id:i,name:document.getElementById("provider-name-input")?.value?.trim()||"自定义供应商",baseUrl:document.getElementById("provider-base-input")?.value?.trim()||"",apiPath:p,api_path:p,apiKey:document.getElementById("provider-key-input")?.value?.trim()||"",defaultModel:document.getElementById("provider-default-model-input")?.value?.trim()||d[0]||"",models:d},b=C();b.providers=b.providers.filter(M=>M.id!==i),b.providers.push(g),je(),t.providerEditorDraft=null,t.providerModelMenuOpen=!1,t.currentView="providerCatalog",u(),x();return}if(n==="save-slot-prompt"){const i=O(a.dataset.slot);C().defaultPrompts[i]=document.getElementById("slot-prompt-input")?.value||"",t.currentView="defaultModels",u(),x();return}if(n==="reset-slot-prompt"){const i=O(a.dataset.slot),s=Ce().defaultPrompts||{};C().defaultPrompts[i]=s[i]||"",u(),x();return}return io(o)},document.addEventListener("input",e=>{const o=e.target;if(o?.dataset?.action==="provider-search"){t.providerSearch=o.value||"",u();return}if(o?.id==="model-slot-input"){const a=v(t.currentContactId)||t.contacts[0],n=o.value||"";if(t.activeModelSlotContext==="contact")a?.settings&&(t.activeModelSlot==="consciousness"?a.settings.loopModel=n:a.settings.model=n);else{const i=k(t.activeModelSlot);i&&(i.model=n)}t.modelSlotMenuOpen=!0,Fe();return}if(o?.id==="provider-name-input"){E().name=o.value||"";return}if(o?.id==="provider-base-input"){E().baseUrl=o.value||"";return}if(o?.id==="provider-api-path-input"){const a=E();a.apiPath=o.value||"",a.api_path=o.value||"";return}if(o?.id==="provider-key-input"){E().apiKey=o.value||"";return}if(o?.id==="provider-models-input"){E().models=String(o.value||"").split(",").map(a=>a.trim()).filter(Boolean),pe();return}if(o?.id==="voice-slot-provider-input"){const a=k("voice");a&&(a.provider=o.value||"");return}if(o?.id==="voice-slot-service-url-input"){const a=k("voice");a&&(a.service_url=o.value||"",a.base_url=o.value||"");return}if(o?.id==="voice-slot-voice-id-input"){const a=k("voice");a&&(a.voice_id=o.value||"");return}if(o?.id==="voice-slot-speaker-input"){const a=k("voice");a&&(a.speaker=o.value||"");return}if(o?.id==="voice-slot-emotion-input"){const a=k("voice");a&&(a.emotion=o.value||"");return}if(o?.id==="voice-slot-speed-input"){const a=k("voice");a&&(a.speed=o.value||"");return}if(o?.id==="voice-slot-format-input"){const a=k("voice");a&&(a.format=o.value||"");return}if(o?.id==="provider-default-model-input"){E().defaultModel=o.value||"",t.providerModelMenuOpen=!0,pe();return}if(o?.dataset?.contactField==="persona"){const a=D();if(!a)return;a.persona=o.value||"",P(180),yn(a.id,a.persona)}}),document.addEventListener("change",e=>{const o=e.target;if(o?.id==="nc-avatar-file"){const a=o.files?.[0];if(!a)return;const n=new FileReader;n.onload=()=>{t.newContactAvatar=typeof n.result=="string"?n.result:"",u()},n.readAsDataURL(a);return}if(o?.id==="account-avatar-file"){const a=o.files?.[0];if(!a)return;const n=new FileReader;n.onload=()=>{t.accountProfile.avatar=typeof n.result=="string"?n.result:t.accountProfile.avatar,t.toast="头像已更新",u(),x(),window.setTimeout(()=>{t.toast="",u()},1200)},n.readAsDataURL(a);return}if(o?.id==="contact-avatar-file"){const a=o.files?.[0];if(!a)return;const n=v(t.currentContactId);if(!n)return;const i=new FileReader;i.onload=()=>{n.avatar=typeof i.result=="string"?i.result:n.avatar,t.toast="头像已更新",u(),P(120),window.setTimeout(()=>{t.toast="",u()},1200)},i.readAsDataURL(a);return}if(o?.id==="moment-image-input"){const a=o.files?.[0];if(!a)return;t.momentComposerImageName=a.name||"";const n=new FileReader;n.onload=()=>{t.momentComposerImage=typeof n.result=="string"?n.result:"",u()},n.readAsDataURL(a);return}if(o?.dataset?.action==="select-slot-model"){const a=k(o.dataset.slot);if(!a)return;a.model=o.value,x();return}String(o?.id||"").startsWith("voice-slot-")&&x()});function Tn(e,o){const a=D(),n=le(a),i=n.findIndex(r=>r.id===e);if(i<0)return;const[s]=n.splice(i,1);if(!o)n.splice(0,0,s);else{const r=n.findIndex(d=>d.id===o);r<0?n.push(s):n.splice(r+1,0,s)}a.settings.quickActions=n,P(120)}const f={id:"",mode:"idle",startX:0,startY:0,currentY:0,hoverId:"",pendingDropId:null,pressTimer:null};function qe(){f.pressTimer&&(clearTimeout(f.pressTimer),f.pressTimer=null)}function go(){qe(),f.id="",f.mode="idle",f.startX=0,f.startY=0,f.currentY=0,f.hoverId="",f.pendingDropId=null}function Pt(){h()?.querySelectorAll(".quick-action-swipe.drop-hint-after").forEach(e=>e.classList.remove("drop-hint-after"))}function An(e,o){const a=h()?.querySelector(`.quick-action-swipe[data-quick-id="${e}"]`);if(!a)return;const n=a.querySelector(".quick-action-row"),i=a.querySelector(".quick-action-delete");if(!n||!i)return;const s=Math.max(-74,Math.min(0,Number(o)||0)),r=Math.min(1,Math.abs(s)/74);n.style.transform=`translateX(${s}px)`,i.style.opacity=String(r),i.style.transform=`translateX(${18*(1-r)}px) scale(${.97+.03*r})`,i.style.pointerEvents=r>.98?"auto":"none"}function me(e){const o=h()?.querySelector(`.quick-action-swipe[data-quick-id="${e}"]`);if(!o)return;const a=o.querySelector(".quick-action-row"),n=o.querySelector(".quick-action-delete");a&&a.style.removeProperty("transform"),n&&(n.style.removeProperty("opacity"),n.style.removeProperty("transform"),n.style.removeProperty("pointer-events"))}function bo(){if(h()?.querySelectorAll(".quick-action-swipe.quick-dragging").forEach(n=>n.classList.remove("quick-dragging")),h()?.querySelectorAll(".quick-action-row.touch-dragging").forEach(n=>{n.classList.remove("touch-dragging"),n.style.removeProperty("transform")}),!t.quickActionDragId)return;const e=h()?.querySelector(`.quick-action-row[data-quick-id="${t.quickActionDragId}"]`),o=e?.closest(".quick-action-swipe");if(!e||!o)return;o.classList.add("quick-dragging"),e.classList.add("touch-dragging");const a=f.currentY-f.startY;e.style.transform=`translateY(${a}px) scale(1.04) rotate(1.2deg)`}function qn(e){const o=Array.from(h()?.querySelectorAll(".quick-action-swipe[data-quick-id]")||[]).filter(n=>n.dataset.quickId!==t.quickActionDragId);if(!o.length)return"";let a="";for(const n of o){const i=n.getBoundingClientRect(),s=i.top+i.height/2;if(e>=s)a=n.dataset.quickId;else break}return a}function ho(){const e=f.pendingDropId,o=t.quickActionDragId;Pt(),t.quickActionDragId="",t.quickActionDropHintId="",t.quickActionDropDirection="",t.quickActionReorderPulseId="",o&&e!==null&&Tn(o,e),u()}function vo(e,o,a){qe(),t.quickActionSwipeOpenId&&t.quickActionSwipeOpenId!==a&&(me(t.quickActionSwipeOpenId),t.quickActionSwipeOpenId="",u()),f.id=a,f.mode="pending",f.startX=e,f.startY=o,f.currentY=o,f.hoverId="",f.pressTimer=window.setTimeout(()=>{if(!(f.mode!=="pending"||!f.id)&&(f.mode="drag",f.pendingDropId=null,t.quickActionDragId=f.id,bo(),navigator?.vibrate))try{navigator.vibrate(12)}catch{}},280)}function yo(e,o,a){if(!f.id)return;const n=e-f.startX,i=o-f.startY;if(f.mode==="pending"){Math.abs(n)>12&&Math.abs(n)>Math.abs(i)?(qe(),f.mode="swipe"):Math.abs(i)>10&&(qe(),f.mode="cancelled");return}if(f.mode==="swipe"){const d=t.quickActionSwipeOpenId===f.id?-74:0,l=Math.max(-74,Math.min(0,d+n));An(f.id,l);return}if(f.mode!=="drag")return;a?.(),f.currentY=o,bo();const s=qn(o);s!==f.pendingDropId&&(f.pendingDropId=s,Pt(),s&&h()?.querySelector(`.quick-action-swipe[data-quick-id="${s}"]`)?.classList.add("drop-hint-after"))}function wo(e){if(f.id){if(qe(),f.mode==="swipe"){const o=t.quickActionSwipeOpenId===f.id,a=e-f.startX;(o?-74+a:a)<-36?(t.quickActionSwipeOpenId=f.id,me(f.id),u()):o&&a>22?(t.quickActionSwipeOpenId="",me(f.id),u()):(me(f.id),o&&(t.quickActionSwipeOpenId=f.id,u()))}f.mode==="drag"&&ho(),go()}}document.addEventListener("touchstart",e=>{if(pt(e.target)||e.target.closest(".quick-action-open"))return;const o=e.target.closest(".quick-action-row");if(!o){!e.target.closest(".quick-action-delete")&&!e.target.closest(".quick-action-swipe")&&t.quickActionSwipeOpenId&&(me(t.quickActionSwipeOpenId),t.quickActionSwipeOpenId="",u());return}const a=e.touches?.[0];a&&vo(a.clientX,a.clientY,o.dataset.quickId||"")},{passive:!0}),document.addEventListener("touchmove",e=>{const o=e.touches?.[0];o&&yo(o.clientX,o.clientY,()=>e.preventDefault())},{passive:!1}),document.addEventListener("touchend",e=>{const o=e.changedTouches?.[0];wo(o?.clientX||f.startX)},{passive:!0}),document.addEventListener("touchcancel",()=>{me(f.id),Pt(),f.mode==="drag"&&ho(),go()},{passive:!0}),document.addEventListener("mousedown",e=>{if(pt(e.target)||e.target.closest(".quick-action-open"))return;const o=e.target.closest(".quick-action-row");if(!o||e.button!==0){!e.target.closest(".quick-action-delete")&&!e.target.closest(".quick-action-swipe")&&t.quickActionSwipeOpenId&&(me(t.quickActionSwipeOpenId),t.quickActionSwipeOpenId="",u());return}vo(e.clientX,e.clientY,o.dataset.quickId||"")}),document.addEventListener("mousemove",e=>{yo(e.clientX,e.clientY,()=>e.preventDefault())}),document.addEventListener("mouseup",e=>{wo(e.clientX)});const Pn=lt;lt=function(){return Pn()},document.addEventListener("DOMContentLoaded",()=>{C(),dn(),fo(),mo(),J(),Ae(t.currentContactId),window.setTimeout(()=>{wt()},250)}),document.addEventListener("focusin",e=>{const o=e.target;if(o?.id==="model-slot-input"){t.modelSlotMenuOpen=!0,Fe();return}o?.id==="provider-default-model-input"&&(t.providerModelMenuOpen=!0,pe())}),document.addEventListener("click",e=>{if(xt.has(t.currentView)&&t.currentView==="modelSlot"&&!e.target.closest('#model-slot-input, .provider-model-picker, [data-action="toggle-model-slot-menu"]')&&t.modelSlotMenuOpen){t.modelSlotMenuOpen=!1,Fe();return}if(t.currentView!=="providerEditor")return;!e.target.closest(".provider-model-picker")&&t.providerModelMenuOpen&&(t.providerModelMenuOpen=!1,pe())})})();
